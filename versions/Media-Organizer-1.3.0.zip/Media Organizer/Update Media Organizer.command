#!/bin/bash
# Double-click to update Media Organizer in place (no need to delete or copy
# folders). Your data and settings are kept.

cd "$(dirname "$0")" || exit 1
clear
echo "=============================================="
echo "  Media Organizer - update"
echo "=============================================="

PYTHON=""
for candidate in /opt/homebrew/bin/python3 /usr/local/bin/python3 \
    /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /usr/bin/python3; do
  if [ -x "$candidate" ] && "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1; then
    PYTHON="$candidate"; break
  fi
done
if [ -z "$PYTHON" ]; then
  echo "  Python was not found. Double-click 'Media Organizer.command' first."
  read -r -p "  Press Enter to close. " _
  exit 1
fi

"$PYTHON" -m media_organizer update
read -r -p "  Press Enter to close. " _
