"""Read folders and propose the best archive structure.

Nothing is changed: the analysis only reads each file's metadata (capture
date, camera) and folder names, then recommends import options with a
plain-language reason for each, plus a preview of the resulting folders.
"""

from __future__ import annotations

import os
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .constants import is_media, is_video
from .duplicates import Progress
from .importer import ImportOptions, event_name, media_info_loader, target_folder, target_name
from .metadata import MediaInfo
from .scanner import WalkReport, order_roots, walk_files

READ_WORKERS = 8


@dataclass
class AnalyzedFile:
    name: str
    size: int
    video: bool
    info: MediaInfo
    event: str


@dataclass
class Analysis:
    sources: List[str]
    files: List[AnalyzedFile] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    skipped_bundles: List[str] = field(default_factory=list)
    cancelled: bool = False


def camera_family(info: MediaInfo) -> str:
    text = f"{info.make} {info.model}".lower()
    if "iphone" in text or "ipad" in text or (text.strip().startswith("apple")):
        return "iPhone / iPad"
    if "dji" in text or text.strip().startswith("fc"):
        return "DJI"
    if "gopro" in text or "hero" in text:
        return "GoPro"
    if "insta360" in text or "arashi" in text:
        return "Insta360"
    if any(b in text for b in ("samsung", "google", "pixel", "huawei", "xiaomi", "oneplus", "motorola", "oppo", "sony xperia")):
        return "Other phone"
    if text.strip():
        return "Camera"
    return "Unknown"


def analyze(sources: List[str], progress: Optional[Progress] = None) -> Analysis:
    progress = progress or Progress()
    sources = order_roots(sources)
    if not sources:
        raise ValueError("Please add at least one folder to analyze.")
    for s in sources:
        if not os.path.isdir(s):
            raise ValueError(f"Folder not found: {s}")
    result = Analysis(sources=sources)
    report = WalkReport()
    progress.set(phase="Listing files", done=0, total=0)
    entries = []
    for e in walk_files(sources, is_media, report, cancelled=progress.cancelled):
        entries.append(e)
        if len(entries) % 200 == 0:
            progress.set(done=len(entries), current=e.path)
    result.errors.extend(report.errors)
    result.skipped_bundles.extend(report.skipped_bundles)
    progress.set(phase="Reading dates and cameras", done=0, total=len(entries))

    info_for = media_info_loader(sources)

    def read(e):
        try:
            return e, info_for(e.path), None
        except OSError as exc:
            return e, None, exc

    # Metadata sits in the first few KB of each file: reading several files
    # at once keeps SSDs and network disks busy instead of waiting on each.
    with ThreadPoolExecutor(max_workers=READ_WORKERS) as pool:
        for i, (e, info, exc) in enumerate(pool.map(read, entries, chunksize=16)):
            if progress.cancelled():
                result.cancelled = True
                pool.shutdown(wait=False, cancel_futures=True)
                break
            if i % 25 == 0:
                progress.set(done=i, current=e.path)
            if exc is not None:
                result.errors.append(f"Cannot read {e.path}: {exc.strerror or exc}")
                continue
            result.files.append(AnalyzedFile(
                name=os.path.basename(e.path),
                size=e.size,
                video=is_video(e.path),
                info=info,
                event=event_name(e.path, e.root, info.camera),
            ))
    progress.set(done=len(entries))
    return result


def recommend(a: Analysis) -> dict:
    files = a.files
    n = len(files) or 1
    per_year = Counter(f.info.date.year for f in files if f.info.date_source != "file date")
    per_month = Counter(f.info.date.strftime("%Y-%m") for f in files)
    per_day = Counter(f.info.date.strftime("%Y-%m-%d") for f in files)
    families = Counter(camera_family(f.info) for f in files)
    undated = sum(1 for f in files if f.info.date_source == "file date")
    in_events = sum(1 for f in files if f.event)
    events = Counter(f.event for f in files if f.event)

    # Same file name with different sizes = certainly different files that
    # would collide in one folder (GoPro/DJI restart numbering on every card).
    sizes_by_name: Dict[str, set] = defaultdict(set)
    for f in files:
        sizes_by_name[f.name.lower()].add(f.size)
    clashing_names = sum(1 for s in sizes_by_name.values() if len(s) > 1)

    reasons = {}
    avg_month = len(files) / max(1, len(per_month))
    max_year = max(per_year.values()) if per_year else len(files)
    if len(files) < 1500 and max_year < 400:
        layout = "year"
        reasons["layout"] = (
            f"You have about {max_year:,} files in your busiest year: one folder per year stays easy to browse."
        )
    elif avg_month > 500:
        layout = "year/month/date"
        reasons["layout"] = (
            f"On average {avg_month:,.0f} files per month: a folder for every day keeps folders small."
        )
    else:
        layout = "year/month"
        reasons["layout"] = (
            f"On average {avg_month:,.0f} files per month: one folder per month (inside a folder per year) "
            "is the easiest to browse in Finder."
        )

    real_families = {k: v for k, v in families.items() if k not in ("Unknown",)}
    special = {k: v for k, v in real_families.items() if k in ("DJI", "GoPro", "Insta360", "Camera")}
    by_camera = len(real_families) >= 2 and any(v >= 0.05 * n for v in special.values())
    fam_text = ", ".join(f"{k} ({v:,})" for k, v in families.most_common())
    if by_camera:
        reasons["by_camera"] = (
            f"Your files come from several devices ({fam_text}). A sub-folder per camera keeps drone and "
            "action-cam footage apart from phone photos."
        )
    else:
        reasons["by_camera"] = (
            f"Most files come from one kind of device ({fam_text}), so extra camera folders would only add clicks."
        )

    action_cams = families.get("GoPro", 0) + families.get("DJI", 0) + families.get("Insta360", 0)
    rename = clashing_names > 0 or action_cams > 0
    if clashing_names:
        reasons["rename"] = (
            f"{clashing_names:,} file names are used by different files (cameras restart numbering, e.g. "
            "GX010001.MP4). Adding date and time to the name avoids confusion and sorts files by time."
        )
    elif action_cams:
        reasons["rename"] = (
            "GoPro/DJI names (GX010001.MP4, DJI_0001.JPG) repeat on every card; adding the date and time "
            "makes them unique and sorts them by time."
        )
    else:
        reasons["rename"] = "File names are already unique; keeping the original names is simplest."

    undated_folder = undated > 0.1 * n
    if undated:
        reasons["undated_folder"] = (
            f"{undated:,} files ({100 * undated / n:.0f}%) have no date from the camera. Their file date may be "
            "the day they were copied, not taken"
            + (", so they are kept apart to check by hand." if undated_folder
               else "; they are few, so they are filed by that date.")
        )
    else:
        reasons["undated_folder"] = "Every file has a date from the camera."

    keep_events = in_events >= max(1, 0.1 * n)
    top_events = ", ".join(f"“{k}”" for k, _ in events.most_common(4))
    if keep_events:
        reasons["keep_event_names"] = (
            f"{in_events:,} files are in folders with meaningful names ({top_events}…). Keeping those names "
            "(e.g. “2023-07 Hawaii”) makes trips and events easy to find."
        )
    elif events:
        reasons["keep_event_names"] = (
            f"Only a few files are in named folders ({top_events}), so plain date folders are cleaner."
        )
    else:
        reasons["keep_event_names"] = "No meaningful folder names found (only camera or date folders)."

    return {
        "layout": layout,
        "by_camera": by_camera,
        "rename": rename,
        "undated_folder": undated_folder,
        "keep_event_names": keep_events,
        "reasons": reasons,
    }


def summary(a: Analysis) -> dict:
    files = a.files
    years = Counter(f.info.date.year for f in files)
    families = Counter(camera_family(f.info) for f in files)
    cameras = Counter(f.info.camera or "Unknown" for f in files)
    dates = [f.info.date for f in files if f.info.date_source != "file date"]
    return {
        "sources": a.sources,
        "files": len(files),
        "bytes": sum(f.size for f in files),
        "photos": sum(1 for f in files if not f.video),
        "videos": sum(1 for f in files if f.video),
        "first": min(dates).strftime("%Y-%m-%d") if dates else "",
        "last": max(dates).strftime("%Y-%m-%d") if dates else "",
        "years": sorted(years.items()),
        "families": families.most_common(),
        "cameras": cameras.most_common(12),
        "date_sources": dict(Counter(f.info.date_source for f in files)),
        "events": Counter(f.event for f in files if f.event).most_common(15),
        "errors": a.errors[:300],
        "skipped_bundles": a.skipped_bundles,
        "cancelled": a.cancelled,
    }


def preview_tree(a: Analysis, options: ImportOptions, max_children: int = 60) -> dict:
    """Folder tree (relative to the archive) the import would create."""
    base = options.destination or "Archive"
    opts = ImportOptions(
        sources=[], destination=base, layout=options.layout, by_camera=options.by_camera,
        rename=options.rename, undated_folder=options.undated_folder,
        keep_event_names=options.keep_event_names,
    )
    root = {"name": os.path.basename(base.rstrip(os.sep)) or base, "count": 0, "bytes": 0, "children": {}, "samples": []}
    for f in a.files:
        folder = target_folder(opts, f.info, f.event if opts.keep_event_names else "")
        rel = os.path.relpath(folder, base)
        node = root
        node["count"] += 1
        node["bytes"] += f.size
        for part in ([] if rel == "." else rel.split(os.sep)):
            node = node["children"].setdefault(
                part, {"name": part, "count": 0, "bytes": 0, "children": {}, "samples": []}
            )
            node["count"] += 1
            node["bytes"] += f.size
        if len(node["samples"]) < 3:
            node["samples"].append(target_name(opts, f.info, f.name))

    folders = [0]

    def finish(node):
        kids = sorted(node["children"].values(), key=lambda k: k["name"])
        folders[0] += len(kids)
        node["more"] = max(0, len(kids) - max_children)
        node["children"] = [finish(k) for k in kids[:max_children]]
        if node["children"]:
            node["samples"] = []
        return node

    tree = finish(root)
    tree["folder_count"] = folders[0]
    return tree


LAYOUT_LABELS = {
    "year/month": "2024 / 2024-07",
    "year/date": "2024 / 2024-07-15",
    "year/month/date": "2024 / 2024-07 / 2024-07-15",
    "year": "2024",
}


def recommend_for_archive(a: Analysis, archive: str = "") -> dict:
    """Like recommend(), but an existing archive's structure always wins.

    Consistency matters more than the ideal layout: once files were filed a
    certain way, new files (and later runs) should follow the same rules.
    """
    from . import archive_settings

    rec = recommend(a)
    rec["archive"] = None
    if not archive or not os.path.isdir(archive):
        return rec
    saved = archive_settings.load(archive)
    if saved:
        for key in ("layout", "by_camera", "rename", "undated_folder", "keep_event_names"):
            if key in saved:
                rec[key] = bool(saved[key]) if key != "layout" else saved[key]
        note = "Your archive is already organized this way; keeping the same setting keeps everything consistent."
        for key in ("layout", "by_camera", "rename", "undated_folder", "keep_event_names"):
            rec["reasons"][key] = note
        rec["archive"] = {"kind": "saved", "updated": saved.get("updated", ""),
                          "set_dates": bool(saved.get("set_dates", True))}
        return rec
    layout = archive_settings.infer_layout(archive)
    if layout:
        rec["layout"] = layout
        rec["reasons"]["layout"] = (
            f"Your archive already uses folders like “{LAYOUT_LABELS.get(layout, layout)}”; "
            "new files follow the same pattern so everything stays consistent."
        )
        rec["archive"] = {"kind": "detected", "layout": layout}
    return rec
