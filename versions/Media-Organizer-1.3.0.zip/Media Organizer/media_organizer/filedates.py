"""Set a file's dates on disk (what Finder shows) to the date a photo was taken.

Only the file system's timestamps change (Date Modified and, on macOS, Date
Created). The photo or video itself is never opened for writing, so its
content and its fingerprint stay exactly the same.
"""

from __future__ import annotations

import datetime as _dt
import os
import sys
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from . import appdata
from .constants import is_media
from .duplicates import Progress
from .metadata import MediaInfo
from .scanner import WalkReport, inside_protected_bundle, order_roots, walk_files

IS_MAC = sys.platform == "darwin"
TRUSTED_SOURCES = ("metadata", "Photos library", "file name")
HISTORY_FILE = "date-fixes.json"
TOLERANCE = 2.0  # seconds: dates this close are already right


def local_timestamp(d: _dt.datetime) -> float:
    """Wall-clock time as taken by the camera -> timestamp on this Mac."""
    return time.mktime(d.timetuple()) + d.microsecond / 1e6


def birth_time(path: str) -> Optional[float]:
    try:
        return getattr(os.stat(path), "st_birthtime", None)
    except OSError:
        return None


def _set_creation_time_mac(path: str, ts: float) -> bool:
    """Set macOS 'Date Created' with setattrlist(2). Best effort."""
    try:
        import ctypes
        import ctypes.util

        libc = ctypes.CDLL(ctypes.util.find_library("c"), use_errno=True)

        class AttrList(ctypes.Structure):
            _fields_ = [
                ("bitmapcount", ctypes.c_ushort),
                ("reserved", ctypes.c_uint16),
                ("commonattr", ctypes.c_uint32),
                ("volattr", ctypes.c_uint32),
                ("dirattr", ctypes.c_uint32),
                ("fileattr", ctypes.c_uint32),
                ("forkattr", ctypes.c_uint32),
            ]

        class TimeSpec(ctypes.Structure):
            _fields_ = [("tv_sec", ctypes.c_long), ("tv_nsec", ctypes.c_long)]

        ATTR_BIT_MAP_COUNT = 5
        ATTR_CMN_CRTIME = 0x00000200
        FSOPT_NOFOLLOW = 0x00000001
        attrs = AttrList(ATTR_BIT_MAP_COUNT, 0, ATTR_CMN_CRTIME, 0, 0, 0, 0)
        sec = int(ts // 1)
        value = TimeSpec(sec, int((ts - sec) * 1e9))
        rc = libc.setattrlist(
            os.fsencode(path), ctypes.byref(attrs), ctypes.byref(value),
            ctypes.sizeof(value), FSOPT_NOFOLLOW,
        )
        return rc == 0
    except Exception:
        return False


def set_file_dates(path: str, ts: float, created: Optional[float] = None) -> None:
    """Set Date Modified to ts and (macOS) Date Created to `created` or ts.

    Raises OSError if the modification date cannot be changed (for example
    on a read-only disk).
    """
    st = os.stat(path)
    os.utime(path, (st.st_atime, ts))
    if IS_MAC:
        _set_creation_time_mac(path, ts if created is None else created)


# ---------------------------------------------------------------------------
# Fixing dates of files already on disk
# ---------------------------------------------------------------------------


@dataclass
class DateItem:
    path: str
    taken: str
    source: str
    current: str
    status: str = ""  # "fixed" / "would fix" / "already right" / "no date" / "error"
    detail: str = ""


@dataclass
class DateFixResult:
    roots: List[str]
    dry_run: bool
    items: List[DateItem] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    cancelled: bool = False
    run_id: str = ""

    def count(self, status: str) -> int:
        return sum(1 for i in self.items if i.status == status)


def _fmt(ts: Optional[float]) -> str:
    if ts is None:
        return ""
    return _dt.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M:%S")


def fix_dates(
    roots: List[str],
    dry_run: bool = True,
    progress: Optional[Progress] = None,
    info_for: Optional[Callable[[str], MediaInfo]] = None,
) -> DateFixResult:
    """Make every photo/video's file dates match the date it was taken."""
    from .importer import media_info_loader

    progress = progress or Progress()
    roots = order_roots(roots)
    if not roots:
        raise ValueError("Please add at least one folder.")
    for r in roots:
        if not os.path.isdir(r):
            raise ValueError(f"Folder not found: {r}")
        bundle = inside_protected_bundle(r)
        if bundle:
            raise ValueError(
                f"'{r}' is inside the app library '{os.path.basename(bundle)}', whose files "
                "must not be changed by hand. Import from it instead."
            )
    info_for = info_for or media_info_loader(roots)
    result = DateFixResult(roots=roots, dry_run=dry_run)
    report = WalkReport()
    progress.set(phase="Listing files", done=0, total=0)
    entries = list(walk_files(roots, is_media, report, cancelled=progress.cancelled))
    result.errors.extend(report.errors)
    progress.set(
        phase="Checking dates (simulation)" if dry_run else "Setting file dates",
        done=0, total=len(entries),
    )
    history = []
    for i, e in enumerate(entries):
        if progress.cancelled():
            result.cancelled = True
            break
        if i % 20 == 0:
            progress.set(done=i, current=e.path)
        try:
            info = info_for(e.path)
            st = os.stat(e.path)
        except OSError as exc:
            result.items.append(DateItem(e.path, "", "", "", "error", str(exc.strerror or exc)))
            continue
        birth = getattr(st, "st_birthtime", None)
        current = min(st.st_mtime, birth) if birth else st.st_mtime
        item = DateItem(
            path=e.path,
            taken=info.date.strftime("%Y-%m-%d %H:%M:%S"),
            source=info.date_source,
            current=_fmt(current),
        )
        result.items.append(item)
        if info.date_source not in TRUSTED_SOURCES:
            item.status, item.detail = "no date", "No date inside the file: left unchanged"
            continue
        target = local_timestamp(info.date)
        if abs(st.st_mtime - target) <= TOLERANCE and (birth is None or abs(birth - target) <= TOLERANCE):
            item.status = "already right"
            continue
        if dry_run:
            item.status = "would fix"
            continue
        try:
            set_file_dates(e.path, target)
        except OSError as exc:
            item.status = "error"
            item.detail = f"Could not change the date: {exc.strerror or exc}"
            continue
        item.status = "fixed"
        history.append({"path": e.path, "mtime": st.st_mtime, "birth": birth, "new": target})
    progress.set(done=len(entries))
    if not dry_run and history:
        result.run_id = _save_history(roots, history)
    return result


def _save_history(roots: List[str], changes: List[dict]) -> str:
    runs = appdata.read_json(HISTORY_FILE, [])
    run_id = _dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    runs.append({
        "id": run_id,
        "created": _dt.datetime.now().isoformat(timespec="seconds"),
        "roots": roots,
        "changes": changes,
    })
    appdata.write_json(HISTORY_FILE, runs[-20:])  # keep the last 20 runs
    return run_id


def list_runs() -> List[dict]:
    out = []
    for r in reversed(appdata.read_json(HISTORY_FILE, [])):
        out.append({
            "id": r["id"],
            "created": r.get("created", ""),
            "roots": r.get("roots", []),
            "files": len(r.get("changes", [])),
            "undone": bool(r.get("undone")),
        })
    return out


def undo_run(run_id: str) -> Dict[str, int]:
    """Put back the file dates changed by one run (if the file is unchanged since)."""
    runs = appdata.read_json(HISTORY_FILE, [])
    run = next((r for r in runs if r.get("id") == run_id), None)
    if run is None:
        raise ValueError("This date fix is not in the history any more.")
    restored = skipped = 0
    for c in run.get("changes", []):
        try:
            st = os.stat(c["path"])
            if abs(st.st_mtime - c["new"]) > TOLERANCE:
                skipped += 1  # changed again since: leave it
                continue
            set_file_dates(c["path"], c["mtime"], created=c.get("birth") or c["mtime"])
            restored += 1
        except OSError:
            skipped += 1
    run["undone"] = True
    appdata.write_json(HISTORY_FILE, runs)
    return {"restored": restored, "skipped": skipped}
