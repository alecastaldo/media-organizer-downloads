"""Exact-duplicate detection and safe, reversible removal.

How duplicates are found (a file is only reported when ALL steps agree):
  1. same size in bytes
  2. same SHA-256 of the first and last 64 KiB
  3. same SHA-256 of the whole file

How duplicates are removed:
  * One copy of every group is always kept (never touched).
  * Right before a copy is moved away, it is compared again with the kept
    copy byte by byte. If anything differs, or the kept copy is missing,
    the file is left alone.
  * Copies are *moved* into a quarantine folder (not deleted), together
    with a manifest, so every move can be undone with one click.
"""

from __future__ import annotations

import datetime as _dt
import os
import re
import shutil
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional

from . import appdata
from .constants import QUARANTINE_DIR_NAME, is_media
from .hashing import Cancelled, HashCache, files_identical, full_hash, quick_hash
from .scanner import (
    FileEntry,
    WalkReport,
    inside_protected_bundle,
    order_roots,
    walk_files,
)

SESSIONS_FILE = "quarantine-sessions.json"
QUICK_WORKERS = 4


@dataclass
class DuplicateGroup:
    id: int
    size: int
    sha256: str
    files: List[FileEntry]
    keep: int = 0  # index into files
    skip: bool = False  # user chose to leave this group alone


@dataclass
class ScanResult:
    roots: List[str]
    preferred: List[str]
    files_scanned: int = 0
    bytes_scanned: int = 0
    groups: List[DuplicateGroup] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    skipped_bundles: List[str] = field(default_factory=list)
    cancelled: bool = False

    @property
    def redundant_files(self) -> int:
        return sum(len(g.files) - 1 for g in self.groups)

    @property
    def redundant_bytes(self) -> int:
        return sum(g.size * (len(g.files) - 1) for g in self.groups)


class Progress:
    """Receives progress updates; the web server shows them to the user."""

    def __init__(self):
        self.phase = ""
        self.done = 0
        self.total = 0
        self.current = ""
        self.cancel_requested = False

    def set(self, phase=None, done=None, total=None, current=None):
        if phase is not None:
            self.phase = phase
        if done is not None:
            self.done = done
        if total is not None:
            self.total = total
        if current is not None:
            self.current = current

    def cancelled(self) -> bool:
        return self.cancel_requested


_COPY_HINT = re.compile(r"(copy|copie|kopie|copia|\(\d+\)|[ _-]\d$| \d+$)", re.I)


_BACKUP_FOLDER = re.compile(
    r"(?<![a-z])(backup|back-up|copy|copies|copia|copie|kopie|duplicate|dupes|old|temp|tmp|trash|"
    r"downloads|desktop|whatsapp|unsorted|to be sorted)(?![a-z])", re.I)


def _keeper_score(entry: FileEntry, preferred: List[str]):
    """Lower is better. Decides which copy is suggested to keep."""
    in_preferred = any(_is_within(entry.path, p) for p in preferred)
    stem = os.path.splitext(os.path.basename(entry.path))[0]
    looks_like_copy = bool(_COPY_HINT.search(stem))
    in_backup_folder = bool(_BACKUP_FOLDER.search(os.path.dirname(entry.path)))
    return (
        0 if in_preferred else 1,
        1 if looks_like_copy else 0,
        1 if in_backup_folder else 0,
        entry.mtime,  # oldest first: usually the original
        entry.path.count(os.sep),
        len(entry.path),
        entry.path,
    )


def _is_within(path: str, folder: str) -> bool:
    folder = folder.rstrip(os.sep) + os.sep
    return path.startswith(folder)


def find_duplicates(
    roots: List[str],
    preferred: Optional[List[str]] = None,
    progress: Optional[Progress] = None,
    cache: Optional[HashCache] = None,
    accept: Callable[[str], bool] = is_media,
) -> ScanResult:
    progress = progress or Progress()
    roots = order_roots(roots)
    preferred = order_roots(preferred or [])
    result = ScanResult(roots=roots, preferred=preferred)
    for r in roots:
        bundle = inside_protected_bundle(r)
        if bundle:
            raise ValueError(
                f"'{r}' is inside the app library '{os.path.basename(bundle)}'. "
                "Files inside Photos / Lightroom libraries must not be removed by hand. "
                "Use the library's own app for that."
            )
        if not os.path.isdir(r):
            raise ValueError(f"Folder not found: {r}")

    report = WalkReport()
    by_size: Dict[int, List[FileEntry]] = defaultdict(list)
    progress.set(phase="Listing files", done=0, total=0)
    count = 0
    for entry in walk_files(
        roots, accept, report, cancelled=progress.cancelled,
        on_dir=lambda d: progress.set(current=d),
    ):
        count += 1
        result.bytes_scanned += entry.size
        if entry.size > 0:
            by_size[entry.size].append(entry)
        if count % 200 == 0:
            progress.set(done=count)
    result.files_scanned = count
    result.errors.extend(report.errors)
    result.skipped_bundles.extend(report.skipped_bundles)
    if progress.cancelled():
        result.cancelled = True
        return result

    # Step 2: quick hash for files that share a size.
    candidates = [grp for grp in by_size.values() if len(grp) > 1]
    total = sum(len(g) for g in candidates)
    progress.set(phase="Comparing file beginnings and ends", done=0, total=total)
    by_quick: Dict[tuple, List[FileEntry]] = defaultdict(list)

    def quick(entry):
        try:
            return entry, quick_hash(entry.path, entry.size), None
        except OSError as exc:
            return entry, None, exc

    # Only 128 KB per file is read here, so several files are read at once.
    todo = [entry for grp in candidates for entry in grp]
    with ThreadPoolExecutor(max_workers=QUICK_WORKERS) as pool:
        for done, (entry, digest, exc) in enumerate(pool.map(quick, todo, chunksize=8), start=1):
            if progress.cancelled():
                pool.shutdown(wait=False, cancel_futures=True)
                result.cancelled = True
                return result
            if done % 20 == 0:
                progress.set(done=done, current=entry.path)
            if exc is not None:
                result.errors.append(f"Cannot read {entry.path}: {exc.strerror or exc}")
                continue
            by_quick[(entry.size, digest)].append(entry)

    # Step 3: full hash.
    candidates = [grp for grp in by_quick.values() if len(grp) > 1]
    total_bytes = sum(e.size for g in candidates for e in g)
    progress.set(phase="Comparing full contents", done=0, total=total_bytes)
    own_cache = cache is None
    cache = cache or HashCache()
    hashed = [0]

    def advance(n):
        hashed[0] += n
        progress.set(done=hashed[0])

    by_full: Dict[tuple, List[FileEntry]] = defaultdict(list)
    try:
        for grp in candidates:
            for entry in grp:
                progress.set(current=entry.path)
                try:
                    digest = cache.hash(entry.path, advance, progress.cancelled)
                except Cancelled:
                    result.cancelled = True
                    return result
                except OSError as exc:
                    result.errors.append(f"Cannot read {entry.path}: {exc.strerror or exc}")
                    continue
                by_full[(entry.size, digest)].append(entry)
    finally:
        if own_cache:
            cache.close()

    groups = []
    for (size, digest), entries in by_full.items():
        if len(entries) < 2:
            continue
        entries.sort(key=lambda e: _keeper_score(e, preferred))
        groups.append(DuplicateGroup(id=0, size=size, sha256=digest, files=entries, keep=0))
    groups.sort(key=lambda g: (-(g.size * (len(g.files) - 1)), g.files[0].path))
    for i, g in enumerate(groups):
        g.id = i
    result.groups = groups
    progress.set(phase="Done", done=progress.total)
    return result


# ---------------------------------------------------------------------------
# Quarantine
# ---------------------------------------------------------------------------


@dataclass
class MoveOutcome:
    moved: List[dict] = field(default_factory=list)
    skipped: List[dict] = field(default_factory=list)
    sessions: List[str] = field(default_factory=list)

    @property
    def moved_bytes(self) -> int:
        return sum(m["size"] for m in self.moved)


def _unique_path(path: str) -> str:
    if not os.path.lexists(path):
        return path
    base, ext = os.path.splitext(path)
    i = 1
    while os.path.lexists(f"{base} ({i}){ext}"):
        i += 1
    return f"{base} ({i}){ext}"


def _move_verified(src: str, dst: str, expected_sha: Optional[str]) -> None:
    """Move src to dst. Same disk: instant rename. Other disk: copy, verify, delete."""
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    try:
        os.rename(src, dst)
        return
    except OSError as exc:
        import errno

        if exc.errno != errno.EXDEV:
            raise
    tmp = dst + ".partial"
    shutil.copyfile(src, tmp)
    if not files_identical(src, tmp):
        os.unlink(tmp)
        raise OSError("copy verification failed")
    try:
        shutil.copystat(src, tmp)
    except OSError:
        pass
    os.rename(tmp, dst)
    os.unlink(src)


class Quarantine:
    """One quarantine session per scan root, created lazily."""

    def __init__(self, stamp: Optional[str] = None):
        self.stamp = stamp or _dt.datetime.now().strftime("%Y-%m-%d %H-%M-%S")
        self.sessions: Dict[str, dict] = {}  # root -> manifest

    def session_dir(self, root: str) -> str:
        return os.path.join(root, QUARANTINE_DIR_NAME, self.stamp)

    def manifest_for(self, root: str) -> dict:
        if root not in self.sessions:
            d = self.session_dir(root)
            os.makedirs(d, exist_ok=True)
            self.sessions[root] = {
                "app": "Media Organizer",
                "created": _dt.datetime.now().isoformat(timespec="seconds"),
                "root": root,
                "entries": [],
            }
            _register_session(d)
            _write_readme(d)
        return self.sessions[root]

    def save(self, root: str) -> None:
        appdata.atomic_write_json(
            os.path.join(self.session_dir(root), "manifest.json"), self.sessions[root]
        )


def _write_readme(session_dir: str) -> None:
    text = (
        "This folder was created by Media Organizer.\n\n"
        "It contains exact duplicate copies of photos and videos. For every file\n"
        "in here, an identical copy (same bytes) was kept at the location listed\n"
        "in manifest.json under \"kept\".\n\n"
        "- To undo: open Media Organizer > Quarantine > Restore.\n"
        "- When you are happy, move this folder to the Trash to free the space.\n"
    )
    try:
        with open(os.path.join(session_dir, "READ ME.txt"), "w", encoding="utf-8") as f:
            f.write(text)
    except OSError:
        pass


def quarantine_duplicates(
    result: ScanResult,
    decisions: List[dict],
    progress: Optional[Progress] = None,
) -> MoveOutcome:
    """Move redundant copies into quarantine.

    decisions: [{"group": id, "keep": file_index, "skip": bool}]
    Groups without a decision are left untouched.
    """
    progress = progress or Progress()
    outcome = MoveOutcome()
    groups = {g.id: g for g in result.groups}
    work = []
    for d in decisions:
        g = groups.get(int(d.get("group", -1)))
        if g is None or d.get("skip"):
            continue
        keep = int(d.get("keep", g.keep))
        if not 0 <= keep < len(g.files):
            continue
        work.append((g, keep))

    total_bytes = sum(g.size * (len(g.files) - 1) for g, _ in work)
    progress.set(phase="Verifying byte by byte and moving to quarantine", done=0, total=total_bytes)
    quarantine = Quarantine()
    done = 0
    for g, keep in work:
        keeper = g.files[keep]
        for i, entry in enumerate(g.files):
            if i == keep:
                continue
            if progress.cancelled():
                break
            progress.set(current=entry.path)
            reason = _refuse_reason(entry, keeper)
            if reason is None and not files_identical(entry.path, keeper.path):
                reason = "Not identical to the kept copy any more (file changed since the scan)"
            if reason:
                outcome.skipped.append({"path": entry.path, "reason": reason})
                done += g.size
                progress.set(done=done)
                continue
            try:
                manifest = quarantine.manifest_for(entry.root)
                rel = os.path.relpath(entry.path, entry.root)
                target = _unique_path(os.path.join(quarantine.session_dir(entry.root), "files", rel))
                _move_verified(entry.path, target, g.sha256)
            except OSError as exc:
                outcome.skipped.append(
                    {"path": entry.path, "reason": f"Could not move: {exc.strerror or exc}"}
                )
                done += g.size
                progress.set(done=done)
                continue
            record = {
                "original": entry.path,
                "quarantined": target,
                "kept": keeper.path,
                "size": g.size,
                "sha256": g.sha256,
            }
            manifest["entries"].append(record)
            try:
                quarantine.save(entry.root)
            except OSError:
                pass
            outcome.moved.append(record)
            done += g.size
            progress.set(done=done)
        if progress.cancelled():
            break
    outcome.sessions = [quarantine.session_dir(r) for r in quarantine.sessions]
    return outcome


def _refuse_reason(entry: FileEntry, keeper: FileEntry) -> Optional[str]:
    if inside_protected_bundle(entry.path):
        return "Inside an app library (e.g. Photos Library) - never modified"
    try:
        s_entry = os.stat(entry.path)
        s_keep = os.stat(keeper.path)
    except FileNotFoundError:
        return "The kept copy or this file no longer exists"
    except OSError as exc:
        return f"Cannot read: {exc.strerror or exc}"
    if (s_entry.st_dev, s_entry.st_ino) == (s_keep.st_dev, s_keep.st_ino):
        return "Same physical file as the kept copy"
    if os.path.realpath(entry.path) == os.path.realpath(keeper.path):
        return "Same physical file as the kept copy"
    return None


# ---------------------------------------------------------------------------
# Session registry, restore and listing
# ---------------------------------------------------------------------------


def _register_session(session_dir: str) -> None:
    sessions = appdata.read_json(SESSIONS_FILE, [])
    if session_dir not in sessions:
        sessions.append(session_dir)
        appdata.write_json(SESSIONS_FILE, sessions)


def list_sessions() -> List[dict]:
    out = []
    for d in appdata.read_json(SESSIONS_FILE, []):
        manifest_path = os.path.join(d, "manifest.json")
        info = {"dir": d, "available": False, "files": 0, "bytes": 0, "created": ""}
        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                import json

                m = json.load(f)
            present = [e for e in m.get("entries", []) if os.path.exists(e["quarantined"])]
            info.update(
                available=True,
                created=m.get("created", ""),
                root=m.get("root", ""),
                files=len(present),
                bytes=sum(e.get("size", 0) for e in present),
            )
        except (OSError, ValueError, KeyError):
            info["missing_reason"] = (
                "Disk not connected" if d.startswith("/Volumes/") and not os.path.exists(d)
                else "Folder was deleted or moved"
            )
        out.append(info)
    out.sort(key=lambda s: s.get("created", ""), reverse=True)
    return out


def forget_session(session_dir: str) -> None:
    sessions = [s for s in appdata.read_json(SESSIONS_FILE, []) if s != session_dir]
    appdata.write_json(SESSIONS_FILE, sessions)


def restore_session(session_dir: str, progress: Optional[Progress] = None) -> MoveOutcome:
    import json

    progress = progress or Progress()
    outcome = MoveOutcome()
    manifest_path = os.path.join(session_dir, "manifest.json")
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)
    entries = manifest.get("entries", [])
    progress.set(phase="Restoring files", done=0, total=len(entries))
    remaining = []
    for i, e in enumerate(entries):
        progress.set(done=i, current=e["original"])
        src, dst = e["quarantined"], e["original"]
        if not os.path.exists(src):
            outcome.skipped.append({"path": src, "reason": "No longer in quarantine"})
            continue
        if os.path.lexists(dst):
            remaining.append(e)
            outcome.skipped.append(
                {"path": dst, "reason": "A file already exists at the original location"}
            )
            continue
        try:
            _move_verified(src, dst, e.get("sha256"))
        except OSError as exc:
            remaining.append(e)
            outcome.skipped.append({"path": src, "reason": f"Could not move back: {exc.strerror or exc}"})
            continue
        outcome.moved.append(e)
    manifest["entries"] = remaining
    appdata.atomic_write_json(manifest_path, manifest)
    if not remaining:
        _remove_empty_dirs(os.path.join(session_dir, "files"))
    progress.set(done=len(entries))
    return outcome


def _remove_empty_dirs(top: str) -> None:
    for dirpath, dirnames, filenames in os.walk(top, topdown=False):
        for name in filenames:
            if name == ".DS_Store":
                try:
                    os.unlink(os.path.join(dirpath, name))
                except OSError:
                    pass
        try:
            os.rmdir(dirpath)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Folder-level comparison
# ---------------------------------------------------------------------------


def _is_ancestor(a: str, b: str) -> bool:
    return b.startswith(a.rstrip(os.sep) + os.sep)


def folder_roots(path_a: str, path_b: str):
    """The two folders where two copies' paths stop being the same.

    /Disk/Photos/2023/IMG_1.JPG and /Disk/Backup/Photos/2023/IMG_1.JPG
    -> ("/Disk/Photos", "/Disk/Backup/Photos"): a whole backup tree is seen
    as one pair of folders instead of one pair per sub-folder.
    """
    a = os.path.dirname(path_a).split(os.sep)
    b = os.path.dirname(path_b).split(os.sep)
    same_name = os.path.basename(path_a) == os.path.basename(path_b)
    if same_name:
        while len(a) > 1 and len(b) > 1 and a[-1] == b[-1]:
            ra, rb = os.sep.join(a[:-1]), os.sep.join(b[:-1])
            if ra == rb or _is_ancestor(ra, rb) or _is_ancestor(rb, ra):
                break
            a, b = a[:-1], b[:-1]
    return os.sep.join(a) or os.sep, os.sep.join(b) or os.sep


def folder_comparison(result: ScanResult, limit: int = 200) -> List[dict]:
    """Which folders share identical files, and which side we suggest keeping."""
    pairs: Dict[tuple, dict] = {}
    for g in result.groups:
        seen_here = set()
        for i in range(len(g.files)):
            for j in range(i + 1, len(g.files)):
                ra, rb = folder_roots(g.files[i].path, g.files[j].path)
                key = (ra, rb) if ra <= rb else (rb, ra)
                if key in seen_here:
                    continue
                seen_here.add(key)
                p = pairs.setdefault(key, {"groups": [], "bytes": 0})
                p["groups"].append(g.id)
                p["bytes"] += g.size
    out = []
    for (a, b), p in pairs.items():
        out.append(_describe_pair(result, a, b, p["groups"], p["bytes"]))
    out.sort(key=lambda d: (-d["bytes"], -d["count"], d["a"]))
    return out[:limit]


def _side(path: str, a: str, b: str) -> Optional[str]:
    in_a, in_b = _is_within(path, a), _is_within(path, b)
    if in_a and in_b:  # one root contains the other: the deeper one wins
        return "a" if len(a) > len(b) else "b"
    return "a" if in_a else ("b" if in_b else None)


def _describe_same_folder(result: ScanResult, folder: str, group_ids: List[int], nbytes: int) -> dict:
    groups = {g.id: g for g in result.groups}
    skipped = sum(1 for gid in group_ids if groups[gid].skip)
    return {
        "a": folder,
        "b": folder,
        "same": True,
        "count": len(group_ids),
        "bytes": nbytes,
        "suggest": "a",
        "reason": "the same file is saved more than once in this folder",
        "current": {"a": len(group_ids) - skipped, "b": 0, "other": 0, "skip": skipped},
    }


def _in_same_folder(g: DuplicateGroup, folder: str) -> bool:
    return sum(1 for f in g.files if os.path.dirname(f.path) == folder) >= 2


def _describe_pair(result: ScanResult, a: str, b: str, group_ids: List[int], nbytes: int) -> dict:
    if a == b:
        return _describe_same_folder(result, a, group_ids, nbytes)
    groups = {g.id: g for g in result.groups}
    default_votes = {"a": 0, "b": 0}
    current = {"a": 0, "b": 0, "other": 0, "skip": 0}
    for gid in group_ids:
        g = groups[gid]
        # the automatic suggestion = copy ranked best by _keeper_score
        best = min(g.files, key=lambda e: _keeper_score(e, result.preferred))
        side = _side(best.path, a, b)
        if side:
            default_votes[side] += 1
        if g.skip:
            current["skip"] += 1
        else:
            side = _side(g.files[g.keep].path, a, b)
            current[side or "other"] += 1
    suggest = "a" if default_votes["a"] >= default_votes["b"] else "b"
    keep_root, other_root = (a, b) if suggest == "a" else (b, a)
    reason = _pair_reason(keep_root, other_root, result.preferred)
    return {
        "a": a,
        "b": b,
        "same": False,
        "count": len(group_ids),
        "bytes": nbytes,
        "suggest": suggest,
        "reason": reason,
        "current": current,
    }


def _pair_reason(keep: str, other: str, preferred: List[str]) -> str:
    if any(_is_within(keep, p) or keep == p for p in preferred):
        return "it is inside the folder you chose to keep first"
    # Only look at the part of the paths that differs (both may be on the Desktop).
    try:
        common = os.path.commonpath([keep, other])
    except ValueError:
        common = ""
    keep_rel, other_rel = keep[len(common):], other[len(common):]
    if _BACKUP_FOLDER.search(other_rel) and not _BACKUP_FOLDER.search(keep_rel):
        return "the other folder's name suggests a backup or copy"
    return "its copies look like the originals (older dates, no “copy” in the names)"


def keep_folder(result: ScanResult, keep_root: str, other_root: str) -> int:
    """Keep the copies in keep_root for every group shared with other_root.

    For duplicates inside one folder (keep_root == other_root) this means:
    remove the extra copies again, using the suggested copy to keep.
    """
    changed = 0
    if keep_root == other_root:
        for g in result.groups:
            if g.skip and _in_same_folder(g, keep_root):
                g.skip = False
                changed += 1
        return changed
    for g in result.groups:
        paths = [f.path for f in g.files]
        idx_keep = [i for i, p in enumerate(paths) if _side(p, keep_root, other_root) == "a"]
        has_other = any(_side(p, keep_root, other_root) == "b" for p in paths)
        if idx_keep and has_other:
            if g.keep not in idx_keep or g.skip:
                changed += 1
            if g.keep not in idx_keep:
                g.keep = idx_keep[0]
            g.skip = False
    return changed


def leave_pair_alone(result: ScanResult, root_a: str, root_b: str) -> int:
    changed = 0
    if root_a == root_b:
        for g in result.groups:
            if not g.skip and _in_same_folder(g, root_a):
                g.skip = True
                changed += 1
        return changed
    for g in result.groups:
        sides = {_side(f.path, root_a, root_b) for f in g.files}
        if "a" in sides and "b" in sides and not g.skip:
            g.skip = True
            changed += 1
    return changed
