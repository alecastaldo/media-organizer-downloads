"""Update the app in place, without deleting or copying folders by hand.

Where the new version comes from, in this order:
  1. If the app folder is a git checkout: `git pull`.
  2. The public downloads repository (DOWNLOAD_URL), directly.
  3. The newest Media Organizer download in ~/Downloads: a .zip downloaded
     with the browser, or the folder Safari unzips it into (fallback when the
     app cannot reach the internet by itself).

Only the app's own files are replaced. Your data (quarantine list, history,
settings) lives in ~/Library/Application Support/Media Organizer and inside
your archives, and is never touched. Nothing is replaced unless the new
version is complete (it must contain the app and its launcher).
"""

from __future__ import annotations

import io
import os
import re
import shutil
import subprocess
import tempfile
import urllib.error
import urllib.request
import zipfile
from typing import Dict, List, Optional, Tuple

from . import __version__

# Releases are published as a ZIP in a public "downloads" repository, so
# anyone can update (and download) without a GitHub account, while the
# source code repository itself can stay private.
DOWNLOADS_REPO = "alecastaldo/media-organizer-downloads"
RELEASE_ZIP = "Media-Organizer.zip"
DOWNLOAD_URL = (os.environ.get("MEDIA_ORGANIZER_UPDATE_URL")  # only for testing
                or f"https://raw.githubusercontent.com/{DOWNLOADS_REPO}/main/{RELEASE_ZIP}")
BROWSER_DOWNLOAD_URL = f"https://github.com/{DOWNLOADS_REPO}/raw/main/{RELEASE_ZIP}"
DOWNLOADS_PAGE = f"https://github.com/{DOWNLOADS_REPO}"

# Parts of the app folder that an update replaces. Anything else in the
# folder (your own notes, files you put there) is left alone.
MANAGED_DIRS = ("media_organizer", "tests", ".github")
MANAGED_FILES = ("README.md", "Media Organizer.command", "Update Media Organizer.command", ".gitignore")
REQUIRED = ("media_organizer/__init__.py", "media_organizer/server.py", "Media Organizer.command")


def app_dir() -> str:
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class UpdateError(ValueError):
    pass


# ---------------------------------------------------------------------------
# Reading a new version (zip bytes or an unzipped folder) into {path: bytes}
# ---------------------------------------------------------------------------


def _files_from_zip(data: bytes) -> Dict[str, bytes]:
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise UpdateError("The downloaded file is not a valid ZIP.")
    names = [n for n in zf.namelist() if not n.endswith("/")]
    # GitHub zips contain one top folder, e.g. "media_organizer-main/".
    prefix = os.path.commonprefix(names)
    prefix = prefix[: prefix.rfind("/") + 1] if "/" in prefix else ""
    files = {}
    for n in names:
        rel = n[len(prefix):]
        if not rel or rel.startswith("/") or ".." in rel.split("/") or "__MACOSX" in rel:
            continue  # never write outside the app folder
        files[rel] = zf.read(n)
    return files


def _files_from_folder(folder: str) -> Dict[str, bytes]:
    files = {}
    for d, dirs, names in os.walk(folder):
        dirs[:] = [x for x in dirs if x not in (".git", "__pycache__")]
        for n in names:
            if n == ".DS_Store" or n.endswith(".pyc"):
                continue
            p = os.path.join(d, n)
            with open(p, "rb") as f:
                files[os.path.relpath(p, folder).replace(os.sep, "/")] = f.read()
    return files


def version_of(files: Dict[str, bytes]) -> Optional[str]:
    m = re.search(rb'__version__\s*=\s*"([^"]+)"', files.get("media_organizer/__init__.py", b""))
    return m.group(1).decode() if m else None


def parse_version(v: Optional[str]) -> Tuple[int, ...]:
    try:
        return tuple(int(x) for x in (v or "0").split("."))
    except ValueError:
        return (0,)


def is_newer(files: Dict[str, bytes], current: str = __version__) -> bool:
    return parse_version(version_of(files)) > parse_version(current)


def _check_complete(files: Dict[str, bytes]) -> None:
    missing = [r for r in REQUIRED if r not in files]
    if missing:
        raise UpdateError("This download is not a complete Media Organizer (missing " + ", ".join(missing) + ").")


# ---------------------------------------------------------------------------
# Finding a new version
# ---------------------------------------------------------------------------


def download_from_github(timeout: int = 30) -> Optional[Dict[str, bytes]]:
    """The latest version from the public download page, or None if it is not reachable
    (private repository, no internet)."""
    try:
        with urllib.request.urlopen(DOWNLOAD_URL, timeout=timeout) as r:
            data = r.read()
    except (urllib.error.URLError, OSError, ValueError):
        return None
    try:
        files = _files_from_zip(data)
        _check_complete(files)
        return files
    except UpdateError:
        return None


def _looks_like_download(name: str) -> bool:
    n = name.lower()
    return n.startswith("media_organizer") or n.startswith("media-organizer") or n.startswith("media organizer")


def find_in_downloads(downloads: Optional[str] = None) -> Optional[Tuple[str, Dict[str, bytes]]]:
    """Newest complete Media Organizer zip or unzipped folder in Downloads."""
    downloads = downloads or os.path.expanduser("~/Downloads")
    here = os.path.realpath(app_dir())
    candidates = []
    try:
        entries = list(os.scandir(downloads))
    except OSError:
        return None
    for e in entries:
        if not _looks_like_download(e.name):
            continue
        if os.path.realpath(e.path) == here:
            continue  # the app itself may live in Downloads
        try:
            candidates.append((e.stat().st_mtime, e))
        except OSError:
            continue
    best = None
    for mtime, e in candidates:
        try:
            if e.is_file() and e.name.lower().endswith(".zip"):
                with open(e.path, "rb") as f:
                    files = _files_from_zip(f.read())
            elif e.is_dir():
                files = _files_from_folder(e.path)
            else:
                continue
            _check_complete(files)
        except (UpdateError, OSError):
            continue
        # highest version wins; for equal versions the newest download
        key = (parse_version(version_of(files)), mtime)
        if best is None or key > best[0]:
            best = (key, e.path, files)
    return (best[1], best[2]) if best else None


# ---------------------------------------------------------------------------
# Installing
# ---------------------------------------------------------------------------


def _managed(rel: str) -> bool:
    return rel in MANAGED_FILES or rel.split("/", 1)[0] in MANAGED_DIRS


def plan_changes(files: Dict[str, bytes], target: Optional[str] = None) -> Dict[str, List[str]]:
    target = target or app_dir()
    changed, added, removed = [], [], []
    for rel, data in files.items():
        if not _managed(rel):
            continue
        p = os.path.join(target, rel)
        try:
            with open(p, "rb") as f:
                if f.read() != data:
                    changed.append(rel)
        except FileNotFoundError:
            added.append(rel)
        except OSError:
            changed.append(rel)
    for top in MANAGED_DIRS:
        base = os.path.join(target, top)
        for d, dirs, names in os.walk(base):
            dirs[:] = [x for x in dirs if x != "__pycache__"]
            for n in names:
                if n.endswith(".pyc") or n == ".DS_Store":
                    continue
                rel = os.path.relpath(os.path.join(d, n), target).replace(os.sep, "/")
                if rel not in files:
                    removed.append(rel)
    return {"changed": sorted(changed), "added": sorted(added), "removed": sorted(removed)}


def install(files: Dict[str, bytes], target: Optional[str] = None) -> Dict[str, List[str]]:
    """Write the new version over the app folder. All files are first written
    next to their destination, then swapped in, so an interrupted update
    cannot leave half-written files."""
    target = target or app_dir()
    _check_complete(files)
    plan = plan_changes(files, target)
    writes = plan["changed"] + plan["added"]
    staged = []
    try:
        for rel in writes:
            dst = os.path.join(target, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=os.path.dirname(dst), prefix=".update-")
            with os.fdopen(fd, "wb") as f:
                f.write(files[rel])
            if rel.endswith((".command", ".sh")):
                os.chmod(tmp, 0o755)
            else:
                os.chmod(tmp, 0o644)
            staged.append((tmp, dst))
    except OSError as exc:
        for tmp, _ in staged:
            try:
                os.unlink(tmp)
            except OSError:
                pass
        raise UpdateError(f"Could not write the update: {exc.strerror or exc}")
    for tmp, dst in staged:
        os.replace(tmp, dst)
    for rel in plan["removed"]:
        try:
            os.unlink(os.path.join(target, rel))
        except OSError:
            pass
    for name in MANAGED_FILES:
        if name.endswith(".command") and os.path.exists(os.path.join(target, name)):
            try:  # keep the launchers double-clickable
                os.chmod(os.path.join(target, name), 0o755)
            except OSError:
                pass
    shutil.rmtree(os.path.join(target, "media_organizer", "__pycache__"), ignore_errors=True)
    return plan


def is_git_checkout(target: Optional[str] = None) -> bool:
    return os.path.isdir(os.path.join(target or app_dir(), ".git"))


def git_pull(target: Optional[str] = None) -> Tuple[bool, str]:
    target = target or app_dir()
    try:
        res = subprocess.run(["git", "-C", target, "pull", "--ff-only"],
                             capture_output=True, text=True, timeout=120)
    except (OSError, subprocess.SubprocessError) as exc:
        return False, str(exc)
    return res.returncode == 0, (res.stdout + res.stderr).strip()


def installed_version(target: Optional[str] = None) -> Optional[str]:
    try:
        with open(os.path.join(target or app_dir(), "media_organizer", "__init__.py"), "rb") as f:
            return version_of({"media_organizer/__init__.py": f.read()})
    except OSError:
        return None


PAGE = "the Media Organizer download page"


class Candidate:
    """A newer version that was found but NOT installed yet."""

    def __init__(self, version: str, source: str, kind: str, files: Dict[str, bytes],
                 file_date: Optional[float] = None):
        self.version, self.source, self.kind = version, source, kind
        self.files, self.file_date = files, file_date

    def describe(self) -> dict:
        return {"to": self.version, "source": self.source, "source_kind": self.kind,
                "file_date": self.file_date}


def check(downloads: Optional[str] = None, target: Optional[str] = None,
          use_page: bool = True, use_downloads: bool = False):
    """Look for a newer version. Nothing is installed.

    Returns (info, candidate). info["status"] is one of: "available",
    "up-to-date", "need-download" (page not reachable), "old-download" (the
    file found in Downloads is not newer), "not-found" (no download found).
    The Downloads folder is only searched when use_downloads is True, i.e.
    after the user said they downloaded the file themselves.
    """
    target = target or app_dir()
    # Compare with what is installed on disk (it may already be newer than
    # the running app if an update was installed but not restarted yet).
    current = installed_version(target) or __version__
    base = {"from": current, "download_url": BROWSER_DOWNLOAD_URL, "page_url": DOWNLOADS_PAGE}
    if is_git_checkout(target):
        return dict(base, status="available", to=None, source="git", source_kind="git"), \
            Candidate("", "git", "git", {})
    if use_downloads:
        found = find_in_downloads(downloads)
        if not found:
            return dict(base, status="not-found"), None
        path, files = found
        if not is_newer(files, current):
            return dict(base, status="old-download", to=version_of(files), source=path), None
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            mtime = None
        cand = Candidate(version_of(files) or "", path, "file", files, mtime)
        return dict(base, status="available", **cand.describe()), cand
    if use_page:
        files = download_from_github()
        if files is None:
            return dict(base, status="need-download"), None
        if not is_newer(files, current):
            return dict(base, status="up-to-date", to=version_of(files), source=PAGE), None
        cand = Candidate(version_of(files) or "", PAGE, "page", files)
        return dict(base, status="available", **cand.describe()), cand
    return dict(base, status="not-found"), None


def install_candidate(cand: "Candidate", target: Optional[str] = None) -> dict:
    """Install a version the user confirmed."""
    target = target or app_dir()
    current = installed_version(target) or __version__
    if cand.kind == "git":
        ok, out = git_pull(target)
        if not ok:
            raise UpdateError(f"git pull failed: {out}")
        return {"status": "updated", "from": current, "to": installed_version(target), "source": "git"}
    if not is_newer(cand.files, current):
        raise UpdateError("This version is not newer than the installed one any more.")
    plan = install(cand.files, target)
    return {"status": "updated", "source": cand.source, "from": current, "to": cand.version,
            "files": len(plan["changed"]) + len(plan["added"]) + len(plan["removed"])}


def update(downloads: Optional[str] = None, target: Optional[str] = None, use_github: bool = True,
           use_downloads: bool = False, confirm=lambda info: True) -> dict:
    """Check and, if the user confirms, install. Used by the command line."""
    info, cand = check(downloads, target, use_page=use_github, use_downloads=use_downloads)
    if cand is None:
        return info
    if not confirm(info):
        return dict(info, status="declined")
    return install_candidate(cand, target)
