"""Safe directory walking for internal and external disks."""

from __future__ import annotations

import os
import stat
from dataclasses import dataclass, field
from typing import Callable, Iterator, List, Optional

from .constants import (
    SKIP_DIR_NAMES,
    SKIP_FILE_NAMES,
    is_protected_bundle,
)


@dataclass
class FileEntry:
    path: str
    size: int
    mtime: float
    dev: int
    ino: int
    root: str  # the scan root this file was found under


@dataclass
class WalkReport:
    errors: List[str] = field(default_factory=list)
    skipped_bundles: List[str] = field(default_factory=list)


def normalize_root(path: str) -> str:
    path = os.path.expanduser(path.strip())
    return os.path.abspath(path)


def inside_protected_bundle(path: str) -> Optional[str]:
    """Return the protected library (e.g. Photos Library) containing path."""
    parts = os.path.abspath(path).split(os.sep)
    for i, part in enumerate(parts):
        if is_protected_bundle(part):
            return os.sep.join(parts[: i + 1])
    return None


def walk_files(
    roots: List[str],
    accept: Callable[[str], bool],
    report: WalkReport,
    skip_protected: bool = True,
    cancelled: Callable[[], bool] = lambda: False,
    on_dir: Callable[[str], None] = lambda d: None,
) -> Iterator[FileEntry]:
    """Yield every accepted regular file under the given roots, once.

    * Symbolic links are never followed.
    * Hidden macOS helper files ("._*", .DS_Store...) are ignored.
    * The same physical file reached twice (overlapping roots, hard links)
      is only yielded once - this is essential so a file is never compared
      with itself and reported as its own duplicate.
    """
    seen = set()
    # Longest roots first so a file gets attributed to the most specific root.
    for root in roots:
        stack = [root]
        while stack:
            if cancelled():
                return
            current = stack.pop()
            on_dir(current)
            try:
                with os.scandir(current) as it:
                    entries = list(it)
            except OSError as exc:
                report.errors.append(f"Cannot read folder {current}: {exc.strerror or exc}")
                continue
            entries.sort(key=lambda e: e.name)
            subdirs = []
            for entry in entries:
                name = entry.name
                try:
                    if entry.is_symlink():
                        continue
                    if entry.is_dir(follow_symlinks=False):
                        if name in SKIP_DIR_NAMES:
                            continue
                        if skip_protected and is_protected_bundle(name):
                            report.skipped_bundles.append(entry.path)
                            continue
                        subdirs.append(entry.path)
                        continue
                    if name.startswith("._") or name in SKIP_FILE_NAMES:
                        continue
                    if not accept(name):
                        continue
                    st = entry.stat(follow_symlinks=False)
                except OSError as exc:
                    report.errors.append(f"Cannot read {entry.path}: {exc.strerror or exc}")
                    continue
                if not stat.S_ISREG(st.st_mode):
                    continue
                key = (st.st_dev, st.st_ino)
                if key in seen:
                    continue
                seen.add(key)
                yield FileEntry(
                    path=entry.path,
                    size=st.st_size,
                    mtime=st.st_mtime,
                    dev=st.st_dev,
                    ino=st.st_ino,
                    root=root,
                )
            # reversed so folders are processed in alphabetical order
            stack.extend(reversed(subdirs))


def order_roots(roots: List[str]) -> List[str]:
    """Normalize, de-duplicate and order roots (most specific first)."""
    out = []
    for r in roots:
        if not r or not r.strip():
            continue
        n = normalize_root(r)
        if n not in out:
            out.append(n)
    out.sort(key=lambda p: (-p.count(os.sep), p))
    return out
