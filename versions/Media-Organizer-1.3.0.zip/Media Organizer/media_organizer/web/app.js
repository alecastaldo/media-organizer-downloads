/* Media Organizer - browser side. Talks only to the local app on 127.0.0.1. */
"use strict";

// ---------------------------------------------------------------- basics
const TOKEN = (() => {
  const m = location.hash.match(/t=([^&]+)/);
  let t = m ? m[1] : null;
  try {
    if (t) sessionStorage.setItem("mo-token", t);
    else t = sessionStorage.getItem("mo-token");
  } catch (e) { /* private mode */ }
  return t || "";
})();

const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g,
  (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function human(bytes) {
  const units = ["bytes", "KB", "MB", "GB", "TB"];
  let n = Number(bytes) || 0, u = 0;
  while (n >= 1000 && u < units.length - 1) { n /= 1000; u++; }
  return u === 0 ? `${n} bytes` : `${n.toFixed(n < 10 ? 2 : 1)} ${units[u]}`;
}
const srcLabel = (s) => (s === "metadata" ? "inside the file" : s);
const plural = (n, one, many) => `${Number(n).toLocaleString()} ${n === 1 ? one : (many || one + "s")}`;
function fmtDate(ts) {
  if (!ts) return "";
  return new Date(ts * 1000).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}
function fmtSecs(s) {
  s = Math.round(s || 0);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ${s % 60}s`;
  return `${Math.floor(m / 60)}h ${m % 60}m`;
}

async function api(path, body) {
  const opts = { headers: { "X-Token": TOKEN } };
  if (body !== undefined) {
    opts.method = "POST";
    opts.headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(body);
  }
  let res;
  try {
    res = await fetch(path, opts);
  } catch (e) {
    throw new Error("The app is not running any more. Start Media Organizer again (double-click “Media Organizer.command”).");
  }
  let data = {};
  try { data = await res.json(); } catch (e) { /* ignore */ }
  if (!res.ok || data.error) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function banner(message, kind) {
  const b = $("#banner");
  if (!message) { b.classList.add("hidden"); return; }
  b.className = "banner " + (kind || "");
  b.innerHTML = `${message} <button class="link" onclick="this.parentNode.classList.add('hidden')">Dismiss</button>`;
  window.scrollTo({ top: 0, behavior: "smooth" });
}
const showError = (e) => banner(esc(e.message || e), "err");

function confirmDialog(title, bodyHtml, okLabel, danger) {
  return new Promise((resolve) => {
    $("#dialog-title").textContent = title;
    $("#dialog-body").innerHTML = bodyHtml;
    const ok = $("#dialog-ok");
    ok.textContent = okLabel || "OK";
    ok.className = "btn primary" + (danger ? " danger" : "");
    $("#dialog").classList.remove("hidden");
    const done = (v) => { $("#dialog").classList.add("hidden"); ok.onclick = null; $("#dialog-cancel").onclick = null; resolve(v); };
    ok.onclick = () => done(true);
    $("#dialog-cancel").onclick = () => done(false);
  });
}

// ---------------------------------------------------------------- persistence (per browser)
const store = {
  get(k, d) { try { const v = localStorage.getItem("mo-" + k); return v ? JSON.parse(v) : d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem("mo-" + k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
};

// ---------------------------------------------------------------- tabs
function showTab(name) {
  $$(".tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === name));
  $$(".panel").forEach((p) => p.classList.toggle("hidden", p.id !== "tab-" + name));
  store.set("tab", name);
  if (name === "quarantine") loadSessions();
  if (name === "dates") loadDates();
  if (name === "help") loadSetupCheck(false);
}
$$(".tab").forEach((t) => t.addEventListener("click", () => showTab(t.dataset.tab)));

// ---------------------------------------------------------------- folder lists
const folders = {
  "dupe-roots": store.get("dupe-roots", []),
  "dupe-preferred": store.get("dupe-preferred", []),
  "imp-sources": store.get("imp-sources", []),
  "imp-dest": store.get("imp-dest", []),
  "dates-roots": store.get("dates-roots", []),
};
let INFO = { mac: true };

function renderFolders(id) {
  const box = document.getElementById(id);
  box.innerHTML = folders[id].map((p, i) =>
    `<div class="folder" data-i="${i}"><span>📁 ${esc(p)}</span>
      <button class="btn small x" data-remove="${id}" data-i="${i}" title="Remove from the list">Remove</button></div>`).join("");
  store.set(id, folders[id]);
  if (id === "imp-dest") loadArchiveInfo();
  // Warn about folders that are gone (e.g. a disk that is not connected)
  folders[id].forEach(async (p, i) => {
    try {
      const r = await api("/api/check-folder", { path: p });
      const el = box.querySelector(`.folder[data-i="${i}"]`);
      if (el && r.blocked) {
        el.classList.add("bad");
        el.firstElementChild.innerHTML = `🔒 ${esc(p)} <i>(macOS is blocking access)</i>
          <button class="link" onclick="openSettings('full-disk')">Allow access…</button>`;
      }
      if (el && !r.exists) {
        if (id === "imp-dest" && r.parent_exists) {
          el.firstElementChild.innerHTML = `📁 ${esc(p)} <i>(new folder — will be created)</i>`;
        } else {
          el.classList.add("bad");
          el.firstElementChild.innerHTML = `⚠️ ${esc(p)} <i>(not found — disk not connected?)</i>`;
        }
      }
    } catch (e) { /* ignore */ }
  });
}

function addFolder(id, path, single) {
  path = (path || "").trim();
  if (!path) return;
  if (path.length > 1) path = path.replace(/\/+$/, "");
  if (single) folders[id] = [path];
  else if (!folders[id].includes(path)) folders[id].push(path);
  renderFolders(id);
  if (id === "imp-dest") refreshTree();
}

document.addEventListener("click", async (ev) => {
  const rm = ev.target.closest("[data-remove]");
  if (rm) {
    folders[rm.dataset.remove].splice(Number(rm.dataset.i), 1);
    renderFolders(rm.dataset.remove);
    return;
  }
  const pick = ev.target.closest("[data-pick]");
  if (pick) {
    const id = pick.dataset.pick, single = !!pick.dataset.single;
    if (INFO.mac) {
      pick.disabled = true;
      try {
        const prompt = single ? pick.textContent.replace(/[＋…]/g, "").trim()
          : "Choose one or more folders (hold ⌘ to select several)";
        const r = await api("/api/choose-folder", { prompt, multiple: !single });
        if (r.path) addFolder(id, r.path, single);
        (r.paths || []).forEach((p) => addFolder(id, p, false));
      } catch (e) { showError(e); }
      pick.disabled = false;
    }
    showTypePath(pick, id, single);
    return;
  }
  const chip = ev.target.closest("[data-place]");
  if (chip) {
    const host = chip.closest("[data-places]");
    addFolder(host.dataset.places, chip.dataset.place, !!host.dataset.single);
  }
});

// A small "type or paste paths" box, for when the Finder picker is not wanted.
// Several folders can be pasted at once, one per line (in Finder: select
// folders and press ⌥⌘C to copy their paths).
function showTypePath(btn, id, single) {
  const row = btn.closest(".row");
  if (row.querySelector(".type-path")) return;
  const div = document.createElement("div");
  div.className = "type-path";
  div.innerHTML = single
    ? `<input placeholder="…or type/paste a folder path, e.g. /Volumes/MyDisk/Photos"><button class="btn small">Add</button>`
    : `<textarea rows="2" placeholder="…or paste one or more folder paths, one per line.  Tip: select folders in Finder and press ⌥⌘C to copy their paths."></textarea><button class="btn small">Add</button>`;
  const input = div.querySelector("input, textarea");
  const go = async () => {
    const lines = input.value.split(/\r?\n/).map((l) => l.trim().replace(/^["']|["']$/g, "")).filter(Boolean);
    if (!lines.length) return;
    const missing = [];
    for (const v of lines) {
      try {
        const r = await api("/api/check-folder", { path: v });
        if (r.blocked) { showBlocked(r.path); }
        if (!r.exists && !(id === "imp-dest" && r.parent_exists)) { missing.push(r.path); continue; }
        addFolder(id, r.path, single);
      } catch (e) { showError(e); return; }
    }
    input.value = missing.join("\n");
    if (missing.length) banner("Folder not found: " + missing.map((m) => `<code>${esc(m)}</code>`).join(", "), "err");
  };
  div.querySelector("button").onclick = go;
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && (single || e.metaKey || e.ctrlKey)) { e.preventDefault(); go(); }
  });
  row.appendChild(div);
}

async function loadPlaces() {
  try {
    const { places } = await api("/api/places");
    $$("[data-places]").forEach((host) => {
      const disks = places.filter((p) => p.kind === "disk");
      const list = host.dataset.places === "dupe-roots" || host.dataset.places === "imp-sources"
        ? places.filter((p) => p.kind === "disk" || ["Pictures", "Movies", "Downloads"].includes(p.label))
        : disks.concat(places.filter((p) => p.label === "Pictures"));
      host.innerHTML = list.map((p) =>
        `<button class="chip ${p.kind}" data-place="${esc(p.path)}" title="${esc(p.path)}${p.free != null ? " · " + human(p.free) + " free" : ""}">${esc(p.label)}</button>`).join("");
    });
  } catch (e) { /* ignore */ }
}

// ---------------------------------------------------------------- jobs
let pollTimer = null;
let onJobDone = null;

function watchJob(after) {
  onJobDone = after;
  $("#job").classList.remove("hidden");
  $("#job-cancel").disabled = false;
  $("#job-cancel").textContent = "Cancel";
  poll();
}

async function poll() {
  clearTimeout(pollTimer);
  let job;
  try { ({ job } = await api("/api/job")); } catch (e) { showError(e); $("#job").classList.add("hidden"); return; }
  if (!job) { $("#job").classList.add("hidden"); return; }
  $("#job-phase").textContent = job.phase || "Working…";
  const bar = $("#job-bar").parentNode;
  const isBytes = /Comparing full|Copying|Checking|Verifying/.test(job.phase);
  if (job.total > 0) {
    bar.classList.remove("indeterminate");
    const pct = Math.min(100, (100 * job.done) / job.total);
    $("#job-bar").style.width = pct.toFixed(1) + "%";
    $("#job-count").textContent = isBytes
      ? `${human(job.done)} of ${human(job.total)} (${pct.toFixed(0)}%)`
      : `${job.done.toLocaleString()} of ${job.total.toLocaleString()}`;
  } else {
    bar.classList.add("indeterminate");
    $("#job-bar").style.width = "";
    $("#job-count").textContent = job.done ? `${job.done.toLocaleString()} files found` : "";
  }
  $("#job-time").textContent = fmtSecs(job.elapsed);
  $("#job-current").textContent = job.current || "";
  if (job.state === "running") {
    pollTimer = setTimeout(poll, 500);
    return;
  }
  $("#job").classList.add("hidden");
  if (job.state === "failed") banner(esc(job.error), "err");
  else if (job.state === "cancelled") banner("Cancelled. Nothing more was changed.", "");
  const cb = onJobDone;
  onJobDone = null;
  if (cb) cb(job);
}

$("#job-cancel").addEventListener("click", async () => {
  $("#job-cancel").disabled = true;
  $("#job-cancel").textContent = "Stopping safely…";
  try { await api("/api/job/cancel", {}); } catch (e) { /* ignore */ }
});

// ---------------------------------------------------------------- duplicates
let dupePage = 0;
let pairsTimer = null;
let pairsExpanded = false;
const PER_PAGE = 25;

$("#scan-btn").addEventListener("click", async () => {
  banner("");
  if (!folders["dupe-roots"].length) { banner("Please add at least one folder or disk to scan.", "err"); return; }
  try {
    await api("/api/duplicates/scan", { roots: folders["dupe-roots"], preferred: folders["dupe-preferred"] });
    dupePage = 0;
    pairsExpanded = false;
    watchJob(() => loadDuplicates());
  } catch (e) { showError(e); }
});

async function loadDuplicates() {
  let data;
  try { data = await api(`/api/duplicates?page=${dupePage}&per=${PER_PAGE}`); } catch (e) { showError(e); return; }
  renderDuplicates(data);
}

function renderDuplicates({ scan, last_apply }) {
  const box = $("#dupe-results");
  $(".applybar") && $(".applybar").remove();
  if (!scan) { box.innerHTML = ""; return; }
  let html = "";
  if (last_apply) {
    html += `<div class="notice ok"><b>${plural(last_apply.moved, "extra copy", "extra copies")} moved to quarantine
      (${human(last_apply.moved_bytes)}).</b> You can restore them any time in
      <button class="link" onclick="showTab('quarantine')">Quarantine &amp; undo</button>.`;
    if (last_apply.skipped.length) {
      html += `<br><br><b>${plural(last_apply.skipped.length, "file was", "files were")} left untouched for safety:</b><ul>` +
        last_apply.skipped.map((s) => `<li><code>${esc(s.path)}</code> — ${esc(s.reason)}</li>`).join("") + "</ul>";
    }
    html += `</div>`;
  }
  html += `<div class="card"><h2>2 · Results</h2>
    <div class="stats">
      <div class="stat"><b>${scan.files_scanned.toLocaleString()}</b><span>photos &amp; videos checked (${human(scan.bytes_scanned)})</span></div>
      <div class="stat"><b>${scan.group_count.toLocaleString()}</b><span>files that exist more than once</span></div>
      <div class="stat"><b>${scan.redundant_files.toLocaleString()}</b><span>extra identical copies</span></div>
      <div class="stat"><b>${human(scan.redundant_bytes)}</b><span>space you can free</span></div>
    </div>`;
  if (scan.cancelled) html += `<div class="notice">The scan was cancelled, so these results are incomplete.</div>`;
  if (scan.skipped_bundles.length) {
    html += `<div class="notice">These app libraries were skipped on purpose (files inside them must only be managed by their app):<ul>` +
      scan.skipped_bundles.map((p) => `<li><code>${esc(p)}</code></li>`).join("") + `</ul></div>`;
  }
  if (scan.errors.length) {
    html += `<details class="notice"><summary>${plural(scan.errors.length, "file or folder", "files or folders")} could not be read (click for details)</summary><ul>` +
      scan.errors.map((e) => `<li>${esc(e)}</li>`).join("") + `</ul>
      <p>If these are on an external disk or in a protected folder, allow access in System Settings ▸ Privacy &amp; Security ▸ Full Disk Access (Terminal), then scan again.</p></details>`;
  }
  if (!scan.group_count) {
    html += `<div class="notice ok">🎉 No duplicates found. Every photo and video in these folders exists only once.</div></div>`;
    box.innerHTML = html;
    return;
  }
  html += `<p class="hint">Each box below is one photo or video that exists several times with <b>exactly the same bytes</b>.
    The copy marked <b style="color:var(--keep)">KEEP</b> stays where it is; the others are moved to a quarantine folder (not deleted).
    Click another copy to keep that one instead. Biggest space savings are shown first.</p></div>`;

  const pages = Math.ceil(scan.group_count / scan.per);
  const pager = pages > 1 ? `<div class="pager">
      <button class="btn small" data-page="${scan.page - 1}" ${scan.page <= 0 ? "disabled" : ""}>‹ Previous</button>
      <span>Page ${scan.page + 1} of ${pages}</span>
      <button class="btn small" data-page="${scan.page + 1}" ${scan.page >= pages - 1 ? "disabled" : ""}>Next ›</button></div>` : "";
  // keep the previous folder panel visible while the new one loads (no flicker)
  const oldPairs = $("#folder-pairs") ? $("#folder-pairs").innerHTML : "";
  html += `<div id="folder-pairs">${oldPairs}</div>`;
  html += pager;
  for (const g of scan.groups) {
    html += `<div class="group ${g.skip ? "skipped" : ""}" data-group="${g.id}">
      <div class="group-head"><span><b>${plural(g.files.length, "identical copy", "identical copies")}</b> · ${human(g.size)} each ·
        frees ${human(g.size * (g.files.length - 1))}</span>
        <label class="check"><input type="checkbox" class="skip" ${g.skip ? "checked" : ""}> Leave this one alone</label></div>
      <div class="group-body">
        <div class="thumb"><img loading="lazy" alt="" src="/api/thumb?g=${g.id}&i=0&t=${encodeURIComponent(TOKEN)}"
           onerror="this.replaceWith(document.createTextNode('${g.is_video ? "🎬 video" : "No preview"}'))"></div>
        <div class="copies">` +
      g.files.map((f) => `
          <label class="copy ${f.index === g.keep ? "keep" : ""}">
            <input type="radio" name="keep-${g.id}" value="${f.index}" ${f.index === g.keep ? "checked" : ""}>
            <span class="p"><b>${esc(f.name)}</b><br>${esc(f.folder)}<br><span style="color:var(--muted)">${f.taken ? `taken ${esc(f.taken)}` : "no date inside the file"} · file date ${fmtDate(f.mtime)}${f.exists ? "" : " · ⚠️ missing"}</span></span>
            <span class="tag">${f.index === g.keep ? "KEEP" : (g.skip ? "stays" : "to quarantine")}</span>
            <span class="actions">
              <button type="button" class="link" data-reveal="${g.id}:${f.index}" title="Show in Finder">Finder</button>
              <button type="button" class="link" data-open="${g.id}:${f.index}" title="Open">Open</button>
            </span>
          </label>`).join("") +
      `</div></div></div>`;
  }
  html += pager;
  box.innerHTML = html;

  const bar = document.createElement("div");
  bar.className = "applybar";
  bar.innerHTML = `<div class="applybar-inner">
    <span><b>${plural(scan.selected_files, "extra copy", "extra copies")}</b> selected · ${human(scan.selected_bytes)}
      <span style="color:var(--muted)">(all pages)</span></span>
    <button class="btn primary" id="apply-btn" ${scan.selected_files ? "" : "disabled"}>Move extra copies to quarantine…</button></div>`;
  document.body.appendChild(bar);
  $("#apply-btn").onclick = () => applyDuplicates(scan);
  loadFolderPairs();
}

function updateSelected(r) {
  if (!r || r.selected_files == null) return;
  const bar = $(".applybar");
  if (!bar) return;
  bar.querySelector("span").innerHTML = `<b>${plural(r.selected_files, "extra copy", "extra copies")}</b> selected · ${human(r.selected_bytes)}
    <span style="color:var(--muted)">(all pages)</span>`;
  $("#apply-btn").disabled = !r.selected_files;
}

// Update one group on screen without reloading the page.
function paintGroup(groupEl) {
  const skip = groupEl.querySelector(".skip").checked;
  groupEl.classList.toggle("skipped", skip);
  groupEl.querySelectorAll(".copy").forEach((c) => {
    const keep = c.querySelector("input").checked;
    c.classList.toggle("keep", keep);
    c.querySelector(".tag").textContent = keep ? "KEEP" : (skip ? "stays" : "to quarantine");
  });
}

const shortName = (p) => {
  const parts = p.split("/").filter(Boolean);
  return parts.length ? parts.slice(-2).join("/") : "/";
};

async function loadFolderPairs() {
  const box = $("#folder-pairs");
  if (!box) return;
  let folders;
  try { ({ folders } = await api("/api/duplicates/folders")); } catch (e) { return; }
  if (!folders.length) { box.innerHTML = ""; return; }
  let html = `<div class="card"><h2>Folders that contain the same files (${folders.length})</h2>
    <p class="hint">Each row compares two folders. Choose which folder keeps its copies; the identical copies in the other
      folder go to quarantine. You can still fine-tune single files below.</p>`;
  const renderPair = (f, i) => {
    if (f.same) {
      const alone = f.current.skip === f.count;
      return `<div class="pair" data-pair="${i}">
      <div class="pair-folders one"><div class="pf ${alone ? "neutral" : "sug"}"><span class="num">📁</span><div><b>${esc(shortName(f.a))}</b><div class="p">${esc(f.a)}</div></div></div></div>
      <div class="pair-info">Inside this one folder, <b>${plural(f.count, "file is", "files are")} saved more than once</b> (${human(f.bytes)} could be freed).<br>
        <span class="sugg">Suggestion: keep one copy of each</span>.<br>
        <small class="muted">${alone ? "Left alone" : f.current.skip ? `${f.current.skip} left alone` : "Extra copies will go to quarantine"}</small></div>
      <div class="row">
        <button class="btn small ${alone ? "" : "primary"}" data-keepfolder="a">${alone ? "" : "✓ "}Keep one copy of each (suggested)</button>
        <button class="btn small ${alone ? "primary" : ""}" data-leavepair="1">${alone ? "✓ " : ""}Leave them alone</button>
      </div></div>`;
    }
    const keepA = f.suggest === "a";
    const cur = f.current;
    const side = cur.skip === f.count ? "none" : cur.a === f.count ? "a" : cur.b === f.count ? "b" : "mixed";
    const cls = (x) => side === x ? "sug" : (side === "none" || side === "mixed" ? "neutral" : "");
    const state = cur.skip === f.count ? "Both folders are left alone"
      : cur.a === f.count ? `Currently keeping the copies in <b>${esc(shortName(f.a))}</b>`
      : cur.b === f.count ? `Currently keeping the copies in <b>${esc(shortName(f.b))}</b>`
      : `Currently mixed: ${cur.a} kept in folder 1, ${cur.b} in folder 2${cur.skip ? `, ${cur.skip} left alone` : ""}${cur.other ? `, ${cur.other} elsewhere` : ""}`;
    const inside = f.b.startsWith(f.a + "/") ? " (files directly in it, not in folder 2)" : "";
    const inside2 = f.a.startsWith(f.b + "/") ? " (files directly in it, not in folder 1)" : "";
    return `<div class="pair" data-pair="${i}">
      <div class="pair-folders">
        <div class="pf ${cls("a")}"><span class="num">1</span><div><b>${esc(shortName(f.a))}</b>${esc(inside)}<div class="p">${esc(f.a)}</div></div></div>
        <div class="pf ${cls("b")}"><span class="num">2</span><div><b>${esc(shortName(f.b))}</b>${esc(inside2)}<div class="p">${esc(f.b)}</div></div></div>
      </div>
      <div class="pair-info">
        Folders 1 and 2 share <b>${plural(f.count, "identical file")}</b> (${human(f.bytes)} could be freed).<br>
        <span class="sugg">Suggestion: keep only the copies in folder ${keepA ? 1 : 2}</span> — ${esc(f.reason)}.<br>
        <small class="muted">${state}</small>
      </div>
      <div class="row">
        <button class="btn small ${side === "a" ? "primary" : ""}" data-keepfolder="a">${side === "a" ? "✓ " : ""}Keep copies in folder 1${keepA ? " (suggested)" : ""}</button>
        <button class="btn small ${side === "b" ? "primary" : ""}" data-keepfolder="b">${side === "b" ? "✓ " : ""}Keep copies in folder 2${keepA ? "" : " (suggested)"}</button>
        <button class="btn small ${side === "none" ? "primary" : ""}" data-leavepair="1">${side === "none" ? "✓ " : ""}Leave both alone</button>
      </div></div>`;
  };
  const SHOW = 12;
  html += folders.slice(0, pairsExpanded ? folders.length : SHOW).map(renderPair).join("");
  if (folders.length > SHOW && !pairsExpanded) {
    html += `<div class="row"><button class="btn small" id="pairs-more">Show all ${folders.length} folder comparisons</button></div>`;
  }
  html += `</div>`;
  box.innerHTML = html;
  const more = $("#pairs-more");
  if (more) more.onclick = () => { pairsExpanded = true; loadFolderPairs(); };
  box.querySelectorAll("[data-pair]").forEach((el) => {
    const f = folders[Number(el.dataset.pair)];
    el.addEventListener("click", async (ev) => {
      const b = ev.target.closest("button");
      if (!b) return;
      try {
        if (b.dataset.keepfolder) {
          const [keep, other] = b.dataset.keepfolder === "a" ? [f.a, f.b] : [f.b, f.a];
          await api("/api/duplicates/keep-folder", { keep, other });
        } else {
          await api("/api/duplicates/leave-pair", { a: f.a, b: f.b });
        }
        const y = window.scrollY;
        await loadDuplicates();
        window.scrollTo({ top: y });
      } catch (e) { showError(e); }
    });
  });
}

$("#dupe-results").addEventListener("change", async (ev) => {
  const groupEl = ev.target.closest("[data-group]");
  if (!groupEl) return;
  const group = Number(groupEl.dataset.group);
  paintGroup(groupEl);  // instant feedback; the server is told in the background
  try {
    let r = null;
    if (ev.target.type === "radio") r = await api("/api/duplicates/keep", { group, keep: Number(ev.target.value) });
    else if (ev.target.classList.contains("skip")) r = await api("/api/duplicates/keep", { group, skip: ev.target.checked });
    updateSelected(r);
    clearTimeout(pairsTimer);
    pairsTimer = setTimeout(loadFolderPairs, 400);
  } catch (e) { showError(e); loadDuplicates(); }
});

$("#dupe-results").addEventListener("click", async (ev) => {
  const pg = ev.target.closest("[data-page]");
  if (pg) { dupePage = Number(pg.dataset.page); await loadDuplicates(); window.scrollTo({ top: $("#dupe-results").offsetTop - 120 }); return; }
  const btn = ev.target.closest("[data-reveal],[data-open]");
  if (btn) {
    ev.preventDefault();
    const [group, index] = (btn.dataset.reveal || btn.dataset.open).split(":").map(Number);
    try { await api(btn.dataset.reveal ? "/api/reveal" : "/api/open", { group, index }); } catch (e) { showError(e); }
  }
});

async function applyDuplicates(scan) {
  const ok = await confirmDialog(
    "Move extra copies to quarantine?",
    `<p><b>${plural(scan.selected_files, "file", "files")}</b> (${human(scan.selected_bytes)}) will be moved into
      “Duplicates Quarantine (Media Organizer)” inside the scanned folder.</p>
     <ul><li>One copy of every photo/video is always kept in place.</li>
       <li>Each file is compared <b>byte by byte</b> with the kept copy again right before it is moved. If anything differs, it is left alone.</li>
       <li>Nothing is deleted. You can restore everything from the “Quarantine &amp; undo” tab.</li></ul>`,
    "Move to quarantine");
  if (!ok) return;
  try {
    await api("/api/duplicates/apply", {});
    watchJob(() => { dupePage = 0; loadDuplicates(); });
  } catch (e) { showError(e); }
}

// ---------------------------------------------------------------- import
$("#icloud-btn").addEventListener("click", async () => {
  const box = $("#icloud-info");
  try {
    const { libraries } = await api("/api/photos-libraries");
    if (!libraries.length) {
      box.innerHTML = `<div class="notice">No Photos library was found in your Pictures folder or on connected disks.
        If yours is somewhere else, use “Add folder…” and choose the <code>originals</code> folder inside it.</div>`;
      return;
    }
    box.innerHTML = libraries.map((l) => `<div class="notice ${l.readable ? "ok" : ""}">
        <b>${esc(l.library.split("/").pop())}</b> <span style="color:var(--muted)">${esc(l.library)}</span><br>
        ${l.readable
          ? `<button class="btn small" data-lib="${esc(l.originals)}">Import from this library</button>
             <br><small>Only photos already downloaded to this Mac can be copied. In Photos ▸ Settings ▸ iCloud choose
             “Download Originals to this Mac” and let it finish first. Edited versions are not included, only originals.</small>`
          : `macOS does not allow the app to read this library yet. Open <b>System Settings ▸ Privacy &amp; Security ▸
             Full Disk Access</b>, turn on <b>Terminal</b>, then quit and restart Media Organizer.`}</div>`).join("");
    $$("[data-lib]", box).forEach((b) => b.onclick = () => { addFolder("imp-sources", b.dataset.lib); box.innerHTML = ""; });
  } catch (e) { showError(e); }
});

const impOptions = ["imp-layout", "imp-camera", "imp-rename", "imp-undated", "imp-events", "imp-setdates"];
impOptions.forEach((id) => {
  const el = document.getElementById(id);
  const saved = store.get(id, null);
  if (saved !== null) { if (el.type === "checkbox") el.checked = saved; else el.value = saved; }
  el.addEventListener("change", () => {
    store.set(id, el.type === "checkbox" ? el.checked : el.value);
    refreshTree();
  });
});

function currentOptions() {
  return {
    layout: $("#imp-layout").value,
    by_camera: $("#imp-camera").checked,
    rename: $("#imp-rename").checked,
    undated_folder: $("#imp-undated").checked,
    keep_event_names: $("#imp-events").checked,
  };
}

// ---------------------------------------------------------------- analysis
let hasAnalysis = false;

$("#analyze-btn").addEventListener("click", async () => {
  banner("");
  if (!folders["imp-sources"].length) { banner("Please add the folder(s) to analyze first (step 1).", "err"); return; }
  try {
    await api("/api/analyze/start", { sources: folders["imp-sources"], destination: folders["imp-dest"][0] || "" });
    watchJob(() => loadAnalysis(true));
  } catch (e) { showError(e); }
});

const OPTION_INPUTS = { by_camera: "imp-camera", rename: "imp-rename", undated_folder: "imp-undated", keep_event_names: "imp-events" };

async function loadAnalysis(applySuggestion) {
  let data;
  try { data = await api("/api/analysis"); } catch (e) { showError(e); return; }
  const a = data.analysis;
  hasAnalysis = !!a;
  if (!a) return;
  const rec = a.recommendation, s = a.summary;
  if (applySuggestion) {
    $("#imp-layout").value = rec.layout;
    for (const [k, id] of Object.entries(OPTION_INPUTS)) document.getElementById(id).checked = !!rec[k];
    impOptions.forEach((id) => { const el = document.getElementById(id); store.set(id, el.type === "checkbox" ? el.checked : el.value); });
  }
  $$("[data-reason]").forEach((el) => {
    const k = el.dataset.reason;
    el.textContent = rec.reasons[k] || "";
    el.className = "reason " + (k === "layout" || rec[k] ? "rec" : "not");
  });
  renderAnalysis(s);
  refreshTree();
}

function barList(pairs, fmt) {
  const max = Math.max(1, ...pairs.map((p) => p[1]));
  return `<div class="bars">` + pairs.map(([k, v]) =>
    `<span>${esc(k)}</span><div><div class="b" style="width:${(100 * v / max).toFixed(1)}%"></div></div><span>${fmt ? fmt(v) : v.toLocaleString()}</span>`).join("") + `</div>`;
}

function renderAnalysis(s) {
  const ds = s.date_sources || {};
  let html = `<div class="notice ok" style="margin-top:14px"><b>Analysis of ${plural(s.files, "file")} (${human(s.bytes)})</b> —
    ${plural(s.photos, "photo")}, ${plural(s.videos, "video")}${s.first ? `, taken from ${esc(s.first)} to ${esc(s.last)}` : ""}.
    The suggested settings are selected below; change anything you like and the preview updates.</div>`;
  if (s.cancelled) html += `<div class="notice">The analysis was cancelled, so it is incomplete.</div>`;
  html += `<div class="cols">
    <div><h3>Files per year</h3>${barList(s.years.map(([y, n]) => [String(y), n]))}</div>
    <div><h3>Devices</h3>${barList(s.families)}
      <h3>Where the date comes from</h3>${barList([["Inside the file", ds.metadata || 0], ["Photos library", ds["Photos library"] || 0], ["File name", ds["file name"] || 0], ["File date only", ds["file date"] || 0]].filter((x, i) => i !== 1 || x[1]))}</div>
    ${s.events.length ? `<div><h3>Named folders found</h3>${barList(s.events)}</div>` : ""}
  </div>`;
  if (s.skipped_bundles.length) {
    html += `<div class="notice">Skipped app libraries (use the iCloud Photos button to include the Photos library):<ul>` +
      s.skipped_bundles.map((p) => `<li><code>${esc(p)}</code></li>`).join("") + `</ul></div>`;
  }
  if (s.errors.length) {
    html += `<details class="notice"><summary>${plural(s.errors.length, "item")} could not be read</summary><ul>` +
      s.errors.map((e) => `<li>${esc(e)}</li>`).join("") + `</ul></details>`;
  }
  $("#analysis").innerHTML = html;
}

let treeTimer = null;
function refreshTree() {
  if (!hasAnalysis) return;
  clearTimeout(treeTimer);
  treeTimer = setTimeout(async () => {
    try {
      const { tree } = await api("/api/analyze/preview", Object.assign(currentOptions(), { destination: folders["imp-dest"][0] || "" }));
      renderTree(tree);
    } catch (e) { showError(e); }
  }, 150);
}

function renderTree(tree) {
  const node = (n, depth) => {
    const label = `📁 ${esc(n.name)} <span class="n">— ${plural(n.count, "file")}, ${human(n.bytes)}</span>`;
    if (!n.children.length) {
      return `<div class="leaf">${label}${n.samples.map((x) => `<div class="f">${esc(x)}</div>`).join("")}${n.count > n.samples.length ? `<div class="f">…</div>` : ""}</div>`;
    }
    return `<details ${depth < 1 ? "open" : ""}><summary>${label}</summary>` +
      n.children.map((c) => node(c, depth + 1)).join("") +
      (n.more ? `<div class="f">…and ${plural(n.more, "more folder")}</div>` : "") + `</details>`;
  };
  $("#tree").innerHTML = `<h3>Proposed structure <span class="n" style="font-weight:normal;color:var(--muted)">(${plural(tree.folder_count, "folder")})</span></h3>
    <div class="tree">${node(tree, 0)}</div>`;
}

async function startImport(dryRun) {
  banner("");
  if (!folders["imp-sources"].length) { banner("Please add the folder(s) to import from.", "err"); return; }
  if (!folders["imp-dest"].length) { banner("Please choose your archive folder.", "err"); return; }
  if (!dryRun) {
    const ok = await confirmDialog("Copy into the archive?",
      `<p>Photos and videos will be <b>copied</b> into <code>${esc(folders["imp-dest"][0])}</code>.</p>
       <ul><li>Your source files are not changed or deleted.</li>
       <li>Nothing in the archive is overwritten; files already there are skipped.</li>
       <li>Every copy is read back and verified.</li></ul>`, "Start copying");
    if (!ok) return;
  }
  try {
    await api("/api/import/start", {
      sources: folders["imp-sources"],
      destination: folders["imp-dest"][0],
      layout: $("#imp-layout").value,
      by_camera: $("#imp-camera").checked,
      rename: $("#imp-rename").checked,
      undated_folder: $("#imp-undated").checked,
      keep_event_names: $("#imp-events").checked,
      set_dates: $("#imp-setdates").checked,
      dry_run: dryRun,
    });
    watchJob(() => loadImport());
  } catch (e) { showError(e); }
}
$("#preview-btn").addEventListener("click", () => startImport(true));
$("#import-btn").addEventListener("click", () => startImport(false));

let importFilter = "all";
let lastImport = null;

async function loadImport() {
  try { lastImport = (await api("/api/import")).result; } catch (e) { showError(e); return; }
  renderImport();
}

function renderImport() {
  const r = lastImport, box = $("#import-results");
  if (!r) { box.innerHTML = ""; return; }
  const c = r.counts, b = r.bytes;
  let html = `<div class="card"><h2>${r.dry_run ? "Preview — nothing was copied yet" : "Import finished"}</h2>`;
  if (r.cancelled) html += `<div class="notice">Cancelled before the end. Files already copied are complete and verified.</div>`;
  html += `<div class="stats">
    ${r.dry_run
      ? `<div class="stat"><b>${c["would copy"].toLocaleString()}</b><span>would be copied (${human(b["would copy"])})</span></div>`
      : `<div class="stat"><b>${c.copied.toLocaleString()}</b><span>copied &amp; verified (${human(b.copied)})</span></div>`}
    <div class="stat"><b>${c.duplicate.toLocaleString()}</b><span>skipped: identical copy already in the archive or in this import (${human(b.duplicate)})</span></div>
    <div class="stat"><b>${c.error.toLocaleString()}</b><span>problems</span></div>
    <div class="stat"><b>${r.date_sources["file date"].toLocaleString()}</b><span>without a camera date (file date used)</span></div>
  </div>`;
  if (r.dry_run && c["would copy"]) {
    html += `<div class="row end"><button class="btn primary" id="import-now">Looks good — copy into archive</button></div>`;
  }
  if (!r.dry_run) {
    html += `<div class="row"><button class="btn small" data-known="${esc(r.destination)}">Show archive in Finder</button>
      ${r.log_file ? `<button class="btn small" data-known="${esc(r.log_file)}">Show import log</button>` : ""}</div>`;
  }
  if (r.errors.length) {
    html += `<details class="notice"><summary>${plural(r.errors.length, "note")}</summary><ul>` +
      r.errors.map((e) => `<li>${esc(e)}</li>`).join("") + `</ul></details>`;
  }
  const filters = [["all", "All"], [r.dry_run ? "would copy" : "copied", r.dry_run ? "To copy" : "Copied"], ["duplicate", "Already in archive"], ["error", "Problems"]];
  html += `<div class="filter">` + filters.map(([k, label]) =>
    `<button class="chip" data-filter="${k}" style="${importFilter === k ? "border-style:solid;color:var(--text)" : ""}">${label}</button>`).join("") + `</div>`;
  const items = r.items.filter((i) => importFilter === "all" || i.status === importFilter);
  html += `<div class="table-wrap"><table><thead><tr><th>Result</th><th>From</th><th>To</th><th>Taken</th><th>Camera</th></tr></thead><tbody>` +
    items.slice(0, 1500).map((i) => `<tr>
      <td class="status-${esc(i.status.replace(" ", "-"))}">${esc(i.status)}${i.detail && i.status !== "copied" ? `<br><small>${esc(i.detail)}</small>` : ""}</td>
      <td class="path">${esc(i.source)}</td><td class="path">${esc(i.destination)}</td>
      <td>${esc(i.date)}<br><small style="color:var(--muted)">from ${esc(srcLabel(i.date_source))}</small></td><td>${esc(i.camera)}</td></tr>`).join("") +
    `</tbody></table></div>`;
  if (items.length > 1500 || r.total_items > r.items.length) {
    html += `<p class="hint">Showing the first ${Math.min(items.length, 1500).toLocaleString()} of ${r.total_items.toLocaleString()} files${r.dry_run ? "" : " — the full list is in the import log"}.</p>`;
  }
  html += `</div>`;
  box.innerHTML = html;
  const now = $("#import-now");
  if (now) now.onclick = () => startImport(false);
}

$("#import-results").addEventListener("click", async (ev) => {
  const f = ev.target.closest("[data-filter]");
  if (f) { importFilter = f.dataset.filter; renderImport(); return; }
  const k = ev.target.closest("[data-known]");
  if (k) { try { await api("/api/reveal", { known_path: k.dataset.known }); } catch (e) { showError(e); } }
});

// ---------------------------------------------------------------- archive consistency
const LAYOUT_LABEL = { "year/month": "2024 / 2024-07", "year/date": "2024 / 2024-07-15",
  "year/month/date": "2024 / 2024-07 / 2024-07-15", "year": "2024" };
let archiveApplied = null;

// When the archive already has a structure, select the same settings so that
// new files (and later runs) stay consistent with what is already there.
async function loadArchiveInfo() {
  const box = $("#archive-info");
  const dest = folders["imp-dest"][0];
  if (!dest) { box.innerHTML = ""; archiveApplied = null; return; }
  let info;
  try { info = await api("/api/archive-settings?path=" + encodeURIComponent(dest)); } catch (e) { return; }
  const first = archiveApplied !== dest;
  archiveApplied = dest;
  if (info.saved) {
    const sv = info.saved;
    if (first) {
      $("#imp-layout").value = sv.layout;
      const map = { "imp-camera": "by_camera", "imp-rename": "rename", "imp-undated": "undated_folder", "imp-events": "keep_event_names", "imp-setdates": "set_dates" };
      for (const [id, k] of Object.entries(map)) if (k in sv) document.getElementById(id).checked = !!sv[k];
      impOptions.forEach((id) => { const el = document.getElementById(id); store.set(id, el.type === "checkbox" ? el.checked : el.value); });
      refreshTree();
    }
    const parts = [LAYOUT_LABEL[sv.layout] || sv.layout];
    if (sv.keep_event_names) parts.push("event names");
    if (sv.by_camera) parts.push("folder per camera");
    if (sv.rename) parts.push("date in file names");
    box.innerHTML = `<div class="notice ok">🔒 <b>This archive remembers its structure</b>${sv.updated ? ` (last used ${esc(new Date(sv.updated).toLocaleDateString())})` : ""}:
      ${esc(parts.join(", "))}. The same settings are selected below, so new files are filed exactly like the ones already there.</div>`;
  } else if (info.detected) {
    if (first) { $("#imp-layout").value = info.detected; store.set("imp-layout", info.detected); refreshTree(); }
    box.innerHTML = `<div class="notice ok">This archive already uses folders like <b>${esc(LAYOUT_LABEL[info.detected] || info.detected)}</b>.
      The same layout is selected below so everything stays consistent.</div>`;
  } else {
    box.innerHTML = "";
  }
}

// ---------------------------------------------------------------- tidy up (reorganize in place)
let reorgFilter = "all";
let lastReorg = null;

async function startReorg(dryRun) {
  banner("");
  const dest = folders["imp-dest"][0];
  if (!dest) { banner("Please choose the archive folder (step 2).", "err"); return; }
  if (!dryRun) {
    const ok = await confirmDialog("Tidy up the archive?",
      `<p>Photos and videos inside <code>${esc(dest)}</code> are <b>moved</b> into the structure chosen in step 3.</p>
       <ul><li>Nothing is copied, deleted or overwritten.</li>
       <li>Files already in the right place are not touched.</li>
       <li>Folders left empty are removed.</li>
       <li>You can undo it below.</li></ul>`, "Tidy up");
    if (!ok) return;
  }
  try {
    await api("/api/reorganize/start", Object.assign(currentOptions(), {
      destination: dest, set_dates: $("#imp-setdates").checked, dry_run: dryRun }));
    watchJob(() => { loadReorg(); loadArchiveInfo(); });
  } catch (e) { showError(e); }
}
$("#reorg-preview").addEventListener("click", () => startReorg(true));
$("#reorg-btn").addEventListener("click", () => startReorg(false));

async function loadReorg() {
  let data;
  try { data = await api("/api/reorganize"); } catch (e) { showError(e); return; }
  lastReorg = data.result;
  renderReorg();
  const runs = data.runs.filter((r) => !r.undone);
  $("#reorg-runs").innerHTML = runs.length ? `<div class="card"><h2>Recent tidy-ups</h2>` + runs.map((r) => `
    <div class="session"><div><b>${plural(r.files, "file")} moved</b> · ${esc(new Date(r.created).toLocaleString())}
      <div class="p">${esc(r.archive)}</div></div>
      <button class="btn small" data-undo-reorg="${esc(r.id)}">Undo</button></div>`).join("") + `</div>` : "";
}

function renderReorg() {
  const r = lastReorg, box = $("#reorg-results");
  if (!r) { box.innerHTML = ""; return; }
  const c = r.counts;
  const moves = r.dry_run ? c["would move"] : c.moved;
  let html = `<div class="card"><h2>${r.dry_run ? "Tidy-up preview — nothing was moved yet" : "Archive tidied up"}</h2>`;
  if (r.cancelled) html += `<div class="notice">Cancelled before the end.</div>`;
  html += `<div class="stats">
    <div class="stat"><b>${moves.toLocaleString()}</b><span>${r.dry_run ? "files would move to their place" : "files moved to their place"}</span></div>
    <div class="stat"><b>${c["in place"].toLocaleString()}</b><span>already in the right place</span></div>
    <div class="stat"><b>${c.duplicate.toLocaleString()}</b><span>identical copy already at the place (left as is)</span></div>
    <div class="stat"><b>${c.error.toLocaleString()}</b><span>problems</span></div></div>`;
  if (r.dry_run && moves) html += `<div class="row end"><button class="btn primary" id="reorg-now">Looks good — tidy up</button></div>`;
  if (!r.dry_run && moves === 0 && !c.error) html += `<div class="notice ok">Everything is already in place: the archive is consistent.</div>`;
  if (c.duplicate) html += `<p class="hint">Identical copies are left where they are: use <b>Find duplicates</b> on the archive to review and remove them safely.</p>`;
  if (r.errors.length) html += `<details class="notice"><summary>${plural(r.errors.length, "note")}</summary><ul>` + r.errors.map((e) => `<li>${esc(e)}</li>`).join("") + `</ul></details>`;
  const moveKey = r.dry_run ? "would move" : "moved";
  const filters = [["all", "All"], [moveKey, r.dry_run ? "To move" : "Moved"], ["in place", "In place"], ["duplicate", "Identical copy"], ["error", "Problems"]];
  html += `<div class="filter">` + filters.map(([k, label]) =>
    `<button class="chip" data-rfilter="${k}" style="${reorgFilter === k ? "border-style:solid;color:var(--text)" : ""}">${label}</button>`).join("") + `</div>`;
  const rel = (p) => p && p.startsWith(r.destination + "/") ? p.slice(r.destination.length + 1) : p;
  const items = r.items.filter((i) => reorgFilter === "all" || i.status === reorgFilter);
  html += `<div class="table-wrap"><table><thead><tr><th>Result</th><th>Now</th><th>New place</th><th>Taken</th></tr></thead><tbody>` +
    items.slice(0, 1500).map((i) => `<tr>
      <td class="status-${esc(i.status.replace(" ", "-"))}">${esc(i.status)}</td>
      <td class="path">${esc(rel(i.source))}</td><td class="path">${i.status === "in place" ? "—" : esc(rel(i.destination))}</td>
      <td>${esc(i.date)}<br><small style="color:var(--muted)">from ${esc(srcLabel(i.date_source))}</small></td></tr>`).join("") +
    `</tbody></table></div>`;
  if (items.length > 1500) html += `<p class="hint">Showing the first 1,500 of ${items.length.toLocaleString()} files.</p>`;
  html += `</div>`;
  box.innerHTML = html;
  const now = $("#reorg-now");
  if (now) now.onclick = () => startReorg(false);
}

$("#reorg-results").addEventListener("click", (ev) => {
  const f = ev.target.closest("[data-rfilter]");
  if (f) { reorgFilter = f.dataset.rfilter; renderReorg(); }
});
$("#reorg-runs").addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-undo-reorg]");
  if (!b) return;
  if (!await confirmDialog("Undo this tidy-up?", "<p>Every file moves back to where it was before. Nothing is overwritten.</p>", "Undo")) return;
  try {
    const r = await api("/api/reorganize/undo", { id: b.dataset.undoReorg });
    banner(`${plural(r.restored, "file")} moved back${r.skipped ? `, ${r.skipped} skipped (changed since)` : ""}.`, "ok");
    loadReorg();
  } catch (e) { showError(e); }
});

// ---------------------------------------------------------------- fix dates
let datesFilter = "all";
let lastDates = null;

async function startDates(dryRun) {
  banner("");
  if (!folders["dates-roots"].length) { banner("Please add the folder(s) whose dates should be fixed.", "err"); return; }
  if (!dryRun) {
    const ok = await confirmDialog("Fix file dates?",
      `<p>Each photo and video in these folders gets the date it was taken as its Finder <b>Date Created</b> and <b>Date Modified</b>.</p>
       <ul><li>The photos themselves are not changed.</li><li>Files without a date inside are left as they are.</li>
       <li>You can undo this below.</li></ul>`, "Fix dates");
    if (!ok) return;
  }
  try {
    await api("/api/dates/start", { roots: folders["dates-roots"], dry_run: dryRun });
    watchJob(() => loadDates());
  } catch (e) { showError(e); }
}
$("#dates-preview").addEventListener("click", () => startDates(true));
$("#dates-fix").addEventListener("click", () => startDates(false));

async function loadDates() {
  let data;
  try { data = await api("/api/dates"); } catch (e) { showError(e); return; }
  lastDates = data.result;
  renderDates();
  const runs = data.runs.filter((r) => !r.undone);
  $("#dates-runs").innerHTML = runs.length ? `<div class="card"><h2>Recent date fixes</h2>` + runs.map((r) => `
    <div class="session"><div><b>${plural(r.files, "file")}</b> · ${esc(new Date(r.created).toLocaleString())}
      <div class="p">${r.roots.map(esc).join("<br>")}</div></div>
      <button class="btn small" data-undo-dates="${esc(r.id)}">Undo</button></div>`).join("") + `</div>` : "";
}

function renderDates() {
  const r = lastDates, box = $("#dates-results");
  if (!r) { box.innerHTML = ""; return; }
  const c = r.counts;
  let html = `<div class="card"><h2>${r.dry_run ? "Check — nothing was changed yet" : "Dates fixed"}</h2>`;
  if (r.cancelled) html += `<div class="notice">Cancelled before the end.</div>`;
  html += `<div class="stats">
    ${r.dry_run
      ? `<div class="stat"><b>${c["would fix"].toLocaleString()}</b><span>files show the wrong date in Finder and can be fixed</span></div>`
      : `<div class="stat"><b>${c.fixed.toLocaleString()}</b><span>files now show the date taken</span></div>`}
    <div class="stat"><b>${c["already right"].toLocaleString()}</b><span>already show the right date</span></div>
    <div class="stat"><b>${c["no date"].toLocaleString()}</b><span>no date inside the file (left unchanged)</span></div>
    <div class="stat"><b>${c.error.toLocaleString()}</b><span>problems</span></div></div>`;
  if (r.dry_run && c["would fix"]) html += `<div class="row end"><button class="btn primary" id="dates-now">Fix these ${c["would fix"].toLocaleString()} files</button></div>`;
  if (c["no date"]) {
    html += `<p class="hint">Files with no date inside usually are screenshots, images saved from apps or messages, or edited exports.
      If they are in your Photos library, import them from there (“iCloud Photos” button in Organize archive): the app then uses the date Photos shows.</p>`;
  }
  const filters = [["all", "All"], [r.dry_run ? "would fix" : "fixed", r.dry_run ? "To fix" : "Fixed"], ["no date", "No date inside"], ["already right", "Already right"], ["error", "Problems"]];
  html += `<div class="filter">` + filters.map(([k, label]) =>
    `<button class="chip" data-dfilter="${k}" style="${datesFilter === k ? "border-style:solid;color:var(--text)" : ""}">${label}</button>`).join("") + `</div>`;
  const items = r.items.filter((i) => datesFilter === "all" || i.status === datesFilter);
  html += `<div class="table-wrap"><table><thead><tr><th>Result</th><th>File</th><th>Finder date ${r.dry_run ? "now" : "before"}</th><th>Date taken</th></tr></thead><tbody>` +
    items.slice(0, 1500).map((i) => `<tr>
      <td class="status-${esc(i.status.replace(" ", "-"))}">${esc(i.status)}${i.detail ? `<br><small>${esc(i.detail)}</small>` : ""}</td>
      <td class="path">${esc(i.path)}</td><td>${esc(i.current)}</td>
      <td>${i.status === "no date" ? "—" : esc(i.taken)}<br><small style="color:var(--muted)">${i.status === "no date" ? "" : "from " + esc(i.source === "metadata" ? "inside the file" : i.source)}</small></td></tr>`).join("") +
    `</tbody></table></div>`;
  if (items.length > 1500) html += `<p class="hint">Showing the first 1,500 of ${items.length.toLocaleString()} files.</p>`;
  html += `</div>`;
  box.innerHTML = html;
  const now = $("#dates-now");
  if (now) now.onclick = () => startDates(false);
}

$("#dates-results").addEventListener("click", (ev) => {
  const f = ev.target.closest("[data-dfilter]");
  if (f) { datesFilter = f.dataset.dfilter; renderDates(); }
});
$("#dates-runs").addEventListener("click", async (ev) => {
  const b = ev.target.closest("[data-undo-dates]");
  if (!b) return;
  if (!await confirmDialog("Undo this date fix?", "<p>The files get back the Finder dates they had before.</p>", "Undo")) return;
  try {
    const r = await api("/api/dates/undo", { id: b.dataset.undoDates });
    banner(`${plural(r.restored, "file")} restored${r.skipped ? `, ${r.skipped} skipped (changed since)` : ""}.`, "ok");
    loadDates();
  } catch (e) { showError(e); }
});

// ---------------------------------------------------------------- quarantine
async function loadSessions() {
  let data;
  try { data = await api("/api/quarantine"); } catch (e) { showError(e); return; }
  const box = $("#sessions");
  let html = "";
  const lr = data.last_restore;
  if (lr) {
    html += `<div class="notice ok">${plural(lr.moved, "file")} restored to its original place.`;
    if (lr.skipped.length) html += `<ul>` + lr.skipped.map((s) => `<li><code>${esc(s.path)}</code> — ${esc(s.reason)}</li>`).join("") + `</ul>`;
    html += `</div>`;
  }
  if (!data.sessions.length) {
    box.innerHTML = html + `<p class="hint">Nothing in quarantine.</p>`;
    return;
  }
  html += data.sessions.map((s) => `<div class="session">
      <div><b>${s.available ? `${plural(s.files, "file")} · ${human(s.bytes)}` : "Not available"}</b>
        ${s.created ? ` · ${esc(new Date(s.created).toLocaleString())}` : ""}
        <div class="p">${esc(s.dir)}</div>
        ${s.available ? "" : `<small>${esc(s.missing_reason || "")}</small>`}</div>
      <div class="row">
        ${s.available ? `
          <button class="btn small" data-known-q="${esc(s.dir)}">Show in Finder</button>
          <button class="btn small" data-restore="${esc(s.dir)}" ${s.files ? "" : "disabled"}>Restore all</button>
          <button class="btn small danger" data-trash="${esc(s.dir)}">Move to Trash…</button>` : `
          <button class="btn small" data-forget="${esc(s.dir)}">Remove from list</button>`}
      </div></div>`).join("");
  box.innerHTML = html;
}

$("#sessions").addEventListener("click", async (ev) => {
  const t = ev.target;
  try {
    if (t.dataset.knownQ) await api("/api/reveal", { known_path: t.dataset.knownQ });
    else if (t.dataset.restore) {
      if (!await confirmDialog("Restore all files?", "<p>Every file in this quarantine goes back to its original folder. Files are never overwritten.</p>", "Restore")) return;
      await api("/api/quarantine/restore", { dir: t.dataset.restore });
      watchJob(() => loadSessions());
    } else if (t.dataset.trash) {
      if (!await confirmDialog("Move this quarantine to the Trash?",
        `<p>These are extra copies — an identical copy of each one was kept. After this, empty the Trash in Finder to free the space.</p>
         <p>macOS may ask to allow Media Organizer (Terminal) to control Finder.</p>`, "Move to Trash", true)) return;
      await api("/api/quarantine/trash", { dir: t.dataset.trash });
      banner("Moved to the Trash. Empty the Trash in Finder to free the space.", "ok");
      loadSessions();
    } else if (t.dataset.forget) {
      await api("/api/quarantine/forget", { dir: t.dataset.forget });
      loadSessions();
    }
  } catch (e) { showError(e); }
});

// ---------------------------------------------------------------- updates
$("#update-btn").addEventListener("click", () => checkForUpdate(false));

// Step 1 only LOOKS for a new version. Nothing is installed until the user
// has seen which version and where it comes from, and clicked Install.
async function checkForUpdate(fromDownloads) {
  banner("");
  try {
    await api("/api/update/start", { downloads: !!fromDownloads });
    watchJob(showUpdateResult);
  } catch (e) { showError(e); }
}

async function showUpdateResult(job) {
  if (job && job.state !== "done") return;
  let r;
  try { ({ result: r } = await api("/api/update")); } catch (e) { showError(e); return; }
  if (!r) return;
  if (r.status === "up-to-date") {
    banner(`✓ Media Organizer ${esc(r.from)} is up to date.`, "ok");
    return;
  }
  if (r.status === "available") {
    const where = r.source_kind === "page" ? "the Media Organizer download page"
      : r.source_kind === "git" ? "git" : `this file: <code>${esc(r.source)}</code>` +
        (r.file_date ? ` (downloaded ${esc(new Date(r.file_date * 1000).toLocaleString())})` : "");
    const ok = await confirmDialog("Install the new version?",
      `<p><b>Version ${esc(r.to || "latest")}</b> is available from ${where}.</p>
       <p>You have version ${esc(r.from)}. Your settings, history and archives are not touched.</p>`, "Install");
    if (!ok) return;
    try {
      await api("/api/update/install", { version: r.to || "" });
      watchJob(showUpdateInstalled);
    } catch (e) { showError(e); }
    return;
  }
  if (r.status === "need-download") {
    const ok = await confirmDialog("Download the latest version",
      `<p>The app could not reach the download page by itself (are you online?).</p>
      <ol><li><a href="${esc(r.download_url)}" target="_blank" rel="noopener"><b>Click here to download the latest version</b></a>.</li>
      <li>When the download has finished, click <b>I have downloaded it</b>.</li></ol>`, "I have downloaded it");
    if (ok) checkForUpdate(true);
    return;
  }
  if (r.status === "old-download") {
    banner(`The file in your Downloads folder is version ${esc(r.to)}, not newer than yours (${esc(r.from)}). Nothing was changed.`, "");
    return;
  }
  banner("No Media Organizer download was found in your Downloads folder. Nothing was changed.", "");
}

async function showUpdateInstalled(job) {
  if (job && job.state !== "done") return;
  let r;
  try { ({ result: r } = await api("/api/update")); } catch (e) { showError(e); return; }
  if (!r || r.status !== "updated") return;
  const ok = await confirmDialog("Update installed",
    `<p>Media Organizer was updated from <b>${esc(r.from)}</b> to <b>${esc(r.to || "the latest version")}</b>.
      Your settings and history are kept.</p><p>Restart now to use it. This page reloads by itself.</p>`, "Restart now");
  if (ok) restartApp();
}

async function restartApp() {
  const before = INFO.started;
  try { await api("/api/restart", {}); } catch (e) { showError(e); return; }
  $("#job").classList.remove("hidden");
  $("#job-phase").textContent = "Restarting Media Organizer…";
  $("#job-bar").parentNode.classList.add("indeterminate");
  $("#job-count").textContent = "";
  $("#job-current").textContent = "";
  $("#job-cancel").disabled = true;
  for (let i = 0; i < 60; i++) {
    await new Promise((res) => setTimeout(res, 1000));
    try {
      const info = await api("/api/info");
      if (info.started !== before) { location.reload(); return; }
    } catch (e) { /* still restarting */ }
  }
  $("#job").classList.add("hidden");
  banner("The app did not come back. Close the Terminal window and double-click “Media Organizer.command”.", "err");
}

// ---------------------------------------------------------------- permissions & problem reports
async function openSettings(pane) {
  try { await api("/api/open-settings", { pane }); } catch (e) { showError(e); }
}

function showBlocked(path) {
  banner(`🔒 macOS is blocking access to <code>${esc(path)}</code>.
    To allow it: open <b>Full Disk Access</b>, turn on <b>Terminal</b>, then close the Terminal window and start Media Organizer again.
    <button class="btn small" onclick="openSettings('full-disk')">Open Full Disk Access settings</button>`, "err");
}

async function loadSetupCheck(showBanner) {
  let p;
  try { p = await api("/api/permissions"); } catch (e) { return; }
  const rows = [];
  if (!p.mac) {
    rows.push(`<div class="setup-row">Not running on a Mac: permission checks are skipped.</div>`);
  } else {
    const fda = p.full_disk_access;
    rows.push(`<div class="setup-row"><span>${fda === true ? "✅" : fda === false ? "⚠️" : "❔"} <b>Full Disk Access</b> —
      ${fda === true ? "allowed. The app can read external disks and the Photos library."
        : fda === false ? "not allowed. Some disks, folders and the Photos library may not be readable."
        : "could not be checked."}</span>
      ${fda === true ? "" : `<button class="btn small" onclick="openSettings('full-disk')">Open settings</button>`}</div>`);
    for (const l of p.photos_libraries) {
      rows.push(`<div class="setup-row"><span>${l.readable ? "✅" : "⚠️"} <b>${esc(l.library.split("/").pop())}</b> —
        ${l.readable ? "readable (iCloud Photos can be imported)." : "not readable: allow Full Disk Access to import from it."}</span></div>`);
    }
    rows.push(`<div class="setup-row"><span>After changing a permission, close the Terminal window and start Media Organizer again.</span></div>`);
    if (showBanner && fda === false && !store.get("fda-dismissed", false)) {
      banner(`⚠️ macOS does not let Media Organizer read everywhere yet (external disks, Photos library).
        <button class="btn small" onclick="openSettings('full-disk')">Open Full Disk Access settings</button>
        and turn on <b>Terminal</b>, then restart the app.
        <button class="link" onclick="store.set('fda-dismissed', true); this.parentNode.classList.add('hidden')">Don't show again</button>`, "");
    }
  }
  $("#setup-body").innerHTML = rows.join("");
}

$("#report-btn").addEventListener("click", () => showReport(false));

async function showReport(includePaths) {
  let text;
  try { ({ text } = await api(`/api/diagnostics?paths=${includePaths ? 1 : 0}`)); } catch (e) { showError(e); return; }
  $("#dialog-title").textContent = "Report a problem";
  $("#dialog-body").innerHTML = `
    <p>Copy this report and send it together with a short description (and a screenshot if you can).
      It contains the app and macOS versions and recent errors. It does not contain your photos.</p>
    <label class="check"><input type="checkbox" id="report-paths" ${includePaths ? "checked" : ""}>
      Include file and folder names (helps when a specific file causes the problem)</label>
    <textarea class="report-text" id="report-text" readonly></textarea>`;
  $("#report-text").value = text;
  $("#report-paths").onchange = (e) => showReport(e.target.checked);
  const ok = $("#dialog-ok");
  ok.textContent = "Copy report";
  ok.className = "btn primary";
  $("#dialog").classList.remove("hidden");
  const close = () => { $("#dialog").classList.add("hidden"); ok.onclick = null; $("#dialog-cancel").onclick = null; };
  $("#dialog-cancel").onclick = close;
  ok.onclick = async () => {
    const area = $("#report-text");
    try { await navigator.clipboard.writeText(area.value); }
    catch (e) { area.select(); document.execCommand("copy"); }
    ok.textContent = "Copied ✓";
    setTimeout(close, 900);
  };
}

// ---------------------------------------------------------------- start
(async function init() {
  if (!TOKEN) {
    banner("Please open the app by double-clicking “Media Organizer.command”.", "err");
    return;
  }
  try { INFO = await api("/api/info"); } catch (e) { showError(e); return; }
  $("#app-version").textContent = "Version " + INFO.version;
  loadSetupCheck(true);
  Object.keys(folders).forEach(renderFolders);
  loadPlaces();
  showTab(store.get("tab", "dupes"));
  // Re-attach to a task that is still running (e.g. after a page reload).
  try {
    const { job } = await api("/api/job");
    if (job && job.state === "running") watchJob(() => { loadDuplicates(); loadImport(); loadSessions(); });
  } catch (e) { /* ignore */ }
  loadDuplicates();
  loadImport();
  loadAnalysis(false);
  loadReorg();
})();
