"""Capture date and camera detection, written in pure Python.

Supported sources of the capture date (best first):
  * EXIF in JPEG, HEIC/HEIF/AVIF, TIFF-based RAW (DNG, GPR, CR2, NEF, ARW...),
    Fujifilm RAF and PNG
  * QuickTime / MP4 metadata (iPhone creation date with time zone,
    GoPro, DJI, Insta360, Android...)
  * Date written in the file name (DJI_20230501123456_0001.MP4,
    IMG_20230501_123456.jpg, PXL_20230501_123456789.jpg...)
  * The file's own date on disk (least reliable, reported as such)

Every parser is defensive: a damaged or unknown file simply yields no
metadata instead of an error.
"""

from __future__ import annotations

import datetime as _dt
import io
import os
import re
import struct
from dataclasses import dataclass
from typing import BinaryIO, Dict, Optional, Tuple

from .constants import extension

MIN_YEAR = 1980


@dataclass
class MediaInfo:
    date: _dt.datetime
    date_source: str  # "metadata", "file name" or "file date"
    make: str = ""
    model: str = ""

    @property
    def camera(self) -> str:
        return camera_label(self.make, self.model)


def camera_label(make: str, model: str) -> str:
    make = (make or "").strip()
    model = (model or "").strip()
    if make.lower().startswith("apple") and model:
        return model  # "iPhone 13 Pro"
    if not model:
        return make
    if not make or model.lower().startswith(make.split()[0].lower()):
        return model
    return f"{make} {model}"


def _valid(d: Optional[_dt.datetime]) -> Optional[_dt.datetime]:
    if d is None:
        return None
    now = _dt.datetime.now() + _dt.timedelta(days=2)
    if d.year < MIN_YEAR or d > now:
        return None
    return d


def parse_exif_datetime(value: str) -> Optional[_dt.datetime]:
    value = value.strip().strip("\x00").strip()
    m = re.match(r"(\d{4})[:\-](\d{2})[:\-](\d{2})[ T](\d{2}):(\d{2}):(\d{2})", value)
    if not m:
        return None
    try:
        return _valid(_dt.datetime(*(int(x) for x in m.groups())))
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# TIFF / EXIF
# ---------------------------------------------------------------------------

_TIFF_TYPE_SIZES = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 6: 1, 7: 1, 8: 2, 9: 4, 10: 8, 11: 4, 12: 8, 13: 4}

TAG_MAKE = 0x010F
TAG_MODEL = 0x0110
TAG_DATETIME = 0x0132
TAG_EXIF_IFD = 0x8769
TAG_DATETIME_ORIGINAL = 0x9003
TAG_DATETIME_DIGITIZED = 0x9004


def _read_ifd(f: BinaryIO, base: int, offset: int, endian: str, wanted) -> Dict[int, object]:
    out: Dict[int, object] = {}
    f.seek(base + offset)
    raw = f.read(2)
    if len(raw) < 2:
        return out
    (count,) = struct.unpack(endian + "H", raw)
    if count > 1000:
        return out
    data = f.read(12 * count)
    for i in range(count):
        entry = data[i * 12 : i * 12 + 12]
        if len(entry) < 12:
            break
        tag, typ, n = struct.unpack(endian + "HHI", entry[:8])
        if tag not in wanted:
            continue
        size = _TIFF_TYPE_SIZES.get(typ, 1) * n
        if size <= 4:
            value_bytes = entry[8 : 8 + size]
        else:
            (voff,) = struct.unpack(endian + "I", entry[8:12])
            if size > 4096:
                continue
            here = f.tell()
            f.seek(base + voff)
            value_bytes = f.read(size)
            f.seek(here)
        if typ == 2:  # ASCII
            out[tag] = value_bytes.split(b"\x00", 1)[0].decode("latin-1", "replace")
        elif typ in (4, 13) and len(value_bytes) >= 4:
            out[tag] = struct.unpack(endian + "I", value_bytes[:4])[0]
        elif typ == 3 and len(value_bytes) >= 2:
            out[tag] = struct.unpack(endian + "H", value_bytes[:2])[0]
    return out


def parse_tiff(f: BinaryIO, base: int = 0) -> Dict[str, str]:
    """Parse a TIFF structure starting at `base` and return EXIF fields."""
    f.seek(base)
    header = f.read(8)
    if len(header) < 8:
        return {}
    if header[:2] == b"II":
        endian = "<"
    elif header[:2] == b"MM":
        endian = ">"
    else:
        return {}
    magic, ifd0 = struct.unpack(endian + "HI", header[2:8])
    if magic not in (42, 0x55, 0x4F52, 0x5352):  # TIFF, RW2, ORF variants
        return {}
    ifd = _read_ifd(f, base, ifd0, endian, {TAG_MAKE, TAG_MODEL, TAG_DATETIME, TAG_EXIF_IFD})
    result: Dict[str, str] = {}
    if isinstance(ifd.get(TAG_MAKE), str):
        result["make"] = ifd[TAG_MAKE].strip()
    if isinstance(ifd.get(TAG_MODEL), str):
        result["model"] = ifd[TAG_MODEL].strip()
    if isinstance(ifd.get(TAG_DATETIME), str):
        result["datetime"] = ifd[TAG_DATETIME]
    exif_off = ifd.get(TAG_EXIF_IFD)
    if isinstance(exif_off, int) and exif_off > 0:
        exif = _read_ifd(f, base, exif_off, endian, {TAG_DATETIME_ORIGINAL, TAG_DATETIME_DIGITIZED})
        if isinstance(exif.get(TAG_DATETIME_ORIGINAL), str):
            result["original"] = exif[TAG_DATETIME_ORIGINAL]
        if isinstance(exif.get(TAG_DATETIME_DIGITIZED), str):
            result["digitized"] = exif[TAG_DATETIME_DIGITIZED]
    return result


def exif_from_bytes(blob: bytes) -> Dict[str, str]:
    if blob.startswith(b"Exif\x00\x00"):
        blob = blob[6:]
    return parse_tiff(io.BytesIO(blob), 0)


def read_jpeg_exif(f: BinaryIO) -> Dict[str, str]:
    f.seek(0)
    if f.read(2) != b"\xff\xd8":
        return {}
    while True:
        marker = f.read(2)
        if len(marker) < 2 or marker[0] != 0xFF:
            return {}
        while marker[1] == 0xFF:  # padding
            nxt = f.read(1)
            if not nxt:
                return {}
            marker = b"\xff" + nxt
        code = marker[1]
        if code in (0xD9, 0xDA):  # end of image / start of scan
            return {}
        if 0xD0 <= code <= 0xD7 or code == 0x01:
            continue
        raw = f.read(2)
        if len(raw) < 2:
            return {}
        (length,) = struct.unpack(">H", raw)
        if length < 2:
            return {}
        if code == 0xE1:
            start = f.tell()
            head = f.read(6)
            if head == b"Exif\x00\x00":
                info = parse_tiff(f, start + 6)
                if info:
                    return info
            f.seek(start + length - 2)
        else:
            f.seek(length - 2, os.SEEK_CUR)


def read_png_exif(f: BinaryIO) -> Dict[str, str]:
    f.seek(0)
    if f.read(8) != b"\x89PNG\r\n\x1a\n":
        return {}
    for _ in range(10000):
        head = f.read(8)
        if len(head) < 8:
            return {}
        length, ctype = struct.unpack(">I4s", head)
        if ctype == b"eXIf" and length < 10_000_000:
            return exif_from_bytes(f.read(length))
        if ctype in (b"IDAT", b"IEND"):
            return {}
        f.seek(length + 4, os.SEEK_CUR)
    return {}


def read_raf_exif(f: BinaryIO) -> Dict[str, str]:
    f.seek(0)
    if f.read(15) != b"FUJIFILMCCD-RAW":
        return {}
    f.seek(84)
    (jpeg_off,) = struct.unpack(">I", f.read(4))
    f.seek(jpeg_off)
    data = f.read(256 * 1024)
    return read_jpeg_exif(io.BytesIO(data))


# ---------------------------------------------------------------------------
# ISO base media (HEIC / AVIF / CR3 images and MP4 / MOV videos)
# ---------------------------------------------------------------------------


def _iter_boxes(f: BinaryIO, start: int, end: int):
    """Yield (type, payload_start, payload_end) for boxes in [start, end)."""
    pos = start
    count = 0
    while pos + 8 <= end and count < 100000:
        count += 1
        f.seek(pos)
        head = f.read(8)
        if len(head) < 8:
            return
        size, btype = struct.unpack(">I4s", head)
        header_len = 8
        if size == 1:
            ext = f.read(8)
            if len(ext) < 8:
                return
            (size,) = struct.unpack(">Q", ext)
            header_len = 16
        elif size == 0:
            size = end - pos
        if size < header_len:
            return
        yield btype, pos + header_len, min(pos + size, end)
        pos += size


def _file_size(f: BinaryIO) -> int:
    here = f.tell()
    f.seek(0, os.SEEK_END)
    size = f.tell()
    f.seek(here)
    return size


def _find_child(f, start, end, btype):
    for t, s, e in _iter_boxes(f, start, end):
        if t == btype:
            return s, e
    return None


def read_heif_exif(f: BinaryIO) -> Dict[str, str]:
    size = _file_size(f)
    meta = _find_child(f, 0, size, b"meta")
    if not meta:
        return {}
    mstart, mend = meta[0] + 4, meta[1]  # skip full-box version/flags
    exif_ids = set()
    locations: Dict[int, Tuple[int, int]] = {}
    for btype, s, e in _iter_boxes(f, mstart, mend):
        if btype == b"iinf":
            f.seek(s)
            version = f.read(4)[0]
            n_size = 2 if version == 0 else 4
            f.read(n_size)
            for t2, s2, e2 in _iter_boxes(f, s + 4 + n_size, e):
                if t2 != b"infe":
                    continue
                f.seek(s2)
                v = f.read(4)[0]
                if v < 2:
                    continue
                if v == 2:
                    (item_id,) = struct.unpack(">H", f.read(2))
                else:
                    (item_id,) = struct.unpack(">I", f.read(4))
                f.read(2)  # protection index
                if f.read(4) == b"Exif":
                    exif_ids.add(item_id)
        elif btype == b"iloc":
            f.seek(s)
            version = f.read(4)[0]
            b1, b2 = f.read(2)
            off_size, len_size = b1 >> 4, b1 & 15
            base_size = b2 >> 4
            idx_size = (b2 & 15) if version in (1, 2) else 0

            def rd(n):
                if n == 0:
                    return 0
                raw = f.read(n)
                return int.from_bytes(raw, "big")

            count = rd(2) if version < 2 else rd(4)
            for _ in range(min(count, 100000)):
                item_id = rd(2) if version < 2 else rd(4)
                method = 0
                if version in (1, 2):
                    method = rd(2) & 15
                rd(2)  # data reference index
                base = rd(base_size)
                n_ext = rd(2)
                first = None
                for _e in range(n_ext):
                    rd(idx_size)
                    off = rd(off_size)
                    ln = rd(len_size)
                    if first is None:
                        first = (base + off, ln)
                if first and method == 0:
                    locations[item_id] = first
    for item_id in exif_ids:
        loc = locations.get(item_id)
        if not loc or loc[1] <= 4 or loc[1] > 10_000_000:
            continue
        f.seek(loc[0])
        blob = f.read(loc[1])
        (skip,) = struct.unpack(">I", blob[:4])
        info = exif_from_bytes(blob[4 + skip :])
        if not info:  # some writers get the offset wrong: search for TIFF header
            for marker in (b"MM\x00*", b"II*\x00"):
                i = blob.find(marker)
                if i >= 0:
                    info = parse_tiff(io.BytesIO(blob), i)
                    break
        if info:
            return info
    return {}


def read_cr3_exif(f: BinaryIO) -> Dict[str, str]:
    # Canon CR3: moov / uuid(85c0b687...) / CMT1 = TIFF IFD0, CMT2 = EXIF IFD
    size = _file_size(f)
    moov = _find_child(f, 0, size, b"moov")
    if not moov:
        return {}
    result: Dict[str, str] = {}
    for t, s, e in _iter_boxes(f, moov[0], moov[1]):
        if t != b"uuid":
            continue
        for t2, s2, e2 in _iter_boxes(f, s + 16, e):
            if t2 in (b"CMT1", b"CMT2") and e2 - s2 < 1_000_000:
                f.seek(s2)
                blob = f.read(e2 - s2)
                bio = io.BytesIO(blob)
                bio.seek(0)
                endian = "<" if blob[:2] == b"II" else ">"
                if t2 == b"CMT1":
                    result.update(parse_tiff(bio, 0))
                else:
                    (ifd,) = struct.unpack(endian + "I", blob[4:8])
                    exif = _read_ifd(bio, 0, ifd, endian, {TAG_DATETIME_ORIGINAL})
                    if isinstance(exif.get(TAG_DATETIME_ORIGINAL), str):
                        result["original"] = exif[TAG_DATETIME_ORIGINAL]
    return result


QT_EPOCH = _dt.datetime(1904, 1, 1, tzinfo=_dt.timezone.utc)


def read_quicktime(f: BinaryIO) -> Dict[str, object]:
    """Read creation date and camera from an MP4/MOV file."""
    size = _file_size(f)
    moov = _find_child(f, 0, size, b"moov")
    info: Dict[str, object] = {}
    if not moov:
        return info
    for btype, s, e in _iter_boxes(f, moov[0], moov[1]):
        if btype == b"mvhd":
            f.seek(s)
            version = f.read(4)[0]
            if version == 1:
                (secs,) = struct.unpack(">Q", f.read(8))
            else:
                (secs,) = struct.unpack(">I", f.read(4))
            if secs > 0:
                try:
                    info["mvhd"] = QT_EPOCH + _dt.timedelta(seconds=secs)
                except OverflowError:
                    pass
        elif btype == b"udta":
            _read_udta(f, s, e, info)
        elif btype == b"meta":
            _read_mdta(f, s, e, info)
    return info


def _read_udta(f, start, end, info):
    for btype, s, e in _iter_boxes(f, start, end):
        if e - s > 65536:
            continue
        if btype in (b"FIRM", b"GPMF", b"CAME", b"MUID"):
            info["gopro"] = True
        if btype in (b"\xa9mak", b"\xa9mod", b"\xa9day"):
            f.seek(s)
            raw = f.read(e - s)
            text = ""
            if len(raw) >= 4:
                (ln,) = struct.unpack(">H", raw[:2])
                text = raw[4 : 4 + ln].decode("utf-8", "replace")
            if raw[4:8] == b"data":  # iTunes-style item
                text = raw[16:].decode("utf-8", "replace")
            text = text.strip("\x00 ")
            key = {b"\xa9mak": "make", b"\xa9mod": "model", b"\xa9day": "day"}[btype]
            info.setdefault(key, text)
        elif btype == b"meta":
            # Some writers put an mdta/ilst meta box inside udta.
            f.seek(s)
            probe = f.read(12)
            inner = s + 4 if probe[4:8] != b"hdlr" else s
            _read_mdta(f, inner, e, info)


def _read_mdta(f, start, end, info):
    """Apple 'keys' + 'ilst' metadata (com.apple.quicktime.creationdate...)."""
    keys = []
    ilst = None
    for btype, s, e in _iter_boxes(f, start, end):
        if btype == b"keys":
            f.seek(s + 4)
            (count,) = struct.unpack(">I", f.read(4))
            for _ in range(min(count, 1000)):
                head = f.read(8)
                if len(head) < 8:
                    break
                ksize, _ns = struct.unpack(">I4s", head)
                if ksize < 8:
                    break
                keys.append(f.read(ksize - 8).decode("utf-8", "replace"))
        elif btype == b"ilst":
            ilst = (s, e)
    if not ilst or not keys:
        return
    for btype, s, e in _iter_boxes(f, ilst[0], ilst[1]):
        idx = struct.unpack(">I", btype)[0]
        if not 1 <= idx <= len(keys):
            continue
        key = keys[idx - 1]
        wanted = {
            "com.apple.quicktime.creationdate": "apple_date",
            "com.apple.quicktime.make": "make",
            "com.apple.quicktime.model": "model",
        }.get(key)
        if not wanted:
            continue
        data = _find_child(f, s, e, b"data")
        if data and data[1] - data[0] < 4096:
            f.seek(data[0] + 8)
            value = f.read(data[1] - data[0] - 8).decode("utf-8", "replace").strip("\x00 ")
            info[wanted] = value


def parse_iso_with_offset(value: str) -> Optional[_dt.datetime]:
    """'2023-05-01T12:34:56+0200' -> naive local wall-clock time 12:34:56."""
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})", value.strip())
    if not m:
        return None
    try:
        return _valid(_dt.datetime(*(int(x) for x in m.groups())))
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# XMP (screenshots, edited/exported images)
# ---------------------------------------------------------------------------

XMP_SCAN_BYTES = 1024 * 1024
_XMP_DATE = re.compile(
    rb"(exif:DateTimeOriginal|photoshop:DateCreated|xmp:CreateDate|exif:DateTimeDigitized)"
    rb"""(?:\s*=\s*["']|>)\s*"""
    rb"(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2})(?::(\d{2}))?)?"
)
_XMP_PRIORITY = {
    b"exif:DateTimeOriginal": 0, b"photoshop:DateCreated": 1,
    b"xmp:CreateDate": 2, b"exif:DateTimeDigitized": 3,
}


def read_xmp_date(f: BinaryIO) -> Optional[_dt.datetime]:
    """Find a capture date in an XMP packet near the start of the file."""
    f.seek(0)
    blob = f.read(XMP_SCAN_BYTES)
    if b"<x:xmpmeta" not in blob and b"xmp" not in blob:
        return None
    best = None
    for m in _XMP_DATE.finditer(blob):
        prio = _XMP_PRIORITY[m.group(1)]
        parts = [int(x) if x else 0 for x in m.groups()[1:]]
        try:
            d = _valid(_dt.datetime(*parts))
        except ValueError:
            d = None
        if d and (best is None or prio < best[0]):
            best = (prio, d)
    return best[1] if best else None


# ---------------------------------------------------------------------------
# File name dates
# ---------------------------------------------------------------------------

_NAME_PATTERNS = [
    # 20230501_123456 / 20230501-123456 / 20230501123456
    re.compile(r"(?<!\d)(20\d{2}|19\d{2})(\d{2})(\d{2})[_\-\s]?(\d{2})(\d{2})(\d{2})"),
    # 2023-05-01 12.34.56 / 2023-05-01_12-34-56
    re.compile(r"(?<!\d)(20\d{2}|19\d{2})-(\d{2})-(\d{2})[ _T](\d{2})[.\-:](\d{2})[.\-:](\d{2})"),
]
_NAME_DATE_ONLY = re.compile(r"(?<!\d)(20\d{2})-?(\d{2})-?(\d{2})(?!\d)")


def date_from_filename(name: str) -> Optional[_dt.datetime]:
    stem = os.path.splitext(os.path.basename(name))[0]
    for pat in _NAME_PATTERNS:
        m = pat.search(stem)
        if m:
            try:
                d = _valid(_dt.datetime(*(int(x) for x in m.groups())))
            except ValueError:
                d = None
            if d:
                return d
    m = _NAME_DATE_ONLY.search(stem)
    if m and ("WA" in stem.upper() or "-" in m.group(0)):
        # WhatsApp (IMG-20230501-WA0001) or explicit 2023-05-01
        try:
            return _valid(_dt.datetime(*(int(x) for x in m.groups())))
        except ValueError:
            return None
    return None


_GOPRO_NAME = re.compile(r"^(G[HXLS]\d{6}|GOPR\d{4}|GP\d{6}|GS\d{6})\.", re.I)


def file_date(path: str) -> _dt.datetime:
    st = os.stat(path)
    ts = st.st_mtime
    birth = getattr(st, "st_birthtime", None)
    if birth and 0 < birth < ts:
        ts = birth
    return _dt.datetime.fromtimestamp(ts)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def _image_exif(path: str, f: BinaryIO) -> Dict[str, str]:
    head = f.read(16)
    f.seek(0)
    ext = extension(path)
    try:
        if head[:2] == b"\xff\xd8":
            return read_jpeg_exif(f)
        if head[:2] in (b"II", b"MM"):
            return parse_tiff(f, 0)
        if head[:8] == b"\x89PNG\r\n\x1a\n":
            return read_png_exif(f)
        if head[:15] == b"FUJIFILMCCD-RAW":
            return read_raf_exif(f)
        if head[4:8] == b"ftyp":
            brand = head[8:12]
            if brand == b"crx " or ext == ".cr3":
                return read_cr3_exif(f)
            return read_heif_exif(f)
    except (struct.error, OSError, ValueError, IndexError, OverflowError):
        return {}
    return {}


def read_media_info(path: str) -> MediaInfo:
    """Best-effort capture date and camera of a photo or video."""
    ext = extension(path)
    name = os.path.basename(path)
    make = model = ""
    date: Optional[_dt.datetime] = None
    try:
        with open(path, "rb") as f:
            head = f.read(16)
            f.seek(0)
            is_iso = head[4:8] in (b"ftyp", b"moov", b"mdat", b"wide", b"free", b"skip", b"pnot")
            is_movie = is_iso and ext not in (".heic", ".heif", ".hif", ".avif", ".cr3")
            if not is_movie:
                exif = _image_exif(path, f)
                make, model = exif.get("make", ""), exif.get("model", "")
                for key in ("original", "digitized", "datetime"):
                    if key in exif:
                        date = parse_exif_datetime(exif[key])
                        if date:
                            break
                if not date:
                    try:
                        date = read_xmp_date(f)
                    except OSError:
                        date = None
                if date:
                    return MediaInfo(date, "metadata", make, model)
            else:
                try:
                    qt = read_quicktime(f)
                except (struct.error, OSError, ValueError, IndexError, OverflowError):
                    qt = {}
                make = str(qt.get("make", "") or "")
                model = str(qt.get("model", "") or "")
                gopro = bool(qt.get("gopro")) or bool(_GOPRO_NAME.match(name))
                dji = name.upper().startswith("DJI") or make.upper().startswith("DJI")
                if gopro and not make:
                    make = "GoPro"
                if dji and not make:
                    make = "DJI"
                if qt.get("apple_date"):
                    date = parse_iso_with_offset(str(qt["apple_date"]))
                if not date and qt.get("day"):
                    date = parse_iso_with_offset(str(qt["day"]))
                if not date and dji:
                    date = date_from_filename(name)
                    if date:
                        return MediaInfo(date, "file name", make, model)
                if not date and isinstance(qt.get("mvhd"), _dt.datetime):
                    mv = qt["mvhd"]
                    if gopro:
                        # GoPro cameras write local time without a time zone.
                        date = _valid(mv.replace(tzinfo=None))
                    else:
                        # The standard says UTC: convert to this Mac's time zone.
                        date = _valid(mv.astimezone().replace(tzinfo=None))
                if date:
                    return MediaInfo(date, "metadata", make, model)
    except OSError:
        pass
    date = date_from_filename(name)
    if date:
        return MediaInfo(date, "file name", make, model)
    return MediaInfo(file_date(path), "file date", make, model)
