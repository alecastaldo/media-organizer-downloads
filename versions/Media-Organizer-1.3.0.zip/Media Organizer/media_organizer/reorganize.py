"""Reorganize an archive in place: move its files into one consistent structure.

For an archive whose sub-folders grew in different ways over the years
(camera dumps, "Photos 2019/Summer", "Backup/DCIM/100APPLE"...), every photo
and video is moved to the folder the chosen structure gives it, inside the
same archive.

Safety rules:
  * Files are only moved within the archive (same disk: an instant rename),
    never copied, changed or deleted.
  * Nothing is ever overwritten. If an identical file is already at the
    target place, the file is left where it is and reported as a duplicate
    (use "Find duplicates" to review those).
  * Files already at their right place are not touched, so running it again
    changes nothing.
  * Every move is recorded and can be undone.
  * Folders that end up empty are removed (only if truly empty).
"""

from __future__ import annotations

import datetime as _dt
import errno
import os
import re
from typing import Dict, List, Optional

from . import appdata, archive_settings
from .constants import is_media, is_sidecar
from .duplicates import Progress
from .filedates import TRUSTED_SOURCES, local_timestamp, set_file_dates
from .hashing import files_identical
from .importer import (
    ImportItem,
    ImportOptions,
    ImportResult,
    _sidecar_map,
    _sidecars_for,
    _write_log,
    event_name,
    media_info_loader,
    target_folder,
    target_name,
)
from .scanner import WalkReport, inside_protected_bundle, walk_files

HISTORY_FILE = "reorganize-runs.json"


def _same_path(a: str, b: str) -> bool:
    """Equal paths; macOS disks usually ignore upper/lower case."""
    if a == b:
        return True
    try:
        return os.path.exists(a) and os.path.exists(b) and os.path.samefile(a, b)
    except OSError:
        return False


def _is_suffixed_variant(current: str, target: str) -> bool:
    """IMG_1234_1.JPG in the right folder, when the target is IMG_1234.JPG:
    a name made unique by an earlier run. It stays, so runs are repeatable."""
    if os.path.dirname(current) != os.path.dirname(target):
        return False
    base, ext = os.path.splitext(os.path.basename(target))
    pattern = re.escape(base) + r"_\d+" + re.escape(ext)
    return re.fullmatch(pattern, os.path.basename(current), re.I) is not None


def _unique(folder: str, name: str, taken: set, current: str) -> str:
    base, ext = os.path.splitext(name)
    candidate, i = name, 1
    while True:
        path = os.path.join(folder, candidate)
        if path.lower() not in taken and (not os.path.lexists(path) or _same_path(path, current)):
            return candidate
        candidate = f"{base}_{i}{ext}"
        i += 1


def reorganize(options: ImportOptions, progress: Optional[Progress] = None) -> ImportResult:
    progress = progress or Progress()
    archive = os.path.abspath(os.path.expanduser(options.destination.strip()))
    options.destination = archive
    options.sources = [archive]
    if not os.path.isdir(archive):
        raise ValueError(f"Archive folder not found: {archive}")
    if inside_protected_bundle(archive):
        raise ValueError("Files inside a Photos or Lightroom library must not be moved by hand.")
    if not options.dry_run and not os.access(archive, os.W_OK):
        raise ValueError(f"Cannot write to {archive}. The disk may be read-only (for example NTFS).")

    result = ImportResult(options=options)
    report = WalkReport()
    progress.set(phase="Listing files", done=0, total=0)
    entries = list(walk_files([archive], lambda n: is_media(n) or is_sidecar(n), report,
                              cancelled=progress.cancelled))
    result.errors.extend(report.errors)
    for b in report.skipped_bundles:
        result.errors.append(f"Left the app library {b} untouched.")
    side = _sidecar_map(entries)
    media = [e for e in entries if is_media(e.path)]
    info_for = media_info_loader([archive])

    # 1. Plan every move first, then execute: the plan is what the preview shows.
    progress.set(phase="Planning the new structure", done=0, total=len(media))
    plan = []
    taken = set()
    # Files already in the right place keep their spot before others are planned.
    planned = []
    for i, e in enumerate(media):
        if progress.cancelled():
            result.cancelled = True
            return result
        if i % 25 == 0:
            progress.set(done=i, current=e.path)
        item = ImportItem(source=e.path, size=e.size)
        result.items.append(item)
        try:
            info = info_for(e.path)
        except OSError as exc:
            item.status, item.detail = "error", str(exc.strerror or exc)
            continue
        item.date = info.date.strftime("%Y-%m-%d %H:%M:%S")
        item.date_source = info.date_source
        item.camera = info.camera
        event = event_name(e.path, archive, info.camera) if options.keep_event_names else ""
        folder = target_folder(options, info, event)
        name = target_name(options, info, os.path.basename(e.path))
        target = os.path.join(folder, name)
        planned.append((e, item, info, folder, name, target))
        if _same_path(target, e.path) or target == e.path or _is_suffixed_variant(e.path, target):
            taken.add(e.path.lower())

    for e, item, info, folder, name, target in planned:
        if target == e.path or _same_path(target, e.path) or _is_suffixed_variant(e.path, target):
            item.status, item.destination, item.detail = "in place", e.path, "Already in the right place"
            continue
        if os.path.lexists(target) and files_identical(target, e.path):
            item.status, item.destination = "duplicate", target
            item.detail = "An identical file is already there: left as is (see Find duplicates)"
            continue
        name = _unique(folder, name, taken, e.path)
        target = os.path.join(folder, name)
        taken.add(target.lower())
        item.destination = target
        item.status = "would move"
        plan.append((e, item, info, target))

    if options.dry_run:
        return result

    # 2. Execute.
    progress.set(phase="Moving files into place", done=0, total=len(plan))
    moves: List[Dict[str, str]] = []
    for i, (e, item, info, target) in enumerate(plan):
        if progress.cancelled():
            result.cancelled = True
            item.status, item.detail = "error", "Cancelled before this file"
            continue
        progress.set(done=i, current=e.path)
        try:
            if os.path.lexists(target):
                raise OSError("a file appeared at the target place meanwhile")
            os.makedirs(os.path.dirname(target), exist_ok=True)
            os.rename(e.path, target)
        except OSError as exc:
            item.status = "error"
            if getattr(exc, "errno", None) == errno.EXDEV:
                item.detail = "On a different disk inside the archive: not moved"
            else:
                item.detail = f"Could not move: {exc.strerror or exc}"
            continue
        moves.append({"from": e.path, "to": target})
        item.status, item.detail = "moved", "Moved"
        if options.set_dates and info.date_source in TRUSTED_SOURCES:
            try:
                set_file_dates(target, local_timestamp(info.date))
            except OSError:
                pass
        # sidecars (.AAE, .XMP, .SRT) follow their photo/video
        new_stem = os.path.splitext(target)[0]
        for s in _sidecars_for(e.path, side):
            dst = new_stem + os.path.splitext(s.path)[1]
            if os.path.lexists(dst) or not os.path.exists(s.path):
                continue
            try:
                os.rename(s.path, dst)
                moves.append({"from": s.path, "to": dst})
            except OSError:
                pass
    progress.set(done=len(plan))
    removed = _remove_empty_folders(archive, {os.path.dirname(m["from"]) for m in moves})
    if removed:
        result.errors.append(f"Removed {removed} folder(s) that became empty.")
    result.log_file = _write_log(result, "tidy-up")
    if moves:
        result.run_id = _save_run(archive, moves)
    if not result.cancelled:
        archive_settings.save(archive, options)
    return result


def _remove_empty_folders(archive: str, folders) -> int:
    """Remove folders left empty by the moves (walking up, never the archive)."""
    removed = 0
    archive = archive.rstrip(os.sep)
    if not archive:
        return 0
    for folder in sorted(folders, key=len, reverse=True):
        while folder.startswith(archive + os.sep):
            try:
                names = os.listdir(folder)
            except OSError:
                break
            if any(n != ".DS_Store" for n in names):
                break
            try:
                for n in names:
                    os.unlink(os.path.join(folder, n))
                os.rmdir(folder)
                removed += 1
            except OSError:
                break
            folder = os.path.dirname(folder)
    return removed


def _save_run(archive: str, moves: List[Dict[str, str]]) -> str:
    runs = appdata.read_json(HISTORY_FILE, [])
    run_id = _dt.datetime.now().strftime("%Y%m%d-%H%M%S-%f")
    runs.append({
        "id": run_id,
        "created": _dt.datetime.now().isoformat(timespec="seconds"),
        "archive": archive,
        "moves": moves,
    })
    appdata.write_json(HISTORY_FILE, runs[-20:])
    return run_id


def list_runs() -> List[dict]:
    return [
        {"id": r["id"], "created": r.get("created", ""), "archive": r.get("archive", ""),
         "files": len(r.get("moves", [])), "undone": bool(r.get("undone"))}
        for r in reversed(appdata.read_json(HISTORY_FILE, []))
    ]


def undo_run(run_id: str) -> Dict[str, int]:
    """Move every file of one run back where it was (never overwriting)."""
    runs = appdata.read_json(HISTORY_FILE, [])
    run = next((r for r in runs if r.get("id") == run_id), None)
    if run is None:
        raise ValueError("This reorganization is not in the history any more.")
    restored = skipped = 0
    for m in reversed(run.get("moves", [])):
        src, dst = m["to"], m["from"]
        if not os.path.exists(src) or os.path.lexists(dst):
            skipped += 1
            continue
        try:
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            os.rename(src, dst)
            restored += 1
        except OSError:
            skipped += 1
    _remove_empty_folders(run.get("archive", ""), {os.path.dirname(m["to"]) for m in run.get("moves", [])})
    run["undone"] = True
    appdata.write_json(HISTORY_FILE, runs)
    return {"restored": restored, "skipped": skipped}
