"""Content hashing, byte-by-byte comparison and a small hash cache."""

from __future__ import annotations

import hashlib
import os
import sqlite3
from typing import Callable, Optional

from .appdata import data_path

CHUNK = 1024 * 1024  # 1 MiB
QUICK_BYTES = 64 * 1024


class Cancelled(Exception):
    pass


def quick_hash(path: str, size: int) -> str:
    """Hash of the first and last 64 KiB. Only used to rule files out."""
    h = hashlib.sha256()
    h.update(str(size).encode())
    with open(path, "rb") as f:
        h.update(f.read(QUICK_BYTES))
        if size > 2 * QUICK_BYTES:
            f.seek(size - QUICK_BYTES)
            h.update(f.read(QUICK_BYTES))
    return h.hexdigest()


def full_hash(
    path: str,
    progress: Optional[Callable[[int], None]] = None,
    cancelled: Callable[[], bool] = lambda: False,
) -> str:
    """SHA-256 of the whole file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            if cancelled():
                raise Cancelled()
            block = f.read(CHUNK)
            if not block:
                break
            h.update(block)
            if progress:
                progress(len(block))
    return h.hexdigest()


def files_identical(a: str, b: str) -> bool:
    """True only if both files have exactly the same bytes.

    This is the final safety check done right before any file is moved
    out of the way, independent of any hash or cache.
    """
    try:
        sa, sb = os.stat(a), os.stat(b)
    except OSError:
        return False
    if sa.st_size != sb.st_size:
        return False
    with open(a, "rb") as fa, open(b, "rb") as fb:
        while True:
            ba = fa.read(CHUNK)
            bb = fb.read(CHUNK)
            if ba != bb:
                return False
            if not ba:
                return True


class HashCache:
    """Remembers full hashes of unchanged files so re-scans are fast.

    A cache hit requires the same path, size and modification time. The
    cache is only ever used to *find* candidate duplicates; deletions are
    always confirmed by a fresh byte-by-byte comparison.
    """

    def __init__(self, path: Optional[str] = None):
        self.path = path or data_path("hash-cache.sqlite3")
        self.db = None
        try:
            self.db = sqlite3.connect(self.path, timeout=10)
            self.db.execute(
                "CREATE TABLE IF NOT EXISTS hashes ("
                " path TEXT PRIMARY KEY, size INTEGER, mtime_ns INTEGER,"
                " sha256 TEXT)"
            )
            self.db.commit()
        except sqlite3.Error:
            # A broken cache must never stop the app: start over.
            self._reset()
        self._pending = 0

    def _reset(self):
        try:
            if self.db is not None:
                self.db.close()
        except sqlite3.Error:
            pass
        try:
            os.unlink(self.path)
        except OSError:
            pass
        try:
            self.db = sqlite3.connect(self.path, timeout=10)
            self.db.execute(
                "CREATE TABLE IF NOT EXISTS hashes ("
                " path TEXT PRIMARY KEY, size INTEGER, mtime_ns INTEGER,"
                " sha256 TEXT)"
            )
        except sqlite3.Error:
            self.db = None

    @staticmethod
    def _key(path: str):
        st = os.stat(path)
        return st.st_size, st.st_mtime_ns

    def get(self, path: str) -> Optional[str]:
        if self.db is None:
            return None
        try:
            size, mtime_ns = self._key(path)
            row = self.db.execute(
                "SELECT size, mtime_ns, sha256 FROM hashes WHERE path=?",
                (_db_text(path),),
            ).fetchone()
        except (OSError, sqlite3.Error):
            return None
        if row and row[0] == size and row[1] == mtime_ns:
            return row[2]
        return None

    def put(self, path: str, digest: str) -> None:
        if self.db is None:
            return
        try:
            size, mtime_ns = self._key(path)
            self.db.execute(
                "INSERT OR REPLACE INTO hashes VALUES (?,?,?,?)",
                (_db_text(path), size, mtime_ns, digest),
            )
            self._pending += 1
            if self._pending >= 200:
                self.db.commit()
                self._pending = 0
        except (OSError, sqlite3.Error):
            pass

    def hash(self, path: str, progress=None, cancelled=lambda: False) -> str:
        cached = self.get(path)
        if cached:
            if progress:
                try:
                    progress(os.path.getsize(path))
                except OSError:
                    pass
            return cached
        digest = full_hash(path, progress, cancelled)
        self.put(path, digest)
        return digest

    def close(self) -> None:
        if self.db is None:
            return
        try:
            self.db.commit()
            self.db.close()
        except sqlite3.Error:
            pass
        self.db = None


def _db_text(path: str) -> str:
    # File names that are not valid UTF-8 (possible on some external disks)
    # are stored in an escaped but unique form.
    return path.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
