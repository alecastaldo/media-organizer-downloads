"""An archive remembers how it is organized, so every run stays consistent.

After an import or reorganization, the chosen structure is saved in a small
hidden file at the top of the archive (".media-organizer.json"). The next
time the same archive is used, from this Mac or another one, the same
structure is suggested and selected. For archives organized by hand or by
another app, the existing folder pattern (2023/2023-07...) is detected.
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import re
from typing import Optional

from .appdata import atomic_write_json

SETTINGS_FILE = ".media-organizer.json"
KEYS = ("layout", "by_camera", "rename", "undated_folder", "keep_event_names", "set_dates")


def settings_path(archive: str) -> str:
    return os.path.join(archive, SETTINGS_FILE)


def load(archive: str) -> Optional[dict]:
    try:
        with open(settings_path(archive), "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(data, dict) or "layout" not in data:
        return None
    return data


def save(archive: str, options) -> None:
    """Remember the structure used for this archive (best effort)."""
    data = {k: getattr(options, k) for k in KEYS}
    data["app"] = "Media Organizer"
    data["updated"] = _dt.datetime.now().isoformat(timespec="seconds")
    try:
        os.makedirs(archive, exist_ok=True)
        atomic_write_json(settings_path(archive), data)
    except OSError:
        pass


_YEAR = re.compile(r"^(19|20)\d{2}$")
_MONTH = re.compile(r"^(19|20)\d{2}-\d{2}(\s.*)?$")
_DATE = re.compile(r"^(19|20)\d{2}-\d{2}-\d{2}(\s.*)?$")


def _subdirs(path: str):
    try:
        with os.scandir(path) as it:
            return [e for e in it if e.is_dir(follow_symlinks=False) and not e.name.startswith(".")]
    except OSError:
        return []


def infer_layout(archive: str) -> Optional[str]:
    """Detect the folder pattern of an existing archive, if clear enough."""
    years = [d for d in _subdirs(archive) if _YEAR.match(d.name)]
    if len(years) < 1:
        return None
    counts = {"year/month": 0, "year/date": 0, "year/month/date": 0, "year": 0}
    for y in years[:30]:
        children = _subdirs(y.path)
        if not children:
            counts["year"] += 1
            continue
        months = [c for c in children if _MONTH.match(c.name) and not _DATE.match(c.name)]
        dates = [c for c in children if _DATE.match(c.name)]
        if dates and len(dates) >= len(children) * 0.6:
            counts["year/date"] += 1
        elif months and len(months) >= len(children) * 0.6:
            nested = sum(1 for m in months[:12] for c in _subdirs(m.path) if _DATE.match(c.name))
            counts["year/month/date" if nested >= 1 else "year/month"] += 1
        else:
            counts["year"] += 1
    best = max(counts, key=counts.get)
    return best if counts[best] >= max(1, 0.6 * min(len(years), 30)) else None
