"""File-type tables and folder names shared by the whole app."""

PHOTO_EXTENSIONS = {
    # common
    ".jpg", ".jpeg", ".jpe", ".heic", ".heif", ".hif", ".avif", ".png",
    ".gif", ".tif", ".tiff", ".bmp", ".webp",
    # raw formats (iPhone ProRAW, DJI, GoPro, DSLR/mirrorless)
    ".dng", ".gpr", ".raw", ".cr2", ".cr3", ".crw", ".nef", ".nrw", ".arw",
    ".srf", ".sr2", ".orf", ".rw2", ".raf", ".pef", ".srw", ".x3f", ".3fr",
    ".iiq", ".erf", ".mrw",
    # Insta360 photos
    ".insp",
}

VIDEO_EXTENSIONS = {
    ".mov", ".mp4", ".m4v", ".3gp", ".3g2", ".avi", ".mts", ".m2ts", ".mkv",
    ".wmv", ".mpg", ".mpeg", ".webm",
    # Insta360 and GoPro Max 360 videos
    ".insv", ".360",
}

# Small files that belong to a photo/video with the same name
# (iPhone edits, Lightroom metadata, DJI flight telemetry).
# They are copied along with their main file during import and are never
# considered for duplicate removal (two different photos can have
# byte-identical .AAE edit files).
SIDECAR_EXTENSIONS = {".aae", ".xmp", ".srt"}

MEDIA_EXTENSIONS = PHOTO_EXTENSIONS | VIDEO_EXTENSIONS

# Folders created by this app (skipped while scanning).
QUARANTINE_DIR_NAME = "Duplicates Quarantine (Media Organizer)"
IMPORT_LOG_DIR_NAME = "Import Logs (Media Organizer)"

# Files / folders that are never scanned.
SKIP_DIR_NAMES = {
    QUARANTINE_DIR_NAME,
    IMPORT_LOG_DIR_NAME,
    ".Trashes", ".Trash", ".Spotlight-V100", ".fseventsd",
    ".TemporaryItems", ".DocumentRevisions-V100", ".PKInstallSandboxManager",
    "$RECYCLE.BIN", "System Volume Information", "@eaDir", ".thumbnails",
    "node_modules", ".git",
}
SKIP_FILE_NAMES = {".DS_Store", "Thumbs.db", "desktop.ini", "Icon\r"}

# App libraries whose inside must never be modified by hand (doing so can
# corrupt the library). They are skipped entirely during duplicate scans.
PROTECTED_BUNDLE_SUFFIXES = (
    ".photoslibrary", ".photolibrary", ".aplibrary", ".migratedaplibrary",
    ".lrlibrary", ".lrdata", ".imovielibrary", ".fcpbundle", ".tvlibrary",
    ".musiclibrary",
)


def extension(name):
    """Lower-case extension including the dot ("" if none)."""
    dot = name.rfind(".")
    if dot <= 0:
        return ""
    return name[dot:].lower()


def is_media(name):
    return extension(name) in MEDIA_EXTENSIONS


def is_video(name):
    return extension(name) in VIDEO_EXTENSIONS


def is_sidecar(name):
    return extension(name) in SIDECAR_EXTENSIONS


def is_protected_bundle(name):
    return name.lower().endswith(PROTECTED_BUNDLE_SUFFIXES)
