"""Where the app keeps its own small files (cache, history)."""

from __future__ import annotations

import json
import os
import sys
import tempfile
import threading

from . import APP_NAME

_lock = threading.Lock()


def app_data_dir() -> str:
    override = os.environ.get("MEDIA_ORGANIZER_DATA")
    if override:
        path = override
    elif sys.platform == "darwin":
        path = os.path.expanduser(f"~/Library/Application Support/{APP_NAME}")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.expanduser("~/.local/share")
        path = os.path.join(base, "media-organizer")
    os.makedirs(path, exist_ok=True)
    return path


def data_path(name: str) -> str:
    return os.path.join(app_data_dir(), name)


def read_json(name: str, default):
    try:
        with open(data_path(name), "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_json(name: str, value) -> None:
    """Atomically write a JSON file in the app data folder."""
    with _lock:
        target = data_path(name)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(target), suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(value, f, indent=2, ensure_ascii=False)
            os.replace(tmp, target)
        except BaseException:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise


def atomic_write_json(path: str, value) -> None:
    """Atomically write a JSON file anywhere (used for quarantine manifests)."""
    directory = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(dir=directory, prefix=".manifest-", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(value, f, indent=2, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
