"""Start the app:  python3 -m media_organizer

Command-line use (optional):
  python3 -m media_organizer launch              start in the background, open the browser
  python3 -m media_organizer                     run in this Terminal window
  python3 -m media_organizer find-duplicates DIR [DIR...]   list duplicates only
"""

from __future__ import annotations

import argparse
import sys


def _human(n: float) -> str:
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "bytes" else f"{n:.1f} {unit}"
        n /= 1000
    return str(n)


def main(argv=None) -> int:
    if sys.version_info < (3, 9):
        print("Media Organizer needs Python 3.9 or newer.")
        return 1
    parser = argparse.ArgumentParser(prog="media_organizer")
    parser.add_argument("--no-browser", action="store_true", help="do not open the browser")
    parser.add_argument("--port", type=int, default=None)
    sub = parser.add_subparsers(dest="command")
    fd = sub.add_parser("find-duplicates", help="report exact duplicates (changes nothing)")
    fd.add_argument("folders", nargs="+")
    sub.add_parser("update", help="update the app in place")
    sub.add_parser("launch", help="start the app in the background (or open it if running)")
    sv = sub.add_parser("serve", help="run the app in this window")
    sv.add_argument("--port", type=int, default=None)
    sv.add_argument("--background", action="store_true")
    sv.add_argument("--open-browser", action="store_true")
    args = parser.parse_args(argv)

    if args.command == "find-duplicates":
        from .duplicates import find_duplicates

        result = find_duplicates(args.folders)
        for g in result.groups:
            print(f"\n{len(g.files)} identical copies, {_human(g.size)} each:")
            for i, f in enumerate(g.files):
                print(("  keep   " if i == g.keep else "  extra  ") + f.path)
        print(
            f"\nScanned {result.files_scanned} files. {len(result.groups)} groups, "
            f"{result.redundant_files} extra copies, {_human(result.redundant_bytes)} could be freed."
        )
        for e in result.errors:
            print("warning:", e, file=sys.stderr)
        return 0

    if args.command == "update":
        from . import updater

        def ask(info) -> bool:
            where = "the download page" if info.get("source_kind") == "page" else info.get("source")
            answer = input(f"\n  Version {info.get('to') or 'latest'} is available (from {where}).\n"
                           f"  You have {info['from']}. Install it now? [y/N] ")
            return answer.strip().lower() in ("y", "yes", "s", "si", "sì")

        r = updater.update(confirm=ask)
        if r["status"] == "need-download":
            print("\n  The app could not reach the download page by itself (are you online?).")
            print(f"  1. Open this address in your browser:\n       {r['download_url']}")
            input("  2. When the download has finished, press Enter here... ")
            r = updater.update(use_github=False, use_downloads=True, confirm=ask)
        status = r["status"]
        if status == "updated":
            print(f"\n  Updated Media Organizer {r['from']} -> {r.get('to') or 'latest'}.")
            print("  Start it again with Media Organizer.command.\n")
        elif status == "up-to-date":
            print(f"\n  Media Organizer {r['from']} is up to date.\n")
        elif status == "declined":
            print("\n  Nothing was changed.\n")
        elif status == "old-download":
            print(f"\n  The download found ({r['source']}) is version {r['to']}, not newer than {r['from']}.\n")
        else:
            print("\n  No Media Organizer download was found in your Downloads folder.\n")
        return 0 if status in ("updated", "up-to-date", "declined") else 2

    if args.command == "launch":
        from .launcher import launch

        return launch()

    from .server import serve

    if args.command == "serve":
        serve(open_browser=args.open_browser, port=args.port, background=args.background)
        return 0
    # no command: run in this Terminal window (older launchers, and after an
    # update installed by version 1.3.0, which restarts the app this way)
    serve(open_browser=not args.no_browser, port=args.port)
    return 0


if __name__ == "__main__":
    sys.exit(main())
