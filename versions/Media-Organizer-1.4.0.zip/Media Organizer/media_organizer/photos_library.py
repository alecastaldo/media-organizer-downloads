"""Read-only helpers for the macOS Photos library (iCloud Photos).

When "Download Originals to this Mac" is enabled in Photos > Settings >
iCloud, every original photo and video from iCloud is stored inside
"Photos Library.photoslibrary/originals". Media Organizer can copy them from
there into your archive. The library itself is only read, never changed.
"""

from __future__ import annotations

import datetime as _dt
import glob
import os
import sqlite3
from typing import Dict, List, Optional


def find_libraries(include_disks: bool = True) -> List[dict]:
    """Photos libraries in ~/Pictures and (optionally) on connected disks.
    Looking on disks can wake sleeping external drives, so it is only done
    when the user asks for it."""
    found = []
    patterns = [os.path.expanduser("~/Pictures/*.photoslibrary")]
    if include_disks:
        patterns += ["/Volumes/*/*.photoslibrary", "/Volumes/*/*/*.photoslibrary"]
    for pattern in patterns:
        for lib in sorted(glob.glob(pattern)):
            originals = os.path.join(lib, "originals")
            if not os.path.isdir(originals):
                originals = os.path.join(lib, "Masters")  # very old libraries
            found.append({
                "library": lib,
                "originals": originals,
                "readable": os.access(originals, os.R_OK) and _can_list(originals),
            })
    return found


def _can_list(path: str) -> bool:
    try:
        os.listdir(path)
        return True
    except OSError:
        return False


APPLE_EPOCH = 978307200  # 2001-01-01 in Unix time (Core Data dates)


def original_names(library: str) -> Dict[str, str]:
    """Map files in originals/ to the name they had on the iPhone (IMG_1234.HEIC)."""
    return {p: v["name"] for p, v in library_info(library).items() if v.get("name")}


def library_info(library: str) -> Dict[str, dict]:
    """For each file in originals/: its iPhone name and the date shown in Photos.

    The date is the one Photos displays, including any change made with
    "Adjust Date and Time", in the local time of the place it was taken.
    Best effort: the Photos database layout changes between macOS versions,
    so any problem returns what could be read (possibly nothing).
    """
    db_path = os.path.join(library, "database", "Photos.sqlite")
    if not os.path.exists(db_path):
        return {}
    uri = "file:" + db_path.replace("?", "%3f").replace("#", "%23") + "?mode=ro&immutable=1"
    try:
        con = sqlite3.connect(uri, uri=True, timeout=5)
    except sqlite3.Error:
        return {}
    out: Dict[str, dict] = {}
    try:
        tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        asset = "ZASSET" if "ZASSET" in tables else "ZGENERICASSET"
        if asset not in tables:
            return {}
        asset_cols = {r[1] for r in con.execute(f"PRAGMA table_info({asset})")}
        if not {"ZDIRECTORY", "ZFILENAME"} <= asset_cols:
            return {}
        has_attrs = "ZADDITIONALASSETATTRIBUTES" in tables
        attr_cols = (
            {r[1] for r in con.execute("PRAGMA table_info(ZADDITIONALASSETATTRIBUTES)")}
            if has_attrs else set()
        )
        date_col = "a.ZDATECREATED" if "ZDATECREATED" in asset_cols else "NULL"
        name_col = "b.ZORIGINALFILENAME" if "ZORIGINALFILENAME" in attr_cols else "NULL"
        tz_col = "b.ZTIMEZONEOFFSET" if "ZTIMEZONEOFFSET" in attr_cols else "NULL"
        join = "LEFT JOIN ZADDITIONALASSETATTRIBUTES b ON b.ZASSET = a.Z_PK" if has_attrs else ""
        rows = con.execute(
            f"SELECT a.ZDIRECTORY, a.ZFILENAME, {name_col}, {date_col}, {tz_col} "
            f"FROM {asset} a {join}"
        )
        originals = os.path.join(library, "originals")
        for directory, filename, original, created, tz_offset in rows:
            if not (directory and filename):
                continue
            entry: dict = {}
            if original:
                ext = os.path.splitext(filename)[1]
                entry["name"] = os.path.splitext(os.path.basename(original))[0] + ext
            date = _photos_date(created, tz_offset)
            if date is not None:
                entry["date"] = date
            if entry:
                out[os.path.join(originals, directory, filename)] = entry
    except sqlite3.Error:
        return out
    finally:
        con.close()
    return out


def _photos_date(created, tz_offset) -> "Optional[_dt.datetime]":
    if created is None:
        return None
    try:
        utc = _dt.datetime(1970, 1, 1) + _dt.timedelta(seconds=float(created) + APPLE_EPOCH)
        if tz_offset is not None:
            return utc + _dt.timedelta(seconds=int(tz_offset))
        # no time zone stored: show it in this Mac's time zone
        return _dt.datetime.fromtimestamp(float(created) + APPLE_EPOCH)
    except (ValueError, OverflowError, OSError, TypeError):
        return None
