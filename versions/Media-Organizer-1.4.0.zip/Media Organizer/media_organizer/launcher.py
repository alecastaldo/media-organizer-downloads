"""Start Media Organizer like an app: in the background, once, with a stable link.

Double-clicking "Media Organizer.command" runs `python3 -m media_organizer launch`:
  * If the app is already running, its page is simply opened in the browser.
  * Otherwise the app is started in the background (it does not need the
    Terminal window), the browser opens when the app is ready, and the
    Terminal window closes itself.
  * The address stays the same between runs (same port when free, and an
    access key stored in the app's data folder), so it can be bookmarked.
  * The app quits from the "Quit" button, or by itself when no page has
    been open for a while and no task is running.
"""

from __future__ import annotations

import json
import os
import secrets
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from typing import Optional

from . import APP_NAME, __version__
from .appdata import data_path, read_json, write_json

STATE_FILE = "server.json"
TOKEN_FILE = "access-key"
LOG_FILE = "server.log"
DEFAULT_PORT = 8765
MAX_LOG_BYTES = 1024 * 1024


def stable_token() -> str:
    """The access key: random, created once, kept in the app's data folder."""
    path = data_path(TOKEN_FILE)
    try:
        with open(path, "r", encoding="utf-8") as f:
            token = f.read().strip()
        if len(token) >= 20:
            return token
    except OSError:
        pass
    token = secrets.token_urlsafe(24)
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(token)
    except OSError:
        pass
    return token


def app_url(port: int, token: str) -> str:
    return f"http://127.0.0.1:{port}/#t={token}"


def write_state(port: int) -> None:
    write_json(STATE_FILE, {"port": port, "pid": os.getpid(), "version": __version__,
                            "started": time.time()})


def clear_state() -> None:
    state = read_json(STATE_FILE, None)
    if isinstance(state, dict) and state.get("pid") == os.getpid():
        try:
            os.unlink(data_path(STATE_FILE))
        except OSError:
            pass


def _pid_alive(pid) -> bool:
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ValueError, TypeError):
        return False


def _responds(port: int, token: str, timeout: float = 2.0) -> bool:
    req = urllib.request.Request(f"http://127.0.0.1:{port}/api/info", headers={"X-Token": token})
    try:
        # never use a proxy for our own address
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(req, timeout=timeout) as r:
            return json.loads(r.read()).get("app") == APP_NAME
    except (urllib.error.URLError, OSError, ValueError):
        return False


def running_instance() -> Optional[dict]:
    """The app already running on this Mac, if any."""
    state = read_json(STATE_FILE, None)
    if not isinstance(state, dict) or not _pid_alive(state.get("pid")):
        return None
    port = int(state.get("port") or 0)
    if port and _responds(port, stable_token()):
        return state
    return None


def _port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def choose_port(preferred: int = DEFAULT_PORT) -> int:
    for port in range(preferred, preferred + 20):
        if _port_free(port):
            return port
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _trim_log(path: str) -> None:
    try:
        if os.path.getsize(path) > MAX_LOG_BYTES:
            with open(path, "rb") as f:
                f.seek(-MAX_LOG_BYTES // 4, os.SEEK_END)
                tail = f.read()
            with open(path, "wb") as f:
                f.write(tail)
    except OSError:
        pass


def _open(url: str) -> bool:
    from . import macos

    return macos.open_url(url)


def close_terminal_window_later() -> None:
    """Close the Terminal window this was started from, after the launcher
    script has finished (macOS only, best effort, never asks anything)."""
    if sys.platform != "darwin":
        return
    try:
        tty = os.ttyname(sys.stdout.fileno())
    except OSError:
        return
    script = (
        "delay 1.5\n"
        'tell application "Terminal"\n'
        "  repeat with w in windows\n"
        "    try\n"
        f'      if tty of selected tab of w is "{tty}" then close w\n'
        "    end try\n"
        "  end repeat\n"
        "end tell\n"
    )
    try:
        subprocess.Popen(["osascript", "-e", script], stdin=subprocess.DEVNULL,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
    except OSError:
        pass


def launch(open_browser: bool = True, close_terminal: bool = True, wait: float = 20.0) -> int:
    say = lambda text="": print("  " + text if text else "", flush=True)  # noqa: E731
    existing = running_instance()
    if existing:
        url = app_url(int(existing["port"]), stable_token())
        say(f"{APP_NAME} is already running: opening it in your browser.")
        say(f"Address (you can bookmark it): {url}")
        if open_browser:
            _open(url)
        if close_terminal:
            close_terminal_window_later()
        return 0

    from .updater import app_dir

    port = choose_port()
    token = stable_token()
    log_path = data_path(LOG_FILE)
    _trim_log(log_path)
    env = dict(os.environ, MEDIA_ORGANIZER_TOKEN=token)
    with open(log_path, "ab") as log:
        proc = subprocess.Popen(
            [sys.executable, "-m", "media_organizer", "serve", "--background", "--port", str(port)],
            cwd=app_dir(), env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True,  # keeps running when this window closes
        )
    say(f"Starting {APP_NAME} {__version__}...")
    deadline = time.time() + wait
    while time.time() < deadline:
        if proc.poll() is not None:
            say("Media Organizer could not start. Details:")
            try:
                with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                    print(f.read()[-3000:], flush=True)
            except OSError:
                pass
            return 1
        if _responds(port, token, timeout=1.0):
            break
        time.sleep(0.2)
    else:
        say("Media Organizer is taking long to start; it will open as soon as it is ready.")
    url = app_url(port, token)
    say()
    say(f"{APP_NAME} is running. It opens in your web browser.")
    say(f"Address (you can bookmark it): {url}")
    say("You can close this window: the app keeps running in the background.")
    say("To quit: click Quit in the app (it also quits by itself when it is not used).")
    say()
    if open_browser and not _open(url):
        say("Could not open the browser automatically: copy the address above into Safari or Chrome.")
        return 0
    if close_terminal:
        close_terminal_window_later()
    return 0
