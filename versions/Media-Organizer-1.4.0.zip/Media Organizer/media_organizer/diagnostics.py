"""Error log, diagnostic report and permission checks.

The error log lives in the app's data folder (never in your archives) and is
trimmed automatically. The diagnostic report is plain text the user can copy
and send when something goes wrong; file and folder names are hidden unless
the user chooses to include them.
"""

from __future__ import annotations

import datetime as _dt
import os
import platform
import re
import sys
import threading
import traceback
from typing import Optional

from . import __version__
from .appdata import app_data_dir, data_path

LOG_FILE = "errors.log"
MAX_LOG_BYTES = 256 * 1024
_lock = threading.Lock()

IS_MAC = sys.platform == "darwin"


def log_error(context: str, message: str, exc: Optional[BaseException] = None) -> None:
    """Append an entry to the error log (best effort, never raises)."""
    try:
        stamp = _dt.datetime.now().isoformat(timespec="seconds")
        text = f"[{stamp}] {context}: {message}\n"
        if exc is not None:
            text += "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
        with _lock:
            path = data_path(LOG_FILE)
            with open(path, "a", encoding="utf-8", errors="replace") as f:
                f.write(text)
            if os.path.getsize(path) > MAX_LOG_BYTES:
                with open(path, "rb") as f:
                    f.seek(-MAX_LOG_BYTES // 2, os.SEEK_END)
                    tail = f.read()
                with open(path, "wb") as f:
                    f.write(b"(older entries removed)\n" + tail[tail.find(b"\n") + 1:])
    except Exception:
        pass


def recent_log(max_chars: int = 6000) -> str:
    try:
        with open(data_path(LOG_FILE), "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    except OSError:
        return ""
    return text[-max_chars:]


# ---------------------------------------------------------------------------
# Permissions (macOS privacy settings)
# ---------------------------------------------------------------------------

# Folders that macOS only lets apps with "Full Disk Access" read.
_FDA_PROBES = ("~/Library/Safari", "~/Library/Mail", "~/Library/Messages",
               "~/Library/Application Support/com.apple.TCC")

SETTINGS_PANES = {
    "full-disk": "x-apple.systempreferences:com.apple.preference.security?Privacy_AllFiles",
    "photos": "x-apple.systempreferences:com.apple.preference.security?Privacy_Photos",
    "files": "x-apple.systempreferences:com.apple.preference.security?Privacy_FilesAndFolders",
    "automation": "x-apple.systempreferences:com.apple.preference.security?Privacy_Automation",
}


def full_disk_access() -> Optional[bool]:
    """True/False when it can be told, None when unknown (not a Mac...)."""
    if not IS_MAC:
        return None
    for probe in _FDA_PROBES:
        path = os.path.expanduser(probe)
        if not os.path.exists(path):
            continue
        try:
            os.listdir(path)
            return True
        except PermissionError:
            return False
        except OSError:
            continue
    return None


def folder_access(path: str) -> dict:
    """Can the app list this folder? Distinguishes 'blocked by macOS'."""
    info = {"exists": os.path.isdir(path), "readable": False, "blocked": False}
    if not info["exists"]:
        return info
    try:
        with os.scandir(path) as it:
            next(it, None)
        info["readable"] = True
    except PermissionError:
        info["blocked"] = True
    except OSError:
        pass
    return info


def permissions() -> dict:
    from . import photos_library

    libs = photos_library.find_libraries(include_disks=False) if IS_MAC else []
    return {
        "mac": IS_MAC,
        "full_disk_access": full_disk_access(),
        "photos_libraries": [{"library": l["library"], "readable": l["readable"]} for l in libs],
    }


# ---------------------------------------------------------------------------
# Diagnostic report
# ---------------------------------------------------------------------------

# Paths may contain spaces (very common on a Mac), so a path runs until a
# closing quote, or until ": ", " - ", " (" or the end of the line - the way
# the app writes its messages ("Cannot read /Volumes/My Disk/a b.jpg: ...").
_QUOTED_PATH = re.compile(r"""(['"])(?:~|/)[^'"\n]*\1""")
_PLAIN_PATH = re.compile(r"(?<![\w.])(?:~/|/)[^\n'\"]*?(?=: | - | \(|,\s|$)", re.M)


def _hide_paths(text: str) -> str:
    text = _QUOTED_PATH.sub(lambda m: m.group(1) + "<path>" + m.group(1), text)
    return _PLAIN_PATH.sub("<path>", text)


def report(include_paths: bool = False, job: Optional[dict] = None) -> str:
    """Plain-text report. Without include_paths, names of the user's files and
    folders are replaced by <path>; locations inside the app are kept (they
    tell which part of the app failed) and the home folder is shown as ~."""
    from . import updater

    app = updater.app_dir()
    home = os.path.expanduser("~")

    def private(text: str) -> str:
        text = text.replace(app, "APP")
        if include_paths:
            return text.replace(home, "~")
        text = text.replace(home, "~")
        return _hide_paths(text)

    mac_ver = platform.mac_ver()[0] if IS_MAC else ""
    perms = permissions()
    lines = [
        "Media Organizer diagnostic report",
        f"Created: {_dt.datetime.now().isoformat(timespec='seconds')}",
        f"App version: {__version__}",
        f"System: {'macOS ' + mac_ver if mac_ver else platform.platform()} ({platform.machine()})",
        f"Python: {platform.python_version()} ({sys.executable})",
        f"App folder: {app.replace(home, '~')}",
        f"Data folder: {app_data_dir().replace(home, '~')}",
        f"Full Disk Access: {_yes_no(perms['full_disk_access'])}",
        f"File and folder names included: {'yes' if include_paths else 'no'}",
    ]
    for lib in perms["photos_libraries"]:
        lines.append(f"Photos library: {private(lib['library'])} (readable: {_yes_no(lib['readable'])})")
    if job:
        lines.append(private(f"Last task: {job.get('kind')} - {job.get('state')}"
                             + (f" - {job.get('error')}" if job.get("error") else "")))
    log = recent_log()
    lines.append("")
    lines.append("Recent errors:" if log else "Recent errors: none")
    if log:
        lines.append(private(log.rstrip()))
    return "\n".join(lines)


def _yes_no(value: Optional[bool]) -> str:
    return "unknown" if value is None else ("yes" if value else "no")
