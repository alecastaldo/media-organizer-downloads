"""Small macOS integrations (folder picker, Finder, thumbnails, Trash).

Everything degrades gracefully on other systems so the app can also be
tested on Linux.
"""

from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import threading
from typing import List, Optional

from .appdata import app_data_dir

IS_MAC = sys.platform == "darwin"
_thumb_slots = threading.BoundedSemaphore(max(2, min(6, (os.cpu_count() or 4) - 2)))
_prefetch_lock = threading.Lock()
_pending = {}  # path -> threading.Event while a thumbnail is being made


def _osascript(lines: List[str], timeout: int = 600) -> subprocess.CompletedProcess:
    args = ["osascript"]
    for line in lines:
        args += ["-e", line]
    return subprocess.run(args, capture_output=True, text=True, timeout=timeout)


def _as_string(text: str) -> str:
    return '"' + text.replace("\\", "\\\\").replace('"', '\\"') + '"'


def choose_folder(prompt: str = "Choose a folder") -> Optional[str]:
    """Show the native macOS folder picker. Returns None if cancelled."""
    if not IS_MAC:
        return None
    res = _osascript([
        "activate",
        f"set f to choose folder with prompt {_as_string(prompt)} with showing package contents",
        "POSIX path of f",
    ])
    if res.returncode != 0:
        return None
    path = res.stdout.strip()
    if len(path) > 1:
        path = path.rstrip("/")
    return path or None


def choose_folders(prompt: str = "Choose folders") -> List[str]:
    """Native picker allowing several folders at once (⌘-click to select more)."""
    if not IS_MAC:
        return []
    res = _osascript([
        "activate",
        f"set fs to choose folder with prompt {_as_string(prompt)} "
        "with multiple selections allowed and showing package contents",
        'set out to ""',
        "repeat with f in fs",
        "set out to out & (POSIX path of (f as alias)) & linefeed",
        "end repeat",
        "return out",
    ])
    if res.returncode != 0:
        return []
    paths = []
    for line in res.stdout.splitlines():
        line = line.strip()
        if line:
            paths.append(line.rstrip("/") if len(line) > 1 else line)
    return paths


def open_url(url: str) -> bool:
    """Open a web address in the default browser. Returns True on success."""
    if IS_MAC:
        # /usr/bin/open is what Finder uses; Python 3.9's webbrowser module goes
        # through an AppleScript route that fails silently on recent macOS.
        try:
            return subprocess.run(["/usr/bin/open", url], capture_output=True, timeout=30).returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False
    import webbrowser

    try:
        return bool(webbrowser.open(url))
    except Exception:
        return False


def reveal_in_finder(path: str) -> bool:
    if IS_MAC:
        return subprocess.run(["open", "-R", path]).returncode == 0
    return False


def open_file(path: str) -> bool:
    if IS_MAC:
        return subprocess.run(["open", path]).returncode == 0
    return False


def move_to_trash(path: str) -> Optional[str]:
    """Move a file/folder to the Trash via Finder. Returns an error text or None."""
    if not IS_MAC:
        return "Moving to the Trash is only available on macOS."
    res = _osascript([
        f"tell application \"Finder\" to delete (POSIX file {_as_string(path)} as alias)"
    ], timeout=3600)
    if res.returncode != 0:
        msg = res.stderr.strip()
        if "-1743" in msg or "Not authorized" in msg:
            return ("macOS did not allow Media Organizer to control Finder. Allow it in "
                    "System Settings > Privacy & Security > Automation, or drag the folder "
                    "to the Trash yourself.")
        return msg or "Finder could not move the folder to the Trash."
    return None


def list_places() -> List[dict]:
    """Useful starting points: home folders and connected external disks."""
    places = []
    home = os.path.expanduser("~")
    for label, path in [
        ("Pictures", os.path.join(home, "Pictures")),
        ("Movies", os.path.join(home, "Movies")),
        ("Downloads", os.path.join(home, "Downloads")),
        ("Desktop", os.path.join(home, "Desktop")),
        ("Home", home),
    ]:
        if os.path.isdir(path):
            places.append({"label": label, "path": path, "kind": "folder"})
    volumes = "/Volumes" if IS_MAC else "/media"
    try:
        for name in sorted(os.listdir(volumes)):
            path = os.path.join(volumes, name)
            if name.startswith(".") or not os.path.isdir(path):
                continue
            if IS_MAC and os.path.realpath(path) == "/":
                continue  # the Mac's own disk
            places.append({"label": name, "path": path, "kind": "disk"})
    except OSError:
        pass
    _add_free_space([p for p in places if p["kind"] == "disk"])
    return places


def _add_free_space(disks: List[dict], timeout: float = 1.5) -> None:
    """Free space per disk, but never wait long for a sleeping or network disk."""
    if not disks:
        return
    from concurrent.futures import ThreadPoolExecutor, wait

    pool = ThreadPoolExecutor(max_workers=min(8, len(disks)))
    futures = {pool.submit(shutil.disk_usage, d["path"]): d for d in disks}
    done, _ = wait(futures, timeout=timeout)
    for fut in done:
        try:
            u = fut.result()
            futures[fut].update(free=u.free, total=u.total)
        except OSError:
            pass
    pool.shutdown(wait=False)


VIDEO_EXTS = {".mov", ".mp4", ".m4v", ".insv", ".360", ".avi", ".mts", ".m2ts", ".mkv", ".3gp", ".mpg", ".mpeg", ".wmv", ".webm"}
PREVIEWABLE = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}


THUMB_SIZE = 280  # shown at 140 px, sharp on Retina screens


def prefetch_thumbnails(paths: List[str]) -> None:
    """Start making previews in the background, before the browser asks."""
    if not IS_MAC:
        return
    todo = []
    with _prefetch_lock:
        for p in paths:
            if p not in _pending:
                _pending[p] = threading.Event()
                todo.append(p)
    for p in todo:
        threading.Thread(target=_prefetch_one, args=(p,), daemon=True).start()


def _prefetch_one(path: str) -> None:
    try:
        _make_thumbnail(path, THUMB_SIZE)
    finally:
        with _prefetch_lock:
            ev = _pending.pop(path, None)
        if ev:
            ev.set()


def thumbnail(path: str, size: int = THUMB_SIZE) -> Optional[str]:
    """Return a path to a small PNG preview of any photo or video."""
    with _prefetch_lock:
        ev = _pending.get(path)
    if ev is not None:
        ev.wait(timeout=40)
    return _make_thumbnail(path, size)


def _make_thumbnail(path: str, size: int) -> Optional[str]:
    try:
        st = os.stat(path)
    except OSError:
        return None
    key = hashlib.sha1(f"{path}|{st.st_size}|{st.st_mtime_ns}|{size}".encode("utf-8", "surrogateescape")).hexdigest()
    cache = os.path.join(app_data_dir(), "thumbnails")
    os.makedirs(cache, exist_ok=True)
    out = os.path.join(cache, key + ".png")
    if os.path.exists(out):
        return out
    if not IS_MAC:
        ext = os.path.splitext(path)[1].lower()
        return path if ext in PREVIEWABLE else None
    with _thumb_slots:
        # Quick Look understands HEIC, RAW and videos.
        tmpdir = os.path.join(cache, "tmp-" + key)
        os.makedirs(tmpdir, exist_ok=True)
        try:
            subprocess.run(
                ["qlmanage", "-t", "-s", str(size), "-o", tmpdir, path],
                capture_output=True, timeout=30,
            )
            produced = [f for f in os.listdir(tmpdir) if f.endswith(".png")]
            if produced:
                os.replace(os.path.join(tmpdir, produced[0]), out)
                return out
            res = subprocess.run(
                ["sips", "-s", "format", "png", "-Z", str(size), path, "--out", out],
                capture_output=True, timeout=30,
            )
            if res.returncode == 0 and os.path.exists(out):
                return out
        except (OSError, subprocess.SubprocessError):
            pass
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)
    return None
