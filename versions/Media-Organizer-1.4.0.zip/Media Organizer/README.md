# Media Organizer

A simple app for your Mac that helps you:

1. **Find exact duplicate photos and videos**, even across several external disks, and remove the extra copies **safely** (nothing is deleted: extras go to a quarantine folder you can undo).
2. **Analyze your folders and suggest the best structure** for your archive: folders by year/month, keeping trip or event names, a folder per camera, clearer file names. You see a preview of the folders before anything happens.
3. **Copy photos and videos into that archive**, from iPhone, **iCloud Photos**, DJI drones, GoPro, Insta360, Android phones and cameras. Files already in the archive are skipped.

It runs **only on your Mac**. The window opens in your web browser, but the "website" comes from the Mac itself (address `127.0.0.1`). No internet connection is needed, and no photo, file name or data ever leaves your computer.

Works on any Mac with **macOS 11 Big Sur or newer**, including **Apple Silicon (M1/M2/M3/M4)** and Intel. It reads internal disks, external USB/Thunderbolt disks, SD cards and network drives.

---

## Install (about 5 minutes, only the first time)

1. Download the app: **https://github.com/alecastaldo/media-organizer-downloads/raw/main/Media-Organizer.zip**
   (download page with instructions: https://github.com/alecastaldo/media-organizer-downloads).
2. Open your **Downloads** folder and double-click the ZIP if Safari did not already unzip it. A folder called `Media Organizer` appears.
3. Move that folder somewhere permanent, for example into your **Documents** or **Applications** folder.
4. Open the folder and **double-click `Media Organizer.command`**.

The first time, macOS protects you from apps downloaded from the internet:

- **macOS 15 Sequoia or newer:** a message says it "could not verify" the file. Click **Done**. Open **System Settings → Privacy & Security**, scroll down, click **Open Anyway** next to "Media Organizer.command" and confirm with your password. Then double-click the file again.
- **macOS 14 or older:** right-click (or Control-click) `Media Organizer.command` → **Open** → **Open**.

If macOS asks to install the **Command Line Tools**, click **Install** and wait until they finish. They are free from Apple and include Python, which the app runs on. Then press **Enter** in the Terminal window.

The app opens in your browser. A **Terminal** window appears for a moment while it starts and then closes by itself: the app keeps running in the background.

- **Bookmark the page.** The address stays the same every time, so the bookmark keeps working whenever the app is running.
- **Double-clicking `Media Organizer.command` again** while the app is running just opens it in the browser. It never starts a second copy.
- **To quit,** click **Quit** at the top right. The app also quits by itself about 20 minutes after you close its page, but never while a task is running.

> **Alternative if double-clicking doesn't work:** open the **Terminal** app, type `bash ` (with a space), drag `Media Organizer.command` into the Terminal window, and press Enter.

### Updating (no need to delete or copy anything)

Click **Check for updates** at the top right of the app.

- The app looks for a newer version and tells you which version it found and where it comes from. **Nothing is installed until you click Install.**
- It then updates itself in its own folder and asks to restart. The page reloads by itself.
- It never installs an older version, and it only replaces the app's own files. Your settings, history and quarantine folders are kept.
- If the app cannot reach the internet by itself, it gives you a link. Download the file with your browser and click **I have downloaded it**: the app shows the file it found in your **Downloads** folder and asks before installing. It never picks up files from Downloads on its own.
- If the app does not start, double-click **Update Media Organizer.command** in the app folder instead: it asks the same questions in the Terminal window.

### Something went wrong?

Click **Report a problem** (top right) and then **Copy report**. Send the report together with a short description and, if possible, a screenshot.

The report contains the app, macOS and Python versions, whether macOS permissions are granted, and the most recent errors. **Names of your files and folders are hidden** unless you tick the box to include them. The app keeps a small error log in its data folder, which is trimmed automatically.

**Help → Setup check** shows whether macOS lets the app read external disks and the Photos library, with a button to open the right System Settings page. When macOS blocks a folder you add, the app says so instead of just reporting that it "cannot read" it.

### Permissions (for external disks and iCloud Photos)

- The first time you use an external disk, macOS asks *"Terminal would like to access files on a removable volume"*. Click **Allow**.
- To read the **Photos library** (iCloud Photos), or if a folder "cannot be read": open **System Settings → Privacy & Security → Full Disk Access**, turn on **Terminal**, then click **Quit** in the app and open Media Organizer again.

---

## How to use it

### Organize your archive (with a suggested structure)

1. Go to **Organize archive**.
2. **Step 1:** add the folders you want to organize: old photo folders, an SD card, an external disk, or **iCloud Photos** (see below).
3. **Step 2:** choose where the organized archive should be, for example `/Volumes/MyDisk/Photo Archive`. It can be a new folder or your existing archive.
4. **Step 3:** click **Analyze my folders & propose a structure**. The app reads the dates and cameras of your files and your folder names, then:
   - shows how many files you have per year, from which devices, and which folder names look like events ("Hawaii", "Wedding Anna");
   - **selects the recommended options** and explains each one in a short sentence;
   - shows a **preview of the folder tree** that will be created. Change any option and the preview updates immediately.
5. Click **Preview file by file** to see exactly where each file would go. Nothing is copied yet.
6. Click **Copy into archive**. Each file is copied, **read back and verified**, and only then saved under its final name.

Example of a resulting archive:

```
Photo Archive/
  2023/
    2023-07 Hawaii/
      iPhone 13 Pro/   2023-07-15 18.02.11 IMG_1234.HEIC
      GoPro/           2023-07-16 10.11.00 GX010001.MP4
    2023-08/
  2024/
    2024-06/
      DJI/             2024-06-10 12.00.00 DJI_20240610120000_0001_D.MP4
  Import Logs (Media Organizer)/   (a list of every import)
```

Your original files are **never** moved, changed or deleted, and nothing already in the archive is ever overwritten. You can safely import the same SD card twice: files already in the archive are skipped.

### Folders inside folders: everything is normalized

All tools look through **every sub-folder, at any depth**. However the files are spread out (camera dumps like `DCIM/100APPLE`, `Trips/Rome 2019/day 2`, old backups), each photo and video gets its place in the one structure you chose.

- A trip or event name is taken from the nearest meaningful folder above the file. For example, "Rome 2019" is kept, while "day 2", "Trips", "SD card 1" or "DCIM" are ignored.
- **The archive remembers its structure.** A small hidden file (`.media-organizer.json`) in the archive stores the settings used. The next time you pick that archive, the same settings are selected automatically, so new files are filed exactly like the old ones. For an archive you organized by hand, the app detects the existing pattern (e.g. `2023/2023-07`) and follows it.
- **Running things again is safe and changes nothing.**
  - Files already in the archive are skipped on import.
  - Files already in the right place are not moved.
  - Date prefixes in names are never doubled.
  - The app's own camera folders are not mistaken for event names.

### Tidy up an existing archive

In **Organize archive**, choose the archive in step 2, pick (or analyze) the structure in step 3, then use **Tidy up the archive itself**.

- It **moves** the photos and videos already inside the archive into that structure, at any depth.
- Nothing is copied, deleted or overwritten.
- Identical copies are left for *Find duplicates*.
- Folders left empty are removed.
- **Undo** moves everything back.

Always start with **Preview tidy-up**, which shows every planned move and changes nothing.

### Find and remove duplicates

1. Go to **Find duplicates** and add the folders or disks to check. Adding several at once finds copies that are spread across them.
   - In the Finder window that opens, hold **⌘ (Command)** to select several folders at once.
   - Or paste several paths, one per line. In Finder, select folders and press **⌥⌘C** (Option-Command-C) to copy their paths.
2. Optionally choose your main archive as the folder whose copies should be kept first.
3. Click **Find duplicates**. For large disks this can take a while; you can cancel at any time.
4. **Folders that contain the same files** compares folders two by two. For example: *"Folders 1 and 2 share 1,240 identical files (18 GB could be freed). Suggestion: keep only the copies in folder 1, because the other folder's name suggests a backup."*
   - One click keeps a whole folder's copies: **Keep copies in folder 1**, **Keep copies in folder 2**, or **Leave both alone**.
   - A backup of a whole folder tree shows up as **one** comparison, not one per sub-folder.
   - Files saved twice inside the same folder are listed separately.
5. Fine-tune single files below if needed. Each box is one photo or video that exists several times. The green **KEEP** copy stays where it is. Click another copy to keep that one instead, or tick **Leave this one alone**.
6. Click **Move extra copies to quarantine**.

### Undo

In **Quarantine & undo**, **Restore all** puts every file back exactly where it was. When you are sure, click **Move to Trash**, then empty the Trash in Finder to free the space.

---

## Why you can trust that a "duplicate" is really a duplicate

- Two files count as duplicates only if **every byte is identical**. The app compares sizes, then the SHA-256 fingerprint of the whole file, and **right before moving anything it compares both files byte by byte again**.
- Photos that only *look* the same (edited, resized, re-exported as JPEG, HEIC vs JPEG) are **not** treated as duplicates and are never touched.
- One copy of each file is **always kept**. If the kept copy is missing or anything has changed since the scan, nothing is moved.
- Extra copies are **moved, not deleted**. Each quarantine folder contains a `manifest.json` listing where every file came from and which identical copy was kept.
- Files inside the **Photos library**, Lightroom catalogs, iMovie and Final Cut libraries are never modified. Changing them by hand could damage the library.
- Symbolic links are not followed. The same file reached twice (overlapping folders, hard links) is recognized and never reported as its own duplicate.
- macOS helper files (`._IMG_1234.JPG`, `.DS_Store`) are ignored.

---

## Wrong dates (for example photos downloaded from iCloud)

Downloaded, AirDropped or copied photos often show the **download date** in Finder, even though the real date is saved inside the photo. Media Organizer handles this:

- **Organizing always uses the real date.** It is read from inside the file (EXIF, XMP, video metadata). Photos imported from the Photos library use the exact date shown in Photos, including dates you corrected with *Image → Adjust Date and Time*.
- **Copies in your archive show the right date in Finder.** Their *Date Created* and *Date Modified* are set to the date taken. You can turn this off in step 3.
- **Fix dates** tab: corrects files you already have.
  1. Add the folders.
  2. Click **Check dates** to see what would change.
  3. Click **Fix dates**.

  Only the dates Finder shows change; the photos themselves are not touched. Every run can be undone.
- Files with **no date inside** (screenshots, images saved from apps or WhatsApp, some edited exports) are listed and left unchanged. If they are in your Photos library, import them from there so the app can use the date Photos knows.

## Getting your photos out of iCloud

**Option A: through the Photos app (recommended, keeps the originals)**

1. Open **Photos → Settings… → iCloud** and select **Download Originals to this Mac**.
   You need enough free space. You can first move the Photos library to an external disk: quit Photos, drag the library to the disk, then open it by holding **Option** while starting Photos.
2. Wait until Photos has finished downloading (the status is shown at the bottom of the Library view).
3. In Media Organizer → **Organize archive**, click **iCloud Photos (Photos library)** → **Import from this library**. Files get their original iPhone names (IMG_1234.HEIC). Only the originals are imported, not edited versions.

**Option B: from icloud.com**

Go to [icloud.com/photos](https://www.icloud.com/photos), select photos, click download, double-click the ZIP you get, then add that folder in **Organize archive**.

---

## Supported files

| | |
|---|---|
| Photos | JPEG, HEIC/HEIF, PNG, GIF, TIFF, WebP, AVIF, DNG/ProRAW and RAW (Canon CR2/CR3, Nikon NEF, Sony ARW, Fuji RAF, Olympus ORF, Panasonic RW2, Pentax PEF, GoPro GPR…), Insta360 INSP |
| Videos | MOV, MP4, M4V (iPhone, DJI, GoPro, Insta360, Android), 360, INSV, AVI, MTS/M2TS, MKV, 3GP, MPG, WMV, WebM |
| Travel with their file | iPhone edits `.AAE`, Lightroom `.XMP`, DJI flight data `.SRT` |
| Ignored | GoPro/DJI preview files `.THM`, `.LRV`, `.LRF` |

The capture date is read from the file itself (EXIF or video metadata). iPhone videos use the local time of the place where they were shot. If a file has no date inside, the date in the file name is used (`DJI_20240610…`, `PXL_2024…`, `IMG-2024…-WA…`), and as a last resort the file's date on disk. The app tells you how many files fall into that last case.

## Disk formats

| Format | Scan / import from | Remove duplicates / use as archive |
|---|---|---|
| APFS, Mac OS Extended | ✅ | ✅ |
| exFAT, FAT32 (SD cards, many USB disks) | ✅ | ✅ |
| NTFS (Windows disks) | ✅ | ❌ macOS cannot write to NTFS |

---

## Troubleshooting

- **The browser window didn't open.** Double-click `Media Organizer.command` again: if the app is running, it opens the page.
- **"Media Organizer is not running".** The app was quit, or it quit by itself because it was not used. Double-click `Media Organizer.command` again. An old address copied from a Terminal window works again as soon as the app runs.
- **A folder or disk can't be read.** Give Terminal **Full Disk Access** (see *Permissions*) and restart the app.
- **"Move to Trash" doesn't work.** macOS asks for permission for Terminal to control Finder. Allow it in **System Settings → Privacy & Security → Automation**, or open the quarantine folder with **Show in Finder** and drag it to the Trash yourself.
- **I want a fresh start.** Everything the app remembers (the file-fingerprint cache for faster re-scans, the list of quarantine folders) is in `~/Library/Application Support/Media Organizer`. It is safe to delete.

## For the technically curious

- Pure Python 3.9+ standard library: no packages to install and nothing downloaded.
- Releases:
  1. Raise `__version__` in `media_organizer/__init__.py` and commit.
  2. Run `python3 tools/make_release.py`.
  3. Publish `dist/Media-Organizer.zip` (plus the versioned copy) in the public `media-organizer-downloads` repository.

  The updater downloads from there and only installs a higher version.
- `python3 -m media_organizer launch` starts the app in the background (what the launcher does). `python3 -m media_organizer` runs it in the current Terminal window instead. `python3 -m media_organizer find-duplicates FOLDER…` lists duplicates in the terminal without changing anything.
- Tests: `python3 -m unittest discover -s tests -t .`. They also run automatically on GitHub on an Apple Silicon Mac (Python 3.9 and 3.12).
