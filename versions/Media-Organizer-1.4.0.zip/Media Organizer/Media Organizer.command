#!/bin/bash
# Double-click this file to start Media Organizer.
# (First time: see the README for the macOS "Open Anyway" step.)

cd "$(dirname "$0")" || exit 1
clear
echo "=============================================="
echo "  Media Organizer"
echo "=============================================="

find_python() {
  for candidate in \
      /opt/homebrew/bin/python3 \
      /usr/local/bin/python3 \
      /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
      /usr/bin/python3; do
    if [ -x "$candidate" ] && "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)' >/dev/null 2>&1; then
      echo "$candidate"
      return 0
    fi
  done
  return 1
}

PYTHON="$(find_python)"
if [ -z "$PYTHON" ]; then
  echo ""
  echo "  Media Organizer needs Apple's free 'Command Line Tools' (they include Python)."
  echo "  A window from Apple will now ask to install them: click 'Install' and wait"
  echo "  until it says the software was installed (a few minutes)."
  echo ""
  xcode-select --install >/dev/null 2>&1
  read -r -p "  When the installation has finished, press Enter here to continue... " _
  PYTHON="$(find_python)"
  if [ -z "$PYTHON" ]; then
    echo ""
    echo "  Python is still not available. Please finish the Command Line Tools"
    echo "  installation and double-click Media Organizer again."
    read -r -p "  Press Enter to close. " _
    exit 1
  fi
fi

# Starts the app in the background (or opens it if it is already running).
# The app does not need this window: it closes by itself.
"$PYTHON" -m media_organizer launch
STATUS=$?
if [ $STATUS -ne 0 ]; then
  echo ""
  echo "  Media Organizer could not start (code $STATUS)."
  echo "  In the app use 'Report a problem', or send a screenshot of this window."
  read -r -p "  Press Enter to close. " _
fi
exit $STATUS
