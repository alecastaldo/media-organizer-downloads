"""Local web interface. Runs on 127.0.0.1 only; nothing leaves the Mac."""

from __future__ import annotations

import json
import mimetypes
import os
import secrets
import socket
import sys
import threading
import time
import traceback
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Callable, Optional
from urllib.parse import parse_qs, urlparse

from . import APP_NAME, __version__, macos, photos_library, updater
from . import archive_settings, reorganize as reorg
from .analyzer import analyze, preview_tree, recommend_for_archive, summary
from .filedates import fix_dates, list_runs, undo_run
from .metadata import read_media_info
from .duplicates import (
    Progress,
    folder_comparison,
    keep_folder,
    leave_pair_alone,
    ScanResult,
    find_duplicates,
    forget_session,
    list_sessions,
    quarantine_duplicates,
    restore_session,
)
from .importer import LAYOUTS, ImportOptions, ImportResult, run_import

STARTED = time.time()  # changes when the app restarts after an update
WEB_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "web")


class Job:
    def __init__(self, kind: str, target: Callable[[Progress], object]):
        self.kind = kind
        self.progress = Progress()
        self.state = "running"  # running / done / failed / cancelled
        self.error = ""
        self.result = None
        self.started = time.time()
        self.finished = None
        self._thread = threading.Thread(target=self._run, args=(target,), daemon=True)

    def start(self):
        self._thread.start()

    def _run(self, target):
        try:
            self.result = target(self.progress)
            self.state = "cancelled" if self.progress.cancel_requested else "done"
        except ValueError as exc:
            self.state, self.error = "failed", str(exc)
        except Exception as exc:  # report, never crash the server
            traceback.print_exc()
            self.state, self.error = "failed", f"Unexpected error: {exc}"
        self.finished = time.time()

    def status(self) -> dict:
        p = self.progress
        return {
            "kind": self.kind,
            "state": self.state,
            "error": self.error,
            "phase": p.phase,
            "done": p.done,
            "total": p.total,
            "current": p.current,
            "elapsed": round((self.finished or time.time()) - self.started, 1),
        }


class AppState:
    def __init__(self):
        # Kept across an in-place update restart, so the open page keeps working.
        self.token = os.environ.get("MEDIA_ORGANIZER_TOKEN") or secrets.token_urlsafe(24)
        self.port = None
        self.last_update = None
        self.lock = threading.Lock()
        self.job: Optional[Job] = None
        self.scan: Optional[ScanResult] = None
        self.last_apply = None
        self.last_import: Optional[ImportResult] = None
        self.last_restore = None
        self.analysis = None
        self.last_dates = None
        self.last_reorg = None
        self.taken_cache = {}
        self.recommendation = None

    def start_job(self, kind, target) -> Job:
        with self.lock:
            if self.job and self.job.state == "running":
                raise ValueError("Another task is still running. Wait for it or cancel it first.")
            self.job = Job(kind, target)
            self.job.start()
            return self.job


STATE = AppState()


def _taken(path: str, mtime: float):
    """Date taken (from inside the file), cached for the result pages."""
    key = (path, mtime)
    if key not in STATE.taken_cache:
        try:
            info = read_media_info(path)
            STATE.taken_cache[key] = (
                info.date.strftime("%Y-%m-%d %H:%M"), info.date_source
            ) if info.date_source != "file date" else (None, None)
        except OSError:
            STATE.taken_cache[key] = (None, None)
    return STATE.taken_cache[key]


def _file_dict(scan: ScanResult, g, i: int) -> dict:
    e = g.files[i]
    taken, taken_source = _taken(e.path, e.mtime)
    return {
        "taken": taken,
        "taken_source": taken_source,
        "index": i,
        "path": e.path,
        "name": os.path.basename(e.path),
        "folder": os.path.dirname(e.path),
        "mtime": e.mtime,
        "exists": os.path.exists(e.path),
    }


def _group_dict(scan: ScanResult, g) -> dict:
    return {
        "id": g.id,
        "size": g.size,
        "sha256": g.sha256,
        "keep": g.keep,
        "skip": g.skip,
        "is_video": os.path.splitext(g.files[0].path)[1].lower() in macos.VIDEO_EXTS,
        "files": [_file_dict(scan, g, i) for i in range(len(g.files))],
    }


def _import_dict(r: ImportResult, limit: int = 3000) -> dict:
    statuses = ["copied", "would copy", "moved", "would move", "in place", "duplicate", "error"]
    items = r.items
    # show problems first, then everything else
    ordered = [i for i in items if i.status == "error"] + [i for i in items if i.status != "error"]
    return {
        "dry_run": r.options.dry_run,
        "destination": r.options.destination,
        "cancelled": r.cancelled,
        "log_file": r.log_file,
        "counts": {s: r.count(s) for s in statuses},
        "bytes": {s: r.bytes(s) for s in statuses},
        "date_sources": {
            s: sum(1 for i in items if i.date_source == s)
            for s in ("metadata", "Photos library", "file name", "file date")
        },
        "errors": r.errors[:500],
        "total_items": len(items),
        "items": [i.__dict__ for i in ordered[:limit]],
    }


def _outcome_dict(o) -> dict:
    return {
        "moved": len(o.moved),
        "moved_bytes": o.moved_bytes,
        "skipped": o.skipped[:1000],
        "sessions": o.sessions,
    }


class Handler(BaseHTTPRequestHandler):
    server_version = "MediaOrganizer/" + __version__
    # Keep connections open between requests: noticeably snappier in Chrome,
    # which otherwise opens a new connection for every thumbnail and click.
    protocol_version = "HTTP/1.1"
    timeout = 120  # close idle connections

    def log_message(self, fmt, *args):  # keep the Terminal window quiet
        pass

    # -- helpers -----------------------------------------------------------
    def _send_json(self, value, status=HTTPStatus.OK):
        body = json.dumps(value, ensure_ascii=True).encode("ascii")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _send_error(self, message, status=HTTPStatus.BAD_REQUEST):
        self._send_json({"error": message}, status)

    def _send_file(self, path, content_type=None, cache=False):
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type or mimetypes.guess_type(path)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "max-age=3600" if cache else "no-store")
        self.end_headers()
        self.wfile.write(data)

    def _authorized(self, query) -> bool:
        token = self.headers.get("X-Token") or (query.get("t") or [""])[0]
        return secrets.compare_digest(token, STATE.token)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0:
            return {}
        raw = self.rfile.read(length)
        try:
            value = json.loads(raw.decode("utf-8"))
        except ValueError:
            return {}
        return value if isinstance(value, dict) else {}

    def _local_host(self) -> bool:
        # Protects against DNS-rebinding: only accept requests addressed to us.
        host = (self.headers.get("Host") or "").split(":")[0]
        return host in ("127.0.0.1", "localhost")

    # -- routing -------------------------------------------------------------
    def do_GET(self):
        if not self._local_host():
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        url = urlparse(self.path)
        q = parse_qs(url.query)
        if url.path in ("/", "/index.html"):
            return self._send_file(os.path.join(WEB_DIR, "index.html"), "text/html; charset=utf-8")
        if url.path.startswith("/static/"):
            name = os.path.basename(url.path)
            return self._send_file(os.path.join(WEB_DIR, name))
        if not url.path.startswith("/api/"):
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        if not self._authorized(q):
            return self._send_error("Not authorized. Please reopen the app.", HTTPStatus.FORBIDDEN)
        try:
            self._api_get(url.path, q)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:
            traceback.print_exc()
            self._send_error(f"Unexpected error: {exc}", HTTPStatus.INTERNAL_SERVER_ERROR)

    def do_POST(self):
        if not self._local_host():
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        url = urlparse(self.path)
        body = self._body()  # always read it, so the connection stays usable
        if not self._authorized({}):
            return self._send_error("Not authorized. Please reopen the app.", HTTPStatus.FORBIDDEN)
        try:
            self._api_post(url.path, body)
        except ValueError as exc:
            self._send_error(str(exc))
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:
            traceback.print_exc()
            self._send_error(f"Unexpected error: {exc}", HTTPStatus.INTERNAL_SERVER_ERROR)

    def _api_get(self, path, q):
        if path == "/api/info":
            return self._send_json({
                "app": APP_NAME,
                "version": __version__,
                "started": STARTED,
                "mac": macos.IS_MAC,
                "home": os.path.expanduser("~"),
                "layouts": list(LAYOUTS),
            })
        if path == "/api/places":
            return self._send_json({"places": macos.list_places()})
        if path == "/api/photos-libraries":
            return self._send_json({"libraries": photos_library.find_libraries()})
        if path == "/api/job":
            job = STATE.job
            return self._send_json({"job": job.status() if job else None})
        if path == "/api/duplicates":
            scan = STATE.scan
            if scan is None:
                return self._send_json({"scan": None})
            page = max(0, int((q.get("page") or ["0"])[0]))
            per = min(200, max(1, int((q.get("per") or ["30"])[0])))
            groups = scan.groups[page * per : (page + 1) * per]
            macos.prefetch_thumbnails([g.files[0].path for g in groups])
            return self._send_json({
                "scan": {
                    "roots": scan.roots,
                    "preferred": scan.preferred,
                    "files_scanned": scan.files_scanned,
                    "bytes_scanned": scan.bytes_scanned,
                    "group_count": len(scan.groups),
                    "redundant_files": scan.redundant_files,
                    "redundant_bytes": scan.redundant_bytes,
                    **_selected(scan),
                    "errors": scan.errors[:300],
                    "skipped_bundles": scan.skipped_bundles,
                    "cancelled": scan.cancelled,
                    "page": page,
                    "per": per,
                    "groups": [_group_dict(scan, g) for g in groups],
                },
                "last_apply": STATE.last_apply,
            })
        if path == "/api/analysis":
            a = STATE.analysis
            if a is None:
                return self._send_json({"analysis": None})
            rec = STATE.recommendation
            return self._send_json({"analysis": {
                "summary": summary(a),
                "recommendation": rec,
                "tree": preview_tree(a, _options_from(rec, q.get("dest", [""])[0])),
            }})
        if path == "/api/duplicates/folders":
            scan = STATE.scan
            return self._send_json({"folders": folder_comparison(scan) if scan else []})
        if path == "/api/dates":
            r = STATE.last_dates
            data = None
            if r is not None:
                order = {"error": 0, "would fix": 1, "fixed": 1, "no date": 2, "already right": 3}
                items = sorted(r.items, key=lambda i: order.get(i.status, 9))
                data = {
                    "dry_run": r.dry_run,
                    "roots": r.roots,
                    "cancelled": r.cancelled,
                    "counts": {k: r.count(k) for k in ("fixed", "would fix", "already right", "no date", "error")},
                    "errors": r.errors[:300],
                    "total_items": len(items),
                    "items": [i.__dict__ for i in items[:2000]],
                }
            return self._send_json({"result": data, "runs": list_runs()})
        if path == "/api/update":
            return self._send_json({"version": __version__, "result": STATE.last_update})
        if path == "/api/archive-settings":
            archive = os.path.abspath(os.path.expanduser((q.get("path") or [""])[0]))
            exists = os.path.isdir(archive)
            return self._send_json({
                "saved": archive_settings.load(archive) if exists else None,
                "detected": archive_settings.infer_layout(archive) if exists else None,
            })
        if path == "/api/reorganize":
            r = STATE.last_reorg
            data = None
            if r is not None:
                data = _import_dict(r)
                data["run_id"] = r.run_id
            return self._send_json({"result": data, "runs": reorg.list_runs()})
        if path == "/api/import":
            r = STATE.last_import
            return self._send_json({"result": _import_dict(r) if r else None})
        if path == "/api/quarantine":
            return self._send_json({"sessions": list_sessions(), "last_restore": STATE.last_restore})
        if path == "/api/thumb":
            entry = self._scan_file(q.get("g", [""])[0], q.get("i", [""])[0])
            if entry is None:
                return self.send_error(HTTPStatus.NOT_FOUND)
            thumb = macos.thumbnail(entry.path)
            if not thumb:
                return self.send_error(HTTPStatus.NOT_FOUND)
            return self._send_file(thumb, cache=True)
        self._send_error("Unknown request", HTTPStatus.NOT_FOUND)

    def _scan_file(self, g, i):
        """Files are referenced by (group, index) - never by a raw path -
        so the browser can only ever touch files found by the scan."""
        scan = STATE.scan
        try:
            group = scan.groups[int(g)]
            return group.files[int(i)]
        except (AttributeError, ValueError, IndexError, TypeError):
            return None

    def _api_post(self, path, body):
        if path == "/api/choose-folder":
            prompt = str(body.get("prompt") or "Choose a folder")
            if body.get("multiple"):
                return self._send_json({"paths": macos.choose_folders(prompt)})
            return self._send_json({"path": macos.choose_folder(prompt)})
        if path == "/api/check-folder":
            p = os.path.abspath(os.path.expanduser(str(body.get("path") or "").strip()))
            return self._send_json({
                "path": p,
                "exists": os.path.isdir(p),
                "parent_exists": os.path.isdir(os.path.dirname(p)),
                "readable": os.access(p, os.R_OK),
                "writable": os.access(p, os.W_OK),
            })
        if path == "/api/job/cancel":
            if STATE.job:
                STATE.job.progress.cancel_requested = True
            return self._send_json({"ok": True})
        if path == "/api/duplicates/scan":
            roots = [str(r) for r in body.get("roots") or [] if str(r).strip()]
            preferred = [str(r) for r in body.get("preferred") or [] if str(r).strip()]
            if not roots:
                raise ValueError("Please add at least one folder to scan.")

            def work(progress):
                result = find_duplicates(roots, preferred, progress)
                STATE.scan = result
                STATE.last_apply = None
                return None

            STATE.start_job("scan", work)
            return self._send_json({"ok": True})
        if path == "/api/duplicates/apply":
            scan = STATE.scan
            if scan is None:
                raise ValueError("Please scan for duplicates first.")
            decisions = [
                {"group": g.id, "keep": g.keep, "skip": g.skip} for g in scan.groups
            ]
            if not any(not d["skip"] for d in decisions):
                raise ValueError("Nothing to do: every group is set to 'leave alone'.")

            def work(progress):
                outcome = quarantine_duplicates(scan, decisions, progress)
                STATE.last_apply = _outcome_dict(outcome)
                moved = {m["original"] for m in outcome.moved}
                # Drop moved files from the displayed result.
                remaining = []
                for g in scan.groups:
                    keep_path = g.files[g.keep].path
                    g.files = [f for f in g.files if f.path not in moved]
                    if len(g.files) > 1:
                        g.keep = next((i for i, f in enumerate(g.files) if f.path == keep_path), 0)
                        remaining.append(g)
                for i, g in enumerate(remaining):
                    g.id = i
                scan.groups = remaining

            STATE.start_job("apply", work)
            return self._send_json({"ok": True})
        if path == "/api/duplicates/keep":
            scan = STATE.scan
            if scan:
                try:
                    g = scan.groups[int(body["group"])]
                    if "keep" in body:
                        k = int(body["keep"])
                        if 0 <= k < len(g.files):
                            g.keep = k
                    if "skip" in body:
                        g.skip = bool(body["skip"])
                except (KeyError, ValueError, IndexError, TypeError):
                    pass
            return self._send_json(dict(ok=True, **(_selected(scan) if scan else {})))
        if path in ("/api/duplicates/keep-folder", "/api/duplicates/leave-pair"):
            scan = STATE.scan
            if scan is None:
                raise ValueError("Please scan for duplicates first.")
            a, b = str(body.get("keep") or body.get("a") or ""), str(body.get("other") or body.get("b") or "")
            known = {(p["a"], p["b"]) for p in folder_comparison(scan, limit=100000)}
            if (a, b) not in known and (b, a) not in known:
                raise ValueError("These folders are not part of the results any more. Please scan again.")
            if path.endswith("keep-folder"):
                changed = keep_folder(scan, a, b)
            else:
                changed = leave_pair_alone(scan, a, b)
            return self._send_json(dict(ok=True, changed=changed, **_selected(scan)))
        if path == "/api/import/start":
            options = ImportOptions(
                sources=[str(s) for s in body.get("sources") or [] if str(s).strip()],
                destination=str(body.get("destination") or ""),
                layout=str(body.get("layout") or "year/month"),
                by_camera=bool(body.get("by_camera")),
                rename=bool(body.get("rename")),
                undated_folder=bool(body.get("undated_folder")),
                keep_event_names=bool(body.get("keep_event_names")),
                set_dates=bool(body.get("set_dates", True)),
                dry_run=bool(body.get("dry_run", True)),
            )
            if not options.destination.strip():
                raise ValueError("Please choose the archive folder.")
            if not options.sources:
                raise ValueError("Please add at least one folder to import from.")

            def work(progress):
                STATE.last_import = run_import(options, progress)

            STATE.start_job("import", work)
            return self._send_json({"ok": True})
        if path == "/api/update/start":
            def work(progress):
                progress.set(phase="Looking for a new version")
                STATE.last_update = updater.update()

            STATE.start_job("update", work)
            return self._send_json({"ok": True})
        if path == "/api/restart":
            if STATE.job and STATE.job.state == "running":
                raise ValueError("Please wait until the current task has finished.")
            self._send_json({"ok": True})
            threading.Timer(0.5, restart).start()
            return None
        if path == "/api/reorganize/start":
            destination = str(body.get("destination") or "").strip()
            if not destination:
                raise ValueError("Please choose the archive folder (step 2).")
            options = _options_from(body, destination)
            options.dry_run = bool(body.get("dry_run", True))
            options.set_dates = bool(body.get("set_dates", True))

            def work(progress):
                STATE.last_reorg = reorg.reorganize(options, progress)

            STATE.start_job("reorganize", work)
            return self._send_json({"ok": True})
        if path == "/api/reorganize/undo":
            return self._send_json(reorg.undo_run(str(body.get("id") or "")))
        if path == "/api/dates/start":
            roots = [str(x) for x in body.get("roots") or [] if str(x).strip()]
            if not roots:
                raise ValueError("Please add at least one folder.")
            dry_run = bool(body.get("dry_run", True))

            def work(progress):
                STATE.last_dates = fix_dates(roots, dry_run=dry_run, progress=progress)

            STATE.start_job("dates", work)
            return self._send_json({"ok": True})
        if path == "/api/dates/undo":
            return self._send_json(undo_run(str(body.get("id") or "")))
        if path == "/api/analyze/start":
            sources = [str(x) for x in body.get("sources") or [] if str(x).strip()]
            if not sources:
                raise ValueError("Please add at least one folder to analyze.")
            destination = str(body.get("destination") or "").strip()

            def work(progress):
                a = analyze(sources, progress)
                STATE.analysis = a
                STATE.recommendation = recommend_for_archive(a, destination)

            STATE.start_job("analyze", work)
            return self._send_json({"ok": True})
        if path == "/api/analyze/preview":
            if STATE.analysis is None:
                raise ValueError("Please analyze your folders first.")
            opts = _options_from(body, str(body.get("destination") or ""))
            return self._send_json({"tree": preview_tree(STATE.analysis, opts)})
        if path in ("/api/reveal", "/api/open"):
            entry = self._scan_file(body.get("group"), body.get("index"))
            target = entry.path if entry else None
            if target is None and body.get("known_path"):
                target = self._known_path(str(body["known_path"]))
            if not target:
                raise ValueError("File not found.")
            ok = macos.reveal_in_finder(target) if path == "/api/reveal" else macos.open_file(target)
            return self._send_json({"ok": ok})
        if path == "/api/quarantine/restore":
            session = self._known_session(body.get("dir"))

            def work(progress):
                STATE.last_restore = _outcome_dict(restore_session(session, progress))

            STATE.start_job("restore", work)
            return self._send_json({"ok": True})
        if path == "/api/quarantine/trash":
            session = self._known_session(body.get("dir"))
            err = macos.move_to_trash(session)
            if err:
                raise ValueError(err)
            forget_session(session)
            return self._send_json({"ok": True})
        if path == "/api/quarantine/forget":
            session = self._known_session(body.get("dir"))
            forget_session(session)
            return self._send_json({"ok": True})
        self._send_error("Unknown request", HTTPStatus.NOT_FOUND)

    def _known_session(self, value) -> str:
        known = {s["dir"] for s in list_sessions()}
        if value not in known:
            raise ValueError("Unknown quarantine folder.")
        return value

    def _known_path(self, value: str) -> Optional[str]:
        """Allow revealing folders/files that the app itself reported."""
        known = set()
        for s in list_sessions():
            known.add(s["dir"])
        for r in (STATE.last_import, STATE.last_reorg):
            if not r:
                continue
            known.add(r.options.destination)
            if r.log_file:
                known.add(r.log_file)
            for i in r.items:
                known.add(i.source)
                known.add(i.destination)
        if value in known and os.path.exists(value):
            return value
        return None


def _selected(scan: ScanResult) -> dict:
    return {
        "selected_files": sum(len(g.files) - 1 for g in scan.groups if not g.skip),
        "selected_bytes": sum(g.size * (len(g.files) - 1) for g in scan.groups if not g.skip),
    }


def _options_from(values, destination: str) -> ImportOptions:
    values = values or {}
    return ImportOptions(
        sources=[],
        destination=destination or "Archive",
        layout=str(values.get("layout") or "year/month"),
        by_camera=bool(values.get("by_camera")),
        rename=bool(values.get("rename")),
        undated_folder=bool(values.get("undated_folder")),
        keep_event_names=bool(values.get("keep_event_names")),
    )


def _free_port(preferred: int = 8765) -> int:
    for port in list(range(preferred, preferred + 20)) + [0]:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return s.getsockname()[1]
            except OSError:
                continue
    raise RuntimeError("No free network port found")


def restart() -> None:
    """Start the (updated) app again in this same Terminal window, same
    address and same access key, so the open browser page just reloads."""
    os.environ["MEDIA_ORGANIZER_TOKEN"] = STATE.token
    print("\n  Restarting with the new version...\n")
    sys.stdout.flush()
    os.chdir(updater.app_dir())
    args = [sys.executable, "-m", "media_organizer", "--no-browser"]
    if STATE.port:
        args += ["--port", str(STATE.port)]
    os.execv(sys.executable, args)


def serve(open_browser: bool = True, port: Optional[int] = None) -> None:
    port = port or _free_port()
    STATE.port = port
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    url = f"http://127.0.0.1:{port}/#t={STATE.token}"
    print(f"\n  {APP_NAME} {__version__} is running.")
    print(f"  If the window did not open, paste this address into Safari or Chrome:\n\n    {url}\n")
    print("  Keep this window open while you use the app.")
    print("  To quit: close this window (or press Control + C).\n")
    sys.stdout.flush()
    if open_browser:
        def launch():
            if macos.open_url(url):
                print("  The app has opened in your web browser.\n")
            else:
                print("  Could not open the browser automatically.")
                print("  Hold the Command (⌘) key and double-click the address above,")
                print("  or copy it into Safari or Chrome.\n")
            sys.stdout.flush()

        threading.Timer(0.6, launch).start()
    try:
        httpd.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("\n  Stopped. You can close this window.")
    finally:
        httpd.server_close()
