"""Copy photos and videos into a tidy, date-based archive.

Safety rules:
  * Source files are never modified, moved or deleted.
  * Existing archive files are never overwritten.
  * Every copy is written under a temporary name, re-read and compared with
    the source (SHA-256) and only then given its final name.
  * A file whose exact content already exists in the archive is skipped.
"""

from __future__ import annotations

import csv
import datetime as _dt
import hashlib
import os
import re
import shutil
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .constants import IMPORT_LOG_DIR_NAME, is_media, is_sidecar
from .duplicates import Progress
from .hashing import CHUNK, HashCache, files_identical, full_hash
from .filedates import TRUSTED_SOURCES, local_timestamp, set_file_dates
from .metadata import MediaInfo, read_media_info
from . import archive_settings, photos_library
from .scanner import FileEntry, WalkReport, inside_protected_bundle, order_roots, walk_files

LAYOUTS = {
    "year/month": "%Y/%Y-%m",
    "year/date": "%Y/%Y-%m-%d",
    "year/month/date": "%Y/%Y-%m/%Y-%m-%d",
    "year": "%Y",
}


@dataclass
class ImportOptions:
    sources: List[str]
    destination: str
    layout: str = "year/month"
    by_camera: bool = False
    rename: bool = False  # prefix file names with the capture date & time
    undated_folder: bool = False  # files without camera date go to "Unknown date"
    keep_event_names: bool = False  # "2023-07 Hawaii" from a source folder named "Hawaii"
    dry_run: bool = True
    set_dates: bool = True  # copies get the date taken as their Finder dates


@dataclass
class ImportItem:
    source: str
    destination: str = ""
    status: str = ""  # copied / would copy / duplicate / error
    detail: str = ""
    date: str = ""
    date_source: str = ""
    camera: str = ""
    size: int = 0


@dataclass
class ImportResult:
    options: ImportOptions
    items: List[ImportItem] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    log_file: str = ""
    cancelled: bool = False
    run_id: str = ""  # reorganize runs that can be undone

    def count(self, status: str) -> int:
        return sum(1 for i in self.items if i.status == status)

    def bytes(self, status: str) -> int:
        return sum(i.size for i in self.items if i.status == status)


_SAFE = re.compile(r'[\\/:*?"<>|\x00-\x1f]+')


def safe_folder_name(text: str) -> str:
    text = _SAFE.sub(" ", text).strip(" .")
    return text[:60] or "Unknown camera"


# Folder names that say nothing about the content (camera cards, exports,
# dates, Photos library internals...). Anything else is treated as an event
# or album name worth keeping, e.g. "Hawaii", "Wedding Anna & Marco".
_GENERIC_FOLDER = re.compile(
    r"^("
    r"dcim|\d{3}[a-z_]{0,8}|\d{3}_\d{4}|[0-9a-f]|misc|mp_root|private|avchd|bdmv|stream|clip|"
    r"photos?|pictures?|pics|images?|videos?|movies?|media|camera( roll| uploads)?|"
    r"icloud( photos)?|photos library|originals|masters|resources|derivatives|"
    r"imports?|exports?|downloads?|desktop|documents|backups?|old|new|temp|tmp|"
    r"untitled( folder)?|new folder|nouveau dossier|nuova cartella|neuer ordner|"
    r"iphone|ipad|gopro|dji|insta360|drone|google photos|takeout|whatsapp|"
    r"(dji|gopro|insta360|img|dsc|mvi|gopr)[ _-]?\d+|no name|eos_digital|"
    r"dji album|dji_album|panorama|hyperlapse|sd card|sdcard|card|volumes|users|"
    r"\d{4}([ ._-]\d{1,2}){0,2}|\d{8}"
    r")$",
    re.I,
)
# Names made only of these words describe a device or a copy, not an event
# ("iPhone export", "Old GoPro card", "Backup copy 2").
_GENERIC_WORDS = {
    "iphone", "ipad", "phone", "gopro", "dji", "drone", "insta360", "camera", "cam",
    "card", "sd", "sdcard", "microsd", "export", "exports", "exported", "import",
    "imports", "imported", "backup", "backups", "copy", "copies", "old", "new",
    "photos", "photo", "pictures", "picture", "pics", "videos", "video", "movies",
    "media", "files", "raw", "jpg", "jpeg", "heic", "mp4", "mov", "download",
    "downloads", "from", "my", "the", "of", "and", "all", "to", "sort", "unsorted",
    "misc", "various", "icloud", "google", "whatsapp", "mac", "macbook", "disk",
    "drive", "external", "hard", "usb", "stuff", "archive", "library", "originals",
    "foto", "fotos", "immagini", "bilder", "vidéos", "vídeos", "copia", "copie",
    "random", "other", "others", "varie", "vari", "altro", "altri", "divers", "sonstiges",
    "dump", "dumps", "transfer", "transfers", "sync", "upload", "uploads",
    # containers of events, not events themselves
    "trips", "trip", "travel", "travels", "vacation", "vacations", "holiday", "holidays",
    "events", "family", "friends", "viaggi", "vacanze", "eventi", "famiglia", "reisen",
    "urlaub", "voyages", "vacances", "viajes", "albums", "album", "day", "days",
    "part", "parte", "giorno", "set", "vol", "volume",
    "desktop", "documents", "scrivania", "documenti", "misc", "temp", "tmp", "inbox",
}
_LEADING_DATE = re.compile(r"^\d{4}(?:[ ._-]?\d{2}){0,2}(?:[ ._-]+|$)")


def clean_event_name(name: str) -> str:
    """'2023-07-15 Hawaii trip' -> 'Hawaii trip'; generic names -> ''."""
    name = name.strip()
    if not name or name.startswith(".") or _GENERIC_FOLDER.match(name):
        return ""
    stripped = _LEADING_DATE.sub("", name).strip(" -_.")
    if not stripped or _GENERIC_FOLDER.match(stripped) or stripped.isdigit():
        return ""
    words = re.findall(r"[^\W_]+", stripped.lower())
    if all(w in _GENERIC_WORDS or w.isdigit() or re.match(r"^\d+[a-z]*$", w)
           or re.match(r"^(card|sd|disk|drive|cam|camera|backup)[a-z0-9]{0,2}$", w) for w in words):
        return ""
    return safe_folder_name(stripped)


# Folders this app creates itself; never mistaken for event names.
APP_FOLDER_NAMES = {"unknown camera", "unknown date"}


def event_name(path: str, root: str, camera: str = "") -> str:
    """Nearest meaningful folder name between the file and its source root.

    The source folder itself is not used (it is usually a container such as
    "Pictures" or a disk name); folders inside app libraries never give names.
    A folder named after the file's own camera ("iPhone 13 Pro", created by
    the "folder per camera" option) is skipped, so organizing an already
    organized archive gives the same result.
    """
    skip = set(APP_FOLDER_NAMES)
    if camera:
        skip.add(safe_folder_name(camera).lower())
    folder = os.path.dirname(path)
    root = root.rstrip(os.sep) or os.sep
    stop = root
    while folder and folder != stop and len(folder) > len(root):
        base = os.path.basename(folder)
        if base.lower().endswith((".photoslibrary", ".photolibrary")):
            return ""
        name = "" if base.strip().lower() in skip else clean_event_name(base)
        if name:
            return name
        parent = os.path.dirname(folder)
        if parent == folder:
            break
        folder = parent
    return ""


def target_folder(options: ImportOptions, info: MediaInfo, event: str = "") -> str:
    parts = [options.destination]
    if options.undated_folder and info.date_source == "file date":
        parts.append("Unknown date")
        if options.keep_event_names and event:
            parts.append(event)
    else:
        pattern = LAYOUTS.get(options.layout, LAYOUTS["year/month"])
        parts.extend(info.date.strftime(pattern).split("/"))
        if options.keep_event_names and event:
            if options.layout == "year":
                parts.append(event)
            else:
                parts[-1] = f"{parts[-1]} {event}"
    if options.by_camera:
        parts.append(safe_folder_name(info.camera or "Unknown camera"))
    return os.path.join(*parts)


# "2023-07-15 18.02.11 IMG_1234.HEIC": the prefix this app adds.
_APP_PREFIX = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}\.\d{2}\.\d{2} ")


def target_name(options: ImportOptions, info: MediaInfo, original_name: str) -> str:
    if not options.rename:
        return original_name
    prefix = info.date.strftime("%Y-%m-%d %H.%M.%S")
    # Replace (never stack) a date prefix added earlier, so names stay stable
    # and a wrong earlier date gets corrected.
    base = _APP_PREFIX.sub("", original_name) or original_name
    return f"{prefix} {base}"


def _copy_and_hash(src: str, dst: str, progress=None, cancelled=lambda: False) -> str:
    h = hashlib.sha256()
    with open(src, "rb") as fi, open(dst, "xb") as fo:
        while True:
            if cancelled():
                raise InterruptedError()
            block = fi.read(CHUNK)
            if not block:
                break
            h.update(block)
            fo.write(block)
            if progress:
                progress(len(block))
        fo.flush()
        os.fsync(fo.fileno())
    return h.hexdigest()


def _copy_times(src: str, dst: str) -> None:
    try:
        st = os.stat(src)
        os.utime(dst, ns=(st.st_atime_ns, st.st_mtime_ns))
    except OSError:
        pass
    try:  # keep the creation date on macOS when possible
        shutil.copystat(src, dst)
    except OSError:
        pass


def _unique_name(folder: str, name: str, taken) -> str:
    base, ext = os.path.splitext(name)
    candidate = name
    i = 1
    while os.path.lexists(os.path.join(folder, candidate)) or os.path.join(folder, candidate).lower() in taken:
        candidate = f"{base}_{i}{ext}"
        i += 1
    return candidate


class ArchiveIndex:
    """Knows which contents already exist in the destination."""

    def __init__(self, destination: str, cache: HashCache, progress: Progress):
        self.cache = cache
        self.by_size: Dict[int, List[str]] = defaultdict(list)
        self.progress = progress
        self.hashes: Dict[str, str] = {}
        if os.path.isdir(destination):
            report = WalkReport()
            n = 0
            for e in walk_files([destination], is_media, report, cancelled=progress.cancelled):
                self.by_size[e.size].append(e.path)
                n += 1
                if n % 500 == 0:
                    progress.set(done=n, current=e.path)

    def find(self, size: int, sha: str, source: str) -> Optional[str]:
        for path in self.by_size.get(size, []):
            digest = self.hashes.get(path)
            if digest is None:
                try:
                    digest = self.cache.hash(path)
                except OSError:
                    continue
                self.hashes[path] = digest
            if digest == sha and files_identical(source, path):
                return path
        return None

    def add(self, path: str, size: int, sha: str) -> None:
        self.by_size[size].append(path)
        self.hashes[path] = sha


def _sidecar_map(entries: List[FileEntry]) -> Dict[tuple, List[FileEntry]]:
    side = defaultdict(list)
    for e in entries:
        if is_sidecar(e.path):
            stem = os.path.splitext(e.path)[0].lower()
            side[stem].append(e)
    return side


def _sidecars_for(path: str, side: Dict[str, List[FileEntry]]) -> List[FileEntry]:
    stem = os.path.splitext(path)[0].lower()
    found = list(side.get(stem, []))
    # iPhone edited photos: IMG_1234.HEIC  <->  IMG_O1234.AAE
    d, b = os.path.split(stem)
    m = re.match(r"^(img_)(\d+)$", b)
    if m:
        found += side.get(os.path.join(d, f"{m.group(1)}o{m.group(2)}"), [])
    return found


def run_import(options: ImportOptions, progress: Optional[Progress] = None,
               cache: Optional[HashCache] = None) -> ImportResult:
    progress = progress or Progress()
    result = ImportResult(options=options)
    dest = os.path.abspath(os.path.expanduser(options.destination.strip()))
    options.destination = dest
    sources = order_roots(options.sources)
    options.sources = sources
    if not sources:
        raise ValueError("Please choose at least one source folder.")
    for s in sources:
        if not os.path.isdir(s):
            raise ValueError(f"Source folder not found: {s}")
        if dest == s or dest.startswith(s.rstrip(os.sep) + os.sep):
            raise ValueError(
                "The archive folder cannot be inside a source folder "
                f"({s}). Please pick a different archive folder."
            )
    parent = dest
    while not os.path.exists(parent):
        parent = os.path.dirname(parent)
    if not options.dry_run and not os.access(parent, os.W_OK):
        raise ValueError(
            f"Cannot write to {parent}. The disk may be read-only (for example an "
            "NTFS disk) or macOS has not given access to it."
        )

    own_cache = cache is None
    cache = cache or HashCache()
    try:
        progress.set(phase="Looking at the existing archive", done=0, total=0)
        archive = ArchiveIndex(dest, cache, progress)

        progress.set(phase="Listing files to import", done=0, total=0)
        report = WalkReport()
        entries = []
        for e in walk_files(
            sources, lambda n: is_media(n) or is_sidecar(n), report,
            cancelled=progress.cancelled,
        ):
            # Never walk into the archive itself if it lives inside a source.
            if e.path.startswith(dest.rstrip(os.sep) + os.sep):
                continue
            entries.append(e)
            if len(entries) % 200 == 0:
                progress.set(done=len(entries), current=e.path)
        result.errors.extend(report.errors)
        for b in report.skipped_bundles:
            result.errors.append(
                f"Skipped the app library {b} (choose its 'originals' folder "
                "with the Photos library button to import from it)."
            )
        if progress.cancelled():
            result.cancelled = True
            return result

        info_for, photos_names = media_info_loader(sources, with_names=True)

        side = _sidecar_map(entries)
        media = [e for e in entries if is_media(e.path)]
        total_bytes = sum(e.size for e in media)
        progress.set(
            phase="Checking (simulation)" if options.dry_run else "Copying and verifying",
            done=0, total=total_bytes,
        )
        done = [0]

        def advance(n):
            done[0] += n
            progress.set(done=done[0])

        seen_this_run: Dict[str, str] = {}
        taken = set()
        for e in media:
            if progress.cancelled():
                result.cancelled = True
                break
            progress.set(current=e.path)
            start_done = done[0]
            item = ImportItem(source=e.path, size=e.size)
            result.items.append(item)
            try:
                _import_one(e, options, archive, seen_this_run, taken, side, item,
                            advance, progress, cache, photos_names, info_for)
            except InterruptedError:
                result.cancelled = True
                item.status, item.detail = "error", "Cancelled"
                break
            except OSError as exc:
                item.status = "error"
                item.detail = str(exc.strerror or exc)
            done[0] = start_done + e.size
            progress.set(done=done[0])
        if not options.dry_run:
            result.log_file = _write_log(result)
            if not result.cancelled and result.count("copied"):
                archive_settings.save(dest, options)
    finally:
        if own_cache:
            cache.close()
    return result


def _library_of(source: str) -> Optional[str]:
    library = inside_protected_bundle(source) or source
    return library if library.lower().endswith(".photoslibrary") else None


def media_info_loader(sources: List[str], with_names: bool = False):
    """Return a function giving the best MediaInfo for a file.

    For files inside a Photos library, the date shown in Photos wins: it
    includes dates fixed with "Adjust Date and Time" and covers photos that
    have no date inside the file (screenshots, saved images...).
    """
    library_data: Dict[str, dict] = {}
    for s in sources:
        library = _library_of(s)
        if library:
            library_data.update(photos_library.library_info(library))

    def info_for(path: str) -> MediaInfo:
        info = read_media_info(path)
        lib = library_data.get(path)
        if lib and lib.get("date") is not None:
            return MediaInfo(lib["date"], "Photos library", info.make, info.model)
        return info

    if with_names:
        names = {p: v["name"] for p, v in library_data.items() if v.get("name")}
        return info_for, names
    return info_for


def _import_one(e, options, archive, seen_this_run, taken, side, item, advance, progress, cache,
                photos_names, info_for):
    info = info_for(e.path)
    original_name = photos_names.get(e.path) or os.path.basename(e.path)
    item.date = info.date.strftime("%Y-%m-%d %H:%M:%S")
    item.date_source = info.date_source
    item.camera = info.camera
    event = event_name(e.path, e.root, info.camera) if options.keep_event_names else ""
    folder = target_folder(options, info, event)
    name = target_name(options, info, original_name)

    sha = None
    needs_hash = e.size in archive.by_size or options.dry_run
    if needs_hash:
        sha = full_hash(e.path, advance, cancelled=progress.cancelled)
        existing = archive.find(e.size, sha, e.path)
        if existing:
            item.status, item.destination = "duplicate", existing
            item.detail = "Identical file already in the archive"
            if not options.dry_run:
                _copy_sidecars(e.path, existing, side)
            return
        if sha in seen_this_run:
            item.status, item.destination = "duplicate", seen_this_run[sha]
            item.detail = "Identical to another file in this import"
            if not options.dry_run:
                _copy_sidecars(e.path, seen_this_run[sha], side)
            return

    name = _unique_name(folder, name, taken)
    target = os.path.join(folder, name)
    taken.add(target.lower())
    item.destination = target
    if options.dry_run:
        item.status = "would copy"
        seen_this_run[sha] = target
        archive.add(target, e.size, sha)
        return

    os.makedirs(folder, exist_ok=True)
    tmp = os.path.join(folder, f".{name}.importing")
    if os.path.lexists(tmp):
        os.unlink(tmp)
    try:
        copied_sha = _copy_and_hash(e.path, tmp, advance, cancelled=progress.cancelled)
        if sha is not None and copied_sha != sha:
            raise OSError("The source file changed while it was being copied")
        if full_hash(tmp) != copied_sha:
            raise OSError("Verification failed: the copy is not identical (disk problem?)")
        _copy_times(e.path, tmp)
        if options.set_dates and info.date_source in TRUSTED_SOURCES:
            # Finder then shows when the photo was taken, not when it was
            # downloaded or copied. Only the file system dates change.
            try:
                set_file_dates(tmp, local_timestamp(info.date))
            except OSError:
                pass
        if os.path.lexists(target):
            raise OSError("A file with this name appeared in the archive meanwhile")
        os.rename(tmp, target)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    sha = copied_sha
    # A file identical to one we already copied during this run (found only
    # now because its size was new to the archive) - keep the one copy.
    if sha in seen_this_run:
        os.unlink(target)
        taken.discard(target.lower())
        item.status, item.destination = "duplicate", seen_this_run[sha]
        item.detail = "Identical to another file in this import"
        _copy_sidecars(e.path, seen_this_run[sha], side)
        return
    seen_this_run[sha] = target
    archive.add(target, e.size, sha)
    cache.put(target, sha)
    item.status = "copied"
    item.detail = "Copied and verified"
    _copy_sidecars(e.path, target, side)


def _copy_sidecars(src_path: str, target: str, side) -> None:
    new_stem = os.path.splitext(target)[0]
    for s in _sidecars_for(src_path, side):
        ext = os.path.splitext(s.path)[1]
        dst = new_stem + ext
        if os.path.lexists(dst):
            continue
        try:
            shutil.copyfile(s.path, dst)
            _copy_times(s.path, dst)
        except OSError:
            pass


def _write_log(result: ImportResult, kind: str = "import") -> str:
    folder = os.path.join(result.options.destination, IMPORT_LOG_DIR_NAME)
    try:
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, _dt.datetime.now().strftime(f"{kind} %Y-%m-%d %H-%M-%S.csv"))
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["status", "source", "destination", "capture date", "date from", "camera", "size", "detail"])
            for i in result.items:
                w.writerow([i.status, i.source, i.destination, i.date, i.date_source, i.camera, i.size, i.detail])
        return path
    except OSError:
        return ""
