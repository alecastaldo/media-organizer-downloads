"""Media Organizer - find exact duplicate photos/videos and organize archives.

Pure Python standard library, compatible with Python 3.9+ (the version Apple
ships with the Command Line Tools on macOS).
"""

__version__ = "1.2.0"
APP_NAME = "Media Organizer"
