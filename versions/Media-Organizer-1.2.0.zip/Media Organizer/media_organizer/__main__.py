"""Start the app:  python3 -m media_organizer

Command-line use (optional):
  python3 -m media_organizer                     open the app in the browser
  python3 -m media_organizer find-duplicates DIR [DIR...]   list duplicates only
"""

from __future__ import annotations

import argparse
import sys


def _human(n: float) -> str:
    for unit in ("bytes", "KB", "MB", "GB", "TB"):
        if n < 1000 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "bytes" else f"{n:.1f} {unit}"
        n /= 1000
    return str(n)


def main(argv=None) -> int:
    if sys.version_info < (3, 9):
        print("Media Organizer needs Python 3.9 or newer.")
        return 1
    parser = argparse.ArgumentParser(prog="media_organizer")
    parser.add_argument("--no-browser", action="store_true", help="do not open the browser")
    parser.add_argument("--port", type=int, default=None)
    sub = parser.add_subparsers(dest="command")
    fd = sub.add_parser("find-duplicates", help="report exact duplicates (changes nothing)")
    fd.add_argument("folders", nargs="+")
    sub.add_parser("update", help="update the app in place")
    args = parser.parse_args(argv)

    if args.command == "find-duplicates":
        from .duplicates import find_duplicates

        result = find_duplicates(args.folders)
        for g in result.groups:
            print(f"\n{len(g.files)} identical copies, {_human(g.size)} each:")
            for i, f in enumerate(g.files):
                print(("  keep   " if i == g.keep else "  extra  ") + f.path)
        print(
            f"\nScanned {result.files_scanned} files. {len(result.groups)} groups, "
            f"{result.redundant_files} extra copies, {_human(result.redundant_bytes)} could be freed."
        )
        for e in result.errors:
            print("warning:", e, file=sys.stderr)
        return 0

    if args.command == "update":
        from . import updater

        r = updater.update()
        status = r["status"]
        if status == "updated":
            print(f"\n  Updated Media Organizer {r['from']} -> {r.get('to') or 'latest'} (from {r.get('source')}).")
            print("  Start it again with Media Organizer.command.\n")
        elif status == "up-to-date":
            print(f"\n  Media Organizer {r['from']} is up to date.\n")
        else:
            if status == "old-download":
                print(f"\n  The download found ({r['source']}) is version {r['to']}, not newer than {r['from']}.")
            print("\n  The app could not download the update by itself (are you online?).")
            print("  1. Open this address in your browser:")
            print(f"       {r['download_url']}")
            print("  2. When the download has finished, run this updater again.\n")
        return 0 if status in ("updated", "up-to-date") else 2

    from .server import serve

    serve(open_browser=not args.no_browser, port=args.port)
    return 0


if __name__ == "__main__":
    sys.exit(main())
